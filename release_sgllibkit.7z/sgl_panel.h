#define SGL_PANEL			1000
#define SGL_HIDDENFRAME		SGL_PANEL + 1
#define SGL_ROUNDEDFRAME	SGL_PANEL + 2

int SGL_PanelIpaddingSet(HWND hwnd, RECT *ipad);
int SGL_PanelIpaddingGet(HWND hwnd, RECT *ipad);

typedef int (*SGL_RESIZECB)(HWND hwnd, int wOffset, int hOffset) ;
int SGL_ResizeInstall(HWND hwnd, int widthMin, int heightMin, SGL_RESIZECB resizeCB);
