/*============================================================================= TABLE CONTROL ==*/

											/*============== CONSTANT DEFINITIONS ==============*/

#define SGL_CTRL_TABLE		1400			/* object type										*/

											/*---- attributes ----------------------------------*/

typedef void (*SGL_TABLE_FILLCB)(HWND, HDC, int, int, RECT*);

typedef struct								/* table column definition							*/
{
	int  width;								/* width (0 for end)								*/
											/* width unit = pixel            (case > 0)			*/
											/*				character height (case < 0)			*/

	int headerMerge;						/* if set: merge with the next column				*/
	int cellNoRightSep;
	COLORREF cellBGcolor;					/* background color									*/
} SGL_TABLE_COLUMN_T;

int SGL_TableColumnsSet(HWND hwnd, SGL_TABLE_COLUMN_T* columns);
int SGL_TableColumnsGet(HWND hwnd, SGL_TABLE_COLUMN_T** columns);
int SGL_TableHeaderHeightSet(HWND hwnd, int linePercent);
int SGL_TableHeaderHeightGet(HWND hwnd);
int SGL_TableHeaderBorderThicknessSet(HWND hwnd, int e);
int SGL_TableHeaderBorderThicknessGet(HWND hwnd, int *e);
int SGL_TableHeightAdjust(HWND hwnd, int rowMin);
int SGL_TableRowNbSet(HWND hwnd, int rowNB);
int SGL_TableRowNbGet(HWND hwnd);
int SGL_TableRowShow(HWND hwnd, int row);
int SGL_TableSelectionModeSet(HWND hwnd, int selMode);
int SGL_TableSelectionModeGet(HWND hwnd);
int SGL_TableSelectionSet(HWND hwnd, int row, int col);
int SGL_TableSelectionGet(HWND hwnd, int *row, int *col);
int SGL_TableFillFunctionSet(HWND hwnd, SGL_TABLE_FILLCB fillFunc);
int SGL_TableUpdate(HWND hwnd, int row1, int rowNB, int col);
int SGL_TableHGridSet(HWND hwnd, int rowGrid);
int SGL_TableHGridGet(HWND hwnd);
int SGL_TableGridThicknessSet(HWND hwnd, int e);
int SGL_TableGridThicknessGet(HWND hwnd, int *e);
int SGL_TableGridColorSet(HWND hwnd, COLORREF color);
int SGL_TableGridColorGet(HWND hwnd, COLORREF *color);
int SGL_TableAltRowSet(HWND hwnd, int dim);
int SGL_TableAltRowGet(HWND hwnd, int *dim);
int SGL_TableCellHeightGet(HWND hwnd);
int SGL_TableCellCoordinatesGet(HWND hwnd, int *row, int *col);
int SGL_TableCellRectangleGet(HWND hwnd, int row, int col, RECT *rect);

/*------------------------------------------------------------------------------------------------

TIPS:

Recommended colors for columns are:
  - editable data:		SGL_WHITE
  - not editable data:	SGL_LTGRAY

Columns labels can be merged:
  - define the text in the rightmost column,
  - set a NULL label to the left columns to be merged with.

The cell width is the column width as defined in the SGL_COLUMN array. This width may include 
a separation line (bottom and right only).

The data cell (or row) height is unique and depends on the font size.

The color of selected items is the same as a selected menu option. Hidden tables do not show the 
selected items.
------------------------------------------------------------------------------------------------*/

