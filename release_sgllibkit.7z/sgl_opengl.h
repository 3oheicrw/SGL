#define SGL_CTRL_OPENGL 1700

int SGL_OglZoomSet(HWND hwnd, double nFoc) ;
int SGL_OglZoomGet(HWND hwnd, double *nFoc) ;

int SGL_OglDepthOfFieldSet(HWND hwnd, double zNear, double zFar) ;
int SGL_OglDepthOfFieldGet(HWND hwnd, double *zNear, double *zFar) ;
