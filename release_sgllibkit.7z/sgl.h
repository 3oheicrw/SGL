/*---- Main SGL include file ----*/

#include "sgl_base.h"

/* Definitions for different object types */

#include "sgl_button.h"
#include "sgl_edit.h"
#include "sgl_image.h"
#include "sgl_graph.h"
#include "sgl_opengl.h"
#include "sgl_popup.h"
#include "sgl_separator.h"
#include "sgl_table.h"
#include "sgl_tools.h"
