#define SGL_CTRL_IMAGE 1600

int SGL_ImageLoad(HWND hwnd, char* fileName) ;
int SGL_ImageLoadW(HWND hwnd, wchar_t* fileName) ;
int SGL_ImageUnload(HWND hwnd) ;

int SGL_ImageFittingSet(HWND hwnd, int fit) ;
int SGL_ImageFittingGet(HWND hwnd) ;

int SGL_ImageFrameIndexSet(HWND hwnd, int frameIndex) ;
int SGL_ImageFrameIndexGet(HWND hwnd) ;
int SGL_ImageFrameCountGet(HWND hwnd) ;

int SGL_ImagePlay(HWND hwnd, int speed100) ;

