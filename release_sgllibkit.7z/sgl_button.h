#define SGL_CTRL_BUTTON			1200
#define SGL_CTRL_PUSHBUTTON		SGL_CTRL_BUTTON + 1
#define SGL_CTRL_CHECKBUTTON	SGL_CTRL_BUTTON + 2
#define SGL_CTRL_RADIOBUTTON	SGL_CTRL_BUTTON + 3

int SGL_ButtonValueSet(HWND hwnd, int value) ;
int SGL_ButtonValueGet(HWND hwnd) ;

