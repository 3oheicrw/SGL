/*============== THIS FILE CONTAINS THE PUBLIC DEFINITIONS OF THE SGL KERNEL ===================*/


/*------------------------------------------------------------------------------------------------

SGL (Small GUI Library) is a graphical user interface library that will help you to build Win32 
applications. It handle most of the burden of the Windows environment and lets you concentrate on 
creative tasks.

It allows you to easily draw or paint you own objects without having to restart from scratch.
It introduces almost no new concepts and uses as far as possible the ones of Windows.

Features:
 - attribute inheritance
 - homogeneous set of functions
 - possibility to draw and paint your own controls

Position
	For top windows, negative coordinates centers the window on the screen; positive values 
	are pixel coordinates. For other windows and controls, position are grid coordinates.
	Fine adjustement is posible with alignment and padding control.

Size
	Positive values are pixel dimensions.
	For some controls:
	- null values set automatically the size,
	- negative values are relative dimensions.
------------------------------------------------------------------------------------------------*/

#define OEMRESOURCE
#include <windows.h>
#include <stdarg.h>
#include "sgl_panel.h"
#include "sgl_debug.h"

											/*============== CONSTANT DEFINITIONS ==============*/
/* Error codes (< 0) */

#define SGL_ERR_INT		-1							/* internal error							*/
#define SGL_ERR_ALLOC	-2							/* allocation error							*/
#define SGL_ERR_TYPE	-3							/* not compatible object					*/
#define SGL_ERR_PARM	-4							/* 1st parameter error						*/

/* Font attributes [these values are array indexes] */

#define SGL_FONT_NORMAL		1

#define SGL_FONT_FIXED		0						/* values for SGL_FONT_OPTION				*/
#define SGL_FONT_BOLD		2
#define SGL_FONT_ITALIC		3
#define SGL_FONT_SYMBOL		4
#define SGL_FONT_EXTRA		5


#define SGL_FONT_SMALL		0						/* values for SGL_FONT_SIZEIX				*/
#define SGL_FONT_LARGE		2
#define SGL_FONT_BIG		3

/* Alignment attributes (16 lsb) */

#define SGL_CENTER			0
#define SGL_LEFT			1
#define SGL_RIGHT			2
#define SGL_TOP				(SGL_LEFT << 8)
#define SGL_BOTTOM			(SGL_RIGHT << 8)

/* Frame border style */

#define SGL_BORDER_NONE			0
#define SGL_BORDER_FLAT			1
#define SGL_BORDER_RFLAT		2
#define SGL_BORDER_BEVEL_UP		3
#define SGL_BORDER_BEVEL_DOWN	4
#define SGL_BORDER_ETCHED_UP	5
#define SGL_BORDER_ETCHED_DOWN	6

/* Size constants	*/

#define SGL_WIDTH	101
#define SGL_HEIGHT	(SGL_WIDTH + 1)

/* Color handling

	Color are defined according to the win32 API, ie:  COLORREF yellow = RGB(255,255,0).
	System colors are defined by adding 0x80000000 to the GetSysColor() argument.
	The special value -1 is used to indicate that the object will inherit the color of its parent.

*/
#define SGL_SYSCOLOR	0x80000000
#define SGL_LTGRAY		(SGL_SYSCOLOR | COLOR_BTNFACE)
#define SGL_GRAY		(SGL_SYSCOLOR | COLOR_BTNSHADOW)
#define SGL_BLACK		0
#define SGL_WHITE		0x00ffffff

/* Keyboard & mouse status */

#define SGL_KEY_SHIFT (GetKeyState(VK_SHIFT) < 0)
#define SGL_KEY_CTRL  (GetKeyState(VK_CONTROL) < 0)
#define SGL_LBUTTON   (GetKeyState(VK_LBUTTON) < 0)
#define SGL_MBUTTON   (GetKeyState(VK_MBUTTON) < 0)
#define SGL_RBUTTON   (GetKeyState(VK_RBUTTON) < 0)


											/*========================================= TYPES ==*/

typedef int (*SGL_CB)(HWND hwnd, UINT event, WPARAM wParam, LPARAM lParam);
/* 
	A callback should return 1 for the fully processed events, and 0 when standard processing
	is required.
*/

typedef struct									/* context for user drawn objects				*/
{
	int selected;								/* object status								*/
	int dimmed;
	COLORREF bgdColor, fgdColor;				/* foreground & background dimmed colors		*/
	int fontSizeIx, fontStyle;					/* text attributes								*/
} SGL_CONTEXT_T;

											/*===================================== FUNCTIONS ==*/

void SGL_Init(HINSTANCE hInstance, char *iconRsc);
void SGL_Exit(void);

HWND SGL_New(HWND parent, int type, DWORD style, char *title, int left, int top);
HWND SGL_Duplicate(HWND parentDest, HWND childSource, char *title, int left, int top);

double SGL_Timer(void);

void SGL_Layout(HWND hwnd);
int SGL_Redraw(HWND hwnd);
int SGL_Run(void);
void SGL_Destroy(HWND hwnd);
																	/* set/get functions		*/
int SGL_RefSizeGet(void);
void SGL_DefPaddingSet(int l);
int SGL_DefPaddingGet(void);

int SGL_FontLoad(char* fName);
int SGL_FontFaceSet(int option, char *name);
int SGL_FontSizeSet(int sizeIx, int size);
int SGL_FontFaceGet(int option, char *name);
HFONT SGL_FontHandleGet(HWND hwnd, int sizeIx, int option);
int SGL_FontSizeGet(HWND hwnd);
int SGL_FontHeightGet(HWND hwnd);
int SGL_FontSizeIxSet(HWND hwnd, int sizeIx);
int SGL_FontSizeIxGet(HWND hwnd);
int SGL_FontStyleSet(HWND hwnd, int option);
int SGL_FontStyleGet(HWND hwnd);

int SGL_PositionSet(HWND hwnd, int left, int top);
int SGL_PositionGet(HWND hwnd, int *left, int *top);

int SGL_SizeSet(HWND hwnd, int sizeID, int size);
int SGL_SizeGet(HWND hwnd, int sizeID, int *size);

#define SGL_SAVE_POSITION	1
#define SGL_SAVE_SIZE		2
int SGL_LayoutConfigure(HWND hwnd, char *section, int op);

int SGL_AlignmentSet(HWND hwnd, int align);
int SGL_AlignmentGet(HWND hwnd);
int SGL_PaddingSet(HWND hwnd, RECT *padding);
int SGL_PaddingGet(HWND hwnd, RECT *padding);

int SGL_VisibleSet(HWND hwnd, int visible);
int SGL_VisibleGet(HWND hwnd);

void SGL_DebugSet(HWND hwnd, int debugLevel);
int SGL_DebugGet(HWND hwnd);

int SGL_CursorPositionSet(HWND hwnd, POINT *pt);
int SGL_CursorPositionGet(HWND hwnd, int current, POINT *pt);

int SGL_TitleSet(HWND hwnd, char* title);
int SGL_TitleGet(HWND hwnd, char** title);

int SGL_DimmedSet(HWND hwnd, int dimmed);
int SGL_DimmedGet(HWND hwnd);

int SGL_BGcolorSet(HWND hwnd, COLORREF color);
int SGL_BGcolorGet(HWND hwnd);
int SGL_FGcolorSet(HWND hwnd, COLORREF color);
int SGL_FGcolorGet(HWND hwnd);

int SGL_BorderStyleSet(HWND hwnd, int style);
int SGL_BorderStyleGet(HWND hwnd);
int SGL_BorderThicknessSet(HWND hwnd, int e);
int SGL_BorderThicknessGet(HWND hwnd, int *e);
int SGL_BorderColorSet(HWND hwnd, COLORREF color);
int SGL_BorderColorGet(HWND hwnd, COLORREF *color);
int SGL_BorderDraw(HDC hdc, RECT *rect, int style, int width, int color, int dim);

int SGL_CallbackFunctionSet(HWND hwnd, SGL_CB func);
int SGL_CallbackFunctionGet(HWND hwnd, SGL_CB *func);
int SGL_CallbackDataSet(HWND hwnd, void *dataPtr);
int SGL_CallbackDataGet(HWND hwnd, void ** dataPtr);

int SGL_ContextGet(HWND hwnd, SGL_CONTEXT_T *context);
