int SGL__tableInit(void) ;
int SGL__tableNew(SGL_T *sgl) ;
void SGL__tableExit(void) ;
