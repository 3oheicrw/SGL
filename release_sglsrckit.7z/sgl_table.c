/*================================================================================= SGL_TABLE.C ==
SGL TABLE object.

Limitations:
 - object with not adjustable (can be added with an appropriate callback),
 - fixed row height (a bit more complicated).

==================================================================================================
date       author			update
----       ------			------
14/06/..   h serindat		creation start
15/09/04					v1.0 - first release
15/09/29					minor update SGL__tableNew(): default args of CreateWindowEx()
15/10/06					added missing break at end of the WM_PAINT case in tableProc()
16/01/11					v1.2 - winProc renamed sglProc to prevent confusion
16/06/03					v1.3 - SGL_TableUpdate() accepts row = -1 (header) and col = -1 (row)
							       SGL_TableCellRectangleGet() error case update
							       tableProc() improved for speed (cf. validate rectangle)
							       fillCB() explicit end notifications
16/07/04					       default cell background color: table background color
16/07/06					       update of internal tools
16/07/16					       new function SGL_TableHeightAdjust()
================================================================================================*/

#include <limits.h>

#include "sgl_base_.h"
#include "sgl_table.h"
#include "sgl_table_.h"

typedef struct								/* specific object data								*/
{
	SGL_T *sgl ;							/* back pointer (not duplicated)					*/
	SGL_TABLE_COLUMN_T *columns ;			/* table columns									*/
	SGL_TABLE_FILLCB fillCB ;				/* table filling function							*/
	int headerH100 ;						/* headerHeight (number of lines * 100)				*/
	int headerBorderThickness ;				/* width of the header's border						*/
	int rowN, row1 ;						/* number of rows, index of 1st visible row			*/
	int rowV ;								/* number of visible rows (max)						*/
	int topCell ;							/* vertical coordinate of the top cell in the table	*/
	int cellHeight ;						/* height of data cells								*/
	int rowGrid ;							/* show row grid 									*/
	int gridThickness ;						/* cell border thickness							*/
	COLORREF gridColor ;					/* color of the cell frame							*/
	int altLinesEnhance ;					/* show odd lines grighter							*/
	int selMode ;							/* select mode 0: none, 1: cell, 2: line, 3: lines	*/
	int selectR, select2 ;					/* index of selected item[s]						*/
} SGL_TABLE_T ;

/* local functions */

static int parmIgnore(SGL_T *sgl, int dum, int check) ;
static void tableResize(SGL_T *sgl) ;
static LRESULT tableProc(HWND hwnd, SGL_T *sgl, UINT message, WPARAM wParam, LPARAM lParam) ;

/* default metrics	*/

#define HEADERBORDERWIDTH	-23
#define CELLBORDERWIDTH		-13

/* debug condition */

#define DEBUG (sgl->debug ? STD : NONE)


/*============================================================================== DESIGN NOTES ====

The filling callback function allows the user to paint the content of each header and cell.
When the data must be retrieved from a large file, it may be usefull to know when to open, 
seek and close the file and not only read a given record.

Prototype:	void fillCB(HWND hwnd, int row, int col, HDC hdc, RECT *rect)

	hwnd		window's object
	row			table row				-1 for the header
	col			table column			-1 at start of each row
	hdc			device context			NULL at end of paint
	rect		cell client rectangle

The return value is only used at start of each row: if not null, the painted process stops.

Use cases:

 - Notifications:

		fillCB(hwnd,  -1, -1, hdc,  &rect) ;	start of filling
		fillCB(hwnd, row, -1, hdc,  NULL) ;		start of row
		fillCB(hwnd,  -1, -1, NULL, &rect) ;	end of filling

 - Normal case:

		fillCB(hwnd,  -1, col, hdc, &rect) ;	to paint the header (col)
		fillCB(hwnd, row, col, hdc, &rect) ;	to paint the cell (row, col)

		The fillCB uses hdc and rect to perform custom drawings.
		If the drawing parameters have been changed, they must be restored before return,
		excepted for the font color.

================================================================================================*/


/*=========================================================================== LOCAL FUNCTIONS ==*/

/*----------------------------------------------------------------------------------------------*/
static int getVScrollPos(HWND hwnd)					/* 32-bit scroll position					*/
{
	SCROLLINFO si = {sizeof(si), SIF_POS} ;
	GetScrollInfo(hwnd, SB_VERT, &si) ;
	return si.nPos ;
}

/*----------------------------------------------------------------------------------------------*/
static int getVScrollTrack(HWND hwnd)				/* 32-bit scroll tracking position			*/
{
	SCROLLINFO si = {sizeof(si), SIF_TRACKPOS} ;
	GetScrollInfo(hwnd, SB_VERT, &si) ;
	return si.nTrackPos ;
}

/*----------------------------------------------------------------------------------------------*/
static int headerHeight(SGL_TABLE_T *table)
{
	return (table->headerH100 * SGL__getFontHeight(table->sgl)) / 100 
			+ 2 * (SIZE(table->headerBorderThickness) + SIZE(SGL_defPad / 2)) ;
}

/*----------------------------------------------------------------------------------------------*/
static int colWidth(SGL_TABLE_T *table, int col)	/* get the pixel width  of a column			*/
{													/* if col = -1: get the with of the table	*/
	int result = -1 ;

	if (table->columns)
	{
		int w ;														/* column width				*/
		int fullWidth = 0 ;											/* width of all columns		*/
		for (int c = 0 ; w = table->columns[c].width ; c++)
		{
			if (w < 0)
				w *= - SGL__getFontHeight(table->sgl) ;
			if (c == col)
			{
				result = w ;
				break ;
			}
			else
				fullWidth += w ;
		}
		if (col < 0)
			result = fullWidth ;
	}
	return result ;
}

/*----------------------------------------------------------------------------------------------*/
static void cellFrame(SGL_TABLE_T *table, HDC hdc, RECT *rect, int mk, COLORREF color)
/*------------------------------------------------------------------------------------------------
This function draws the frame of a cell.
The frame is defined by its color and its width (module variable).
It is painted on some sides of the cell rectangle (rect) according to the mask mk:
	0x0001	right side
	0x0002	bottom side
	0x0004	left side
On output, the rectangle is reduced by the frame width.
------------------------------------------------------------------------------------------------*/
{
	SetDCPenColor(hdc, color) ;
	SelectObject(hdc, GetStockObject(DC_PEN)) ;

	for (int w = 0 ; w < SIZE(table->gridThickness) ; w++)
	{
		if (mk & 0x0001)									/* paint the right side				*/
		{
			rect->right-- ;
			MoveToEx(hdc, rect->right, rect->top, NULL) ;
			LineTo(hdc, rect->right, rect->bottom) ;
		}
		if (mk & 0x0002)									/* bottom side						*/
		{
			rect->bottom-- ;
			MoveToEx(hdc, rect->left, rect->bottom, NULL) ;
			LineTo(hdc, rect->right, rect->bottom) ;
		}
		if (mk & 0x0004)									/* left side						*/
		{
			MoveToEx(hdc, rect->left, rect->top, NULL) ;
			LineTo(hdc, rect->left, rect->bottom) ;
			rect->left++ ;
		}
	}
}

/*----------------------------------------------------------------------------------------------*/
static void tableVscroll(SGL_TABLE_T *table, int row1New)
{
	int row1Max = max(0, table->rowN - table->rowV) ;		/* limit rowInc to the table size	*/
	if (row1New > row1Max) row1New = row1Max ;
	if (row1New < 0) row1New = 0 ;

	int rowInc = row1New - table->row1 ;
	if (rowInc)
	{
		HWND hwnd = table->sgl->hwnd ;
		SetFocus(hwnd) ;									/* close modless controls if any	*/

		table->row1 = row1New ;								/* new 1st visible row				*/

		RECT scrollRect ;											/* scroll window			*/
		GetClientRect(hwnd, &scrollRect) ;
		scrollRect.top = table->topCell ;

		ScrollWindow(hwnd, 0, - rowInc * table->cellHeight, &scrollRect, &scrollRect) ;

		UpdateWindow(hwnd) ;										/* display new rows			*/
	}
}


/*========================================================================= PRIVATE FUNCTIONS ==*/

/*----------------------------------------------------------------------------------------------*/
int SGL__tableInit(void) { return 0 ; }
void SGL__tableExit(void) { return ; }

/*----------------------------------------------------------------------------------------------*/
int SGL__tableNew(SGL_T *sgl)								/* create a new table				*/
{
	if (sgl->type != SGL_CTRL_TABLE) return SGL_ERR_TYPE ;
	if (sgl->hwndParent == NULL)	 return SGL_ERR_PARM - 0 ;	/* parent must exist			*/

	NEW(SGL_TABLE_T, table) ;
	if (sgl->ex)											/* case duplicate					*/
		*table = *(SGL_TABLE_T*)sgl->ex ;
	else													/* case new							*/
	{
		sgl->typeName = "TABLE" ;
		sgl->parmIgnore = parmIgnore ;								/* check for std attributes	*/
		sgl->resizeObj = tableResize ;
		sgl->sglProc = tableProc ;

		table->headerH100 = 100 ;									/* default attributes		*/
		table->headerBorderThickness = HEADERBORDERWIDTH ;
		table->rowGrid = 1 ;
		table->gridThickness = CELLBORDERWIDTH ;
		table->gridColor = SGL_GRAY ;
	}

	sgl->ex = table ;
	table->sgl = sgl ;

	sgl->hwnd = CreateWindowEx(0, MAINCLASSNAME, sgl->title, sgl->winStyle | sgl->uStyle,
							    0, 0, 0, 0,
							    sgl->hwndParent, (HMENU) 0, SGL__instance, NULL) ;
	if (sgl->hwnd == NULL)
		return SGL_ERR_ALLOC ;

	return 0 ;
}

/*----------------------------------------------------------------------------------------------*/
static int parmIgnore(SGL_T *sgl, int check, int dum)
{
	if (check == CHECK_BORDERSTYLE || check == CHECK_BORDERTHICKNESS)
		return 1 ;
	return 0 ;
}

/*----------------------------------------------------------------------------------------------*/
static void tableResize(SGL_T *sgl)							/* resize a table					*/
{
	SGL_TABLE_T *table = sgl->ex ;
	table->cellHeight = SGL__getFontHeight(table->sgl) 
						+ 2 * (SIZE(table->gridThickness) + SIZE(SGL_defPad / 2)) ;

	for (int i = 0 ; i < 2 ; i++)						/* 0: horizontal, 1: vertical			*/
	{
		int l = 0 ;											/* width or heigth					*/
		if (sgl->uSize[i] == 0)								/* case autosize					*/
		{
			if (i == 0)												/* auto width				*/
				l = colWidth(table, -1) ;									/* columns' width	*/
			else													/* auto height				*/
				l = headerHeight(table) + 8 * table->cellHeight ;
		}
		else if (sgl->uSize[i] < 0)
		{
			if (i == 0)										/* width in char height				*/
				l = - sgl->uSize[i] * SGL__getFontHeight(table->sgl) ;
			else											/* height: number of visible rows	*/
				l = headerHeight(table) - sgl->uSize[i] * table->cellHeight ;
		}
		else
			l = sgl->uSize[i] ;								/* user size in pixels				*/

		if (sgl->scrollBars[1 - i])							/* add non client objects			*/
			l += GetSystemMetrics(i ? SM_CXHSCROLL : SM_CXVSCROLL) ;

		RECT_SETWH(i, sgl->rect, l)
	}
}


/*========================================================================= SET/GET FUNCTIONS ==*/

#define CHECK_OBJ(h, t)		SGL_T* sgl = SGL__getStruct(h) ;								\
							if (sgl == NULL)					return SGL_ERR_PARM - 0 ;	\
							if (sgl->type != SGL_CTRL_TABLE)	return SGL_ERR_TYPE ;		\
							SGL_TABLE_T *t = sgl->ex ;										\
							if (t == NULL)						return SGL_ERR_INT ;

int SGL_TableColumnsSet(HWND hwnd, SGL_TABLE_COLUMN_T* columns)
{
	CHECK_OBJ(hwnd, table) ;
	if (columns == NULL)		return SGL_ERR_PARM - 1 ;

	table->columns = columns ;
	return 0 ;
}

int SGL_TableColumnsGet(HWND hwnd, SGL_TABLE_COLUMN_T** columns)
{
	CHECK_OBJ(hwnd, table) ;
	if (columns == NULL)		return SGL_ERR_PARM - 1 ;

	*columns = table->columns ;
	return 0 ;
}

int SGL_TableHeaderHeightSet(HWND hwnd, int linePercent)
{
	CHECK_OBJ(hwnd, table) ;
	if (linePercent < 100)		return SGL_ERR_PARM - 1 ;

	table->headerH100 = linePercent ;
	return 0 ;
}

int SGL_TableHeaderHeightGet(HWND hwnd)
{
	CHECK_OBJ(hwnd, table) ;
	return table->headerH100 ;
}

int SGL_TableHeaderBorderThicknessSet(HWND hwnd, int e)
{
	CHECK_OBJ(hwnd, table) ;
	table->headerBorderThickness = e ;
	return 0 ;
}

int SGL_TableHeaderBorderThicknessGet(HWND hwnd, int *e)
{
	CHECK_OBJ(hwnd, table) ;
	if (e == NULL)				return SGL_ERR_PARM - 1 ;
	*e = table->headerBorderThickness ;
	return 0 ;
}

int SGL_TableRowNbSet(HWND hwnd, int rowNB)
{
	CHECK_OBJ(hwnd, table) ;
	if (rowNB < 0)		return SGL_ERR_PARM - 1 ;

	table->rowN = rowNB ;
	return 0 ;
}

int SGL_TableRowNbGet(HWND hwnd)
{
	CHECK_OBJ(hwnd, table) ;
	return table->rowN ;
}

int SGL_TableHeightAdjust(HWND hwnd, int rowMin)
{
	SGL_Layout(hwnd) ;
	CHECK_OBJ(hwnd, table) ;
	if (rowMin < 0) return SGL_ERR_PARM - 1 ;
	RECT r ; GetClientRect(hwnd, &r) ;
	int h = RECT_GETWH(1, r) - headerHeight(table) ;
	int rowNb = max(rowMin, (h + 1) / table->cellHeight) ;
	SGL_SizeSet(hwnd, SGL_HEIGHT, - rowNb) ;
	return headerHeight(table) + rowMin * table->cellHeight ;		/* minimum height (pixesl)	*/
}

int SGL_TableRowShow(HWND hwnd, int row)
{
	CHECK_OBJ(hwnd, table) ;
	if (row < 0 || row >= table->rowN)	return SGL_ERR_PARM - 1 ;

	int redraw = 1 ;
	if (table->row1 > row)
		table->row1 = row ;
	else if (table->row1 <  row - table->rowV + 1)
		table->row1 = row - table->rowV + 1 ;
	else
		redraw = 0 ;

	if (redraw)
		SGL_Redraw(hwnd) ;
	return 0 ;
}

int SGL_TableSelectionModeSet(HWND hwnd, int selMode)
{
	CHECK_OBJ(hwnd, table) ;
	if (selMode < 0 || selMode > 3)	return SGL_ERR_PARM - 1 ;

	table->selMode = selMode ;
	return 0 ;
}

int SGL_TableSelectionModeGet(HWND hwnd)
{
	CHECK_OBJ(hwnd, table) ;
	return table->selMode ;
}

int SGL_TableSelectionSet(HWND hwnd, int row, int col)
{
	CHECK_OBJ(hwnd, table) ;
														/* save the previous cell range	*/
	int r1 =  table->selMode == 3 ? min(table->selectR, table->select2) : table->selectR ;
	int nr = (table->selMode == 3 ? abs(table->selectR - table->select2) : 0) + 1 ;
	int c1 = table->selMode < 2 ? table->select2 : -1 ;

	if (row >= 0)	table->selectR = row ;				/* set the new values			*/
	if (col >= 0)	table->select2 = col ;				/* < 0 values are ignored		*/

	SGL_TableUpdate(hwnd, r1, nr, c1) ;					/* redraw the previous range	*/

														/* new cell range				*/
	r1 =  table->selMode == 3 ? min(table->selectR, table->select2) : table->selectR ;
	nr = (table->selMode == 3 ? abs(table->selectR - table->select2) : 0) + 1 ;
	c1 = table->selMode < 2 ? table->select2 : -1 ;
	SGL_TableUpdate(hwnd, r1, nr, c1) ;					/* redraw the new cell range	*/
	return 0 ;
}

int SGL_TableSelectionGet(HWND hwnd, int *row, int *col)
{
	CHECK_OBJ(hwnd, table) ;
	if (row) *row = table->selectR ;
	if (col) *col = table->select2 ;
	return 0 ;
}

int SGL_TableFillFunctionSet(HWND hwnd, SGL_TABLE_FILLCB fillFunc)
{
	CHECK_OBJ(hwnd, table) ;
	table->fillCB = fillFunc ;
	return 0 ;
}

int SGL_TableUpdate(HWND hwnd, int row1, int rowNB, int col)
/*
	Updated rows:	if row1=-1:	header (rowNB is ignored)
					else:		rowNB rows starting at row1
	If col=-1: the full row is updated.
*/
{
	CHECK_OBJ(hwnd, table) ;
	SGL_Log(DEBUG, "TABLE invalidate [rows %d..%d, col %d]", row1, row1 + rowNB, col) ;

	RECT rect = {0, 0, 0, 0} ;

	int w = colWidth(table, col) ;
	if (w < 0)
		return SGL_ERR_PARM - 4 ;

	rect.right = w ;
	for (int ic = 0 ; ic < col ; ic++)
		rect.left += colWidth(table, ic) ;
	rect.right += rect.left ;

	if (row1 == -1)												/* case header					*/
	{
		rect.top    = 0 ;
		rect.bottom = table->topCell ;

		for ( --col ; col >= 0 && table->columns[col].headerMerge; col-- )
			rect.left -= colWidth(table, col) ;						/* include merge columns	*/
	}
	else														/* case standard cell			*/
	{
		if (row1 < table->row1 || row1 >= table->row1 + table->rowV)
			return SGL_ERR_PARM - 2 ;
		if (row1 + rowNB - 1 >= table->row1 + table->rowV)
			return SGL_ERR_PARM - 3 ;
		rect.top    = (row1 - table->row1) * table->cellHeight + table->topCell ;
		rect.bottom = rect.top + rowNB * table->cellHeight ;
	}

	InvalidateRect(hwnd, &rect, 0) ;
	return 0 ;
}

int SGL_TableHGridSet(HWND hwnd, int rowGrid)
{
	CHECK_OBJ(hwnd, table) ;
	table->rowGrid = rowGrid ? 1 : 0 ;
	return 0 ;
}

int SGL_TableHGridGet(HWND hwnd)
{
	CHECK_OBJ(hwnd, table) ;
	return table->rowGrid ;
}

int SGL_TableGridThicknessSet(HWND hwnd, int e)
{
	CHECK_OBJ(hwnd, table) ;
	table->gridThickness = e ;
	return 0 ;
}

int SGL_TableGridThicknessGet(HWND hwnd, int *e)
{
	CHECK_OBJ(hwnd, table) ;
	if (e == NULL)				return SGL_ERR_PARM - 1 ;
	*e = table->gridThickness ;
	return 0 ;
}

int SGL_TableGridColorSet(HWND hwnd, COLORREF color)
{
	CHECK_OBJ(hwnd, table) ;
	table->gridColor = color ;
	return 0 ;
}

int SGL_TableGridColorGet(HWND hwnd, COLORREF *color)
{
	CHECK_OBJ(hwnd, table) ;
	if (color == NULL)			return SGL_ERR_PARM - 1 ;
	*color = table->gridColor ;
	return 0 ;
}

int SGL_TableAltRowSet(HWND hwnd, int enh)
{
	CHECK_OBJ(hwnd, table) ;
	table->altLinesEnhance = enh ;
	return 0 ;
}

int SGL_TableAltRowGet(HWND hwnd, int *enh)
{
	CHECK_OBJ(hwnd, table) ;
	if (enh == NULL)			return SGL_ERR_PARM - 1 ;
	*enh = table->altLinesEnhance ;
	return 0 ;
}

int SGL_TableCellHeightGet(HWND hwnd)
{
	CHECK_OBJ(hwnd, table) ;
	return table->cellHeight ;
}

int SGL_TableCellCoordinatesGet(HWND hwnd, int *row, int *col)
{
	CHECK_OBJ(hwnd, table) ;

	POINT pt ;												/* mouse table coordinates			*/
	SGL_CursorPositionGet(hwnd, 0, &pt) ;					/* position at last message			*/

	int c ;													/* get column						*/
	for (c = -1 ; pt.x >= 0 ; c++)
	{
		int w = colWidth(table, c + 1) ;
		if (w <= 0)													/* if past last column		*/
			return SGL_ERR_PARM - 2 ;
		pt.x -= w ;
	}

	int r ;															/* get row					*/
	if (pt.y < table->topCell)												/* in header		*/
		r = -1 ;
	else if (table->cellHeight)												/* in data			*/
	{
		r = table->row1 + (pt.y - table->topCell) / table->cellHeight ;
		if (r >= table->rowN)
			return SGL_ERR_PARM - 1 ;
	}
	else
		return SGL_ERR_INT ;										/* table not yet painted	*/

	int result = 0 ;
	if (col == NULL)
		result = SGL_ERR_PARM - 2 ;
	else
		*col = c ;
	if (row == NULL)
		result = SGL_ERR_PARM - 1 ;
	else *row = r ;
	SGL_Log(DEBUG, "TABLE Cell coordinates [row, col]: %d, %d", r, c) ;
	return result ;
}

int SGL_TableCellRectangleGet(HWND hwnd, int row, int col, RECT *rect)
{
	CHECK_OBJ(hwnd, table) ;
	if (row != -1 && (row < table->row1 || row >= table->row1 + table->rowV))
		return SGL_ERR_PARM - 1 ;
	if (col < 0)									/* check column								*/
		return SGL_ERR_PARM - 2 ;
	int colW = colWidth(table, col) ;				/* column width								*/
	if (colW <= 0)
		return SGL_ERR_PARM - 2 ;

	if (rect == NULL)								/* check rectangle							*/
		return SGL_ERR_PARM - 3 ;
	rect->left = rect->top = 0 ;					/* initial position							*/

	int w ;											/* border thickness							*/
	if (row < 0)									/* adjust size and exclude borders			*/
	{														/* for header - cf WM_PAINT			*/
		w = SIZE(table->headerBorderThickness) ;
		rect->top = rect->left =             w ;
		rect->right =                 colW - w ;
		rect->bottom = headerHeight(table) - w ;
	}
	else
	{														/* for cell - cf frameCell()		*/
		w = SIZE(table->gridThickness) ;
		if (col == 0)
			rect->left = w ;
		rect->right = colW - w ;
		rect->bottom = table->cellHeight - w ;
	}

	POINT pt = {0} ;								/* rectangle origin							*/
	for (int c = 0 ; c < col ; c++)							/* in the table window				*/
		pt.x += colWidth(table, c) ;
	pt.y = (row < 0) ? 0 : (row - table->row1) * table->cellHeight + table->topCell ;
	ClientToScreen(sgl->hwnd, &pt) ;						/* in the screen					*/

	OffsetRect(rect, pt.x, pt.y) ;					/* move rectangle to its origin				*/
	return 0 ;
}

/*========================================================================== WINDOW PROCEDURE ==*/

static LRESULT tableProc(HWND hwnd, SGL_T *sgl, UINT message, WPARAM wParam, LPARAM lParam)
{
	LRESULT result = DEFPROC ;						/* default result: no message processed		*/

	SGL_TABLE_T *table = sgl->ex ;

	switch (message)
	{
		case WM_LBUTTONDOWN :
		{
			if (table->selMode)
			{
				int r, c ;									/* r, c: clicked cell				*/
				if (0 == SGL_TableCellCoordinatesGet(sgl->hwnd, &r, &c) && r >= 0)
				{
					if (table->selMode == 3)							/* case multiline		*/
						c = (MK_SHIFT & wParam) ? table->select2 : r ;
					CHKERR(SGL_TableSelectionSet(sgl->hwnd, r, c)) ;	/* change selection		*/
				}
			}
			break ;
		}

		case WM_VSCROLL :
		case WM_MOUSEWHEEL :
		{
			int rowNew = table->row1 ;						/* may exceed available rows		*/

			if (message == WM_VSCROLL)						/* case vertical scroll				*/
			{
				switch (LOWORD(wParam))
				{
					case SB_LINEUP :		rowNew-- ;							break ;
					case SB_LINEDOWN :		rowNew++ ;							break ;
					case SB_PAGEUP :		rowNew -= table->rowV - 1 ;			break ;
					case SB_PAGEDOWN :		rowNew += table->rowV - 1 ;			break ;
					case SB_TOP :			rowNew = 0 ;						break ;
					case SB_BOTTOM :		rowNew = table->rowN ;				break ;
					case SB_THUMBPOSITION :	rowNew = getVScrollPos(hwnd) ;		break ;
					case SB_THUMBTRACK :	rowNew = getVScrollTrack(hwnd) ;	break ;
				}
			}
			else											/* case mouse wheel					*/
			{
				int inc = 3 ;										/* default increment		*/
				if (table->rowV < 10)
					inc = 1 ;
				if (MK_SHIFT & LOWORD(wParam))						/* if shift					*/
					inc = table->rowV - 1 ;							/*	page scroll				*/

				int rot = (short) HIWORD(wParam) / WHEEL_DELTA ;	/* wheel rotation			*/

				rowNew -= rot * inc ;
			}

			tableVscroll(table, rowNew ) ;
			result = 0 ;
			break ;
		}

		case WM_KEYDOWN :
		{
			if (wParam == VK_SHIFT || wParam == VK_CONTROL)		/* not used alone				*/
				break ;

			result = 0 ;								/* process row index					*/
			int rowNew = table->selMode ? table->selectR : table->row1 ;
			switch (wParam)
			{												/* may excedd available rows		*/
				case VK_UP :		rowNew-- ;						break ;
				case VK_DOWN :		rowNew++ ;						break ;
				case VK_PRIOR :		rowNew -= table->rowV - 1 ;		break ;
				case VK_NEXT :		rowNew += table->rowV - 1 ;		break ;
				case VK_HOME :		rowNew = 0 ;					break ;
				case VK_END :		rowNew = table->rowN ;			break ;
				default :			result = DEFPROC ;
			}

			if (result == 0)
			{
				if (table->selMode == 0)					/* scroll only						*/
					tableVscroll(table, rowNew) ;
				else										/* change selected row				*/
				{
					if (rowNew < 0) rowNew = 0 ;					/* min/max values			*/
					if (rowNew >= table->rowN) rowNew = table->rowN - 1 ;

					if (table->selMode == 3 && !SGL_KEY_SHIFT)		/* case multiline			*/
						CHKERR(SGL_TableSelectionSet(hwnd, rowNew, rowNew))
					else
						CHKERR(SGL_TableSelectionSet(hwnd, rowNew, -1))

					if (rowNew < table->row1)				/* make the updated line visible	*/
						tableVscroll(table, rowNew) ;
					if (rowNew >= table->row1 + table->rowV)
						tableVscroll(table, rowNew - table->rowV + 1) ;
				}
				break ;
			}

			result = 0 ;								/* process column index					*/
			if (table->selMode == 1)
			{
				int colInc = 0 ;		
				switch (wParam)
				{
					case VK_LEFT :		colInc = - 1 ;					break ;
					case VK_RIGHT :		colInc =   1 ;					break ;
					default :			result = DEFPROC ;
				}

				if (result == 0)
				{
					int colN ;							/* number of columns					*/
					for (colN = 0 ; table->columns[colN].width ; colN++) ;

					int newCol = table->select2 + colInc ;
					if (newCol < 0)			newCol = 0 ;
					if (newCol > colN - 1)	newCol = colN - 1 ;
					if (newCol != table->select2)
					{
						CHKERR(SGL_TableSelectionSet(hwnd, -1, newCol)) ;
						break ;
					}
				}
			}
			break ;
		}

		case WM_PAINT :
		{
			PAINTSTRUCT ps ;
			HDC hdc = BeginPaint(hwnd, &ps) ;

			SGL_TABLE_COLUMN_T *columns = table->columns ;
			int colN = 0 ;								/* number of columns					*/
			if (columns)
				for (colN = 0 ; columns[colN].width ; colN++) ;
			int r, c ;									/* current row and column				*/

			RECT fcell, cell ;							/* cell rectangle with / without frame	*/
			GetClientRect(hwnd, &fcell) ;
			int tableHeight = RECT_GETWH(1, fcell) ;	/* size of the table (client area)		*/
			int tableWidth  = RECT_GETWH(0, fcell) ;

			SetBkMode(hdc, TRANSPARENT) ;				/* text writing mode					*/
			SelectObject(hdc, SGL__getFont(sgl)) ;

			SetDCBrushColor(hdc, sgl->context.bgdColor) ;	/* table background color			*/
			SetTextColor(hdc, sgl->context.fgdColor) ;		/* text for title and headers		*/

			SGL_TABLE_FILLCB fillCB = table->fillCB ;	/* filling function						*/
			if (fillCB == NULL)								/* case none: erase table			*/
			{
			    FillRect(hdc, &fcell, GetStockObject(DC_BRUSH)) ;
				break ;
			}

			fillCB(hwnd, hdc, - 1, -1, NULL) ;			/* notify start of paint				*/

												/*---- paint headers ---------------------------*/
			fcell.bottom = fcell.top + headerHeight(table) ;
			if (fcell.bottom >= fcell.top &&						/* header exists			*/
				fcell.bottom > ps.rcPaint.top && fcell.top < ps.rcPaint.bottom)
			{
				fcell.left = 0 ; fcell.right = tableWidth ;			/* header background		*/
			    FillRect(hdc, &fcell, GetStockObject(DC_BRUSH)) ;

				fcell.right = 0 ;
				for (c = 0 ; c < colN ; c++)
				{
					fcell.right += colWidth(table, c) ;
					if (columns[c].headerMerge)
						continue ;
					if (fcell.right >= 0 &&					/* check if it has to be painted	*/
						fcell.right > ps.rcPaint.left && fcell.left < ps.rcPaint.right)
					{
						cell = fcell ;
						SGL_BorderDraw(hdc, &cell, SGL_BORDER_BEVEL_UP, 
											SIZE(table->headerBorderThickness),
											sgl->context.bgdColor,
											sgl->context.dimmed) ;
						fillCB(hwnd, hdc, -1, c, &cell) ;			/* user draw				*/
					}
					fcell.left = fcell.right ;
					if (fcell.left > tableWidth) break ;
				}
			}
			fcell.top = fcell.bottom ;

			fcell.left = colWidth(table, -1) ;	/*---- paint background at right of data -------*/
			fcell.right = tableWidth ;
			if (fcell.left < fcell.right)
			{
				fcell.bottom = tableHeight ;
			    FillRect(hdc, &fcell, GetStockObject(DC_BRUSH)) ;	/* same color as above		*/
			}

												/*---- paint data ------------------------------*/
			COLORREF bgCell[colN][2] ;
			for (c = 0 ; c < colN ; c++)				/* cell background colors				*/
			{
				COLORREF color = columns[c].cellBGcolor ;
				if (color == -1)
					bgCell[c][0] = sgl->context.bgdColor ;
				else
					bgCell[c][0] = SGL_ColorDim(color, sgl->context.dimmed) ;
				int cr = GetRValue(bgCell[c][0]) - 10 * table->altLinesEnhance ; 
				int cg = GetGValue(bgCell[c][0]) - 10 * table->altLinesEnhance ;
				int cb = GetBValue(bgCell[c][0]) - 10 * table->altLinesEnhance ;
				cr = max(0, cr) ; cr = min(255, cr) ;
				cg = max(0, cg) ; cg = min(255, cg) ;
				cb = max(0, cb) ; cb = min(255, cb) ;
				bgCell[c][1] = RGB(cr, cg, cb) ;
			}
			COLORREF gridColor = SGL_ColorDim(table->gridColor, sgl->context.dimmed) ;

			table->topCell = fcell.top ;				/* top of data							*/

			table->rowV = (tableHeight - fcell.top) / table->cellHeight ;
			int row1Max = max(0, table->rowN - table->rowV) ;
			if (table->row1 > row1Max)
				table->row1 = row1Max ;

			for (int v = 0 ; v < table->rowV + 1 ; v++)	/* loop on rows							*/
			{
				r = table->row1 + v ;								/* row index				*/
				if (r >= table->rowN)
					break ;											/* table end				*/
				fillCB(hwnd, hdc, r, -1, NULL) ;					/* notify start of row		*/
				fcell.bottom = fcell.top + table->cellHeight ;		/* cell rectangle			*/

															/* check if it has to be painted	*/
				if (fcell.bottom <= ps.rcPaint.top || fcell.top >= ps.rcPaint.bottom)
				{
					fcell.top = fcell.bottom ;
					continue ;
				}

				int selectedRow = 0 ;
				if (sgl->context.dimmed == 0)
				{
					switch (table->selMode)
					{
						case 2 :
						case 1 :
							selectedRow = (r == table->selectR) ;
						case 0 :
							break ;
						case 3 :
							selectedRow = ((table->selectR - r) * (table->select2 - r) <= 0) ;
							break ;
					}
				}

				fcell.left = 0 ;
				for (c = 0 ; c < colN ; c++)				/* loop on columns					*/
				{
					fcell.right = fcell.left + colWidth(table, c) ;
															/* check if it has to be painted	*/
					if (fcell.right <= ps.rcPaint.left || fcell.left >= ps.rcPaint.right)
					{
						fcell.left = fcell.right ;
						continue ;
					}

					int selectedCol = 1 ;
					if ((table->selMode == 1) && (c != table->select2))
						selectedCol = 0 ;

					if (fcell.right >= 0)					/* the cell is visible				*/
					{
						int borders = (table->rowGrid ? 2 : 0)
									| (columns[c].cellNoRightSep ? 0 : 1) ;
						borders |= (c == 0 ? 4 : 0) |
								   (c == colN - 1 ? 1 : 0) |
								   (v == table->rowN - 1 ? 2 : 0) ;
						cell = fcell ;							/* cell content					*/
						cellFrame(table, hdc, &cell, borders, gridColor) ;

																/* update context for user draw	*/
						sgl->context.selected = (selectedRow && selectedCol) ;

						if (selectedRow && selectedCol)							
						{
							SetDCBrushColor(hdc, GetSysColor(COLOR_MENUHILIGHT)) ;
							SetTextColor(hdc, SGL_WHITE) ;
						}
						else
						{
							SetDCBrushColor(hdc, bgCell[c][r % 2]) ;
							SetTextColor(hdc, sgl->context.fgdColor) ;
						}
						FillRect(hdc, &cell, GetStockObject(DC_BRUSH)) ;
															
						fillCB(hwnd, hdc, r, c, &cell) ;			/* user draw				*/
					}
					fcell.left = fcell.right ;
					if (fcell.left > tableWidth) break ;
				}
				fcell.top = fcell.bottom ;
				fillCB(hwnd, NULL, r, -2, NULL) ;					/* notify end of row		*/
			}

			if (sgl->scrollBars[1])								/* if vertical scroll bar is on	*/
			{
				SetScrollRange(hwnd, SB_VERT, 0, max(1, row1Max), 1) ;
				SetScrollPos(hwnd, SB_VERT, table->row1, 1) ;
			}

			if (fcell.top < tableHeight)		/*---- paint background under the data ---------*/
			{
				fcell.bottom = tableHeight ;
				fcell.left = 0 ;
				SetDCBrushColor(hdc, sgl->context.bgdColor) ;
			    FillRect(hdc, &fcell, GetStockObject(DC_BRUSH)) ;
			}
			fillCB(hwnd, NULL, -1, -2, NULL) ;				/* notify end of paint				*/
			EndPaint(hwnd, &ps) ;
			result = 0 ;
			break ;
		}
	}
	return result ;
}
