int SGL__imageInit(void) ;
int SGL__imageNew(SGL_T *sgl) ;
void SGL__imageExit(void) ;
