int SGL__separatorInit(void) ;
int SGL__separatorNew(SGL_T *sgl) ;
void SGL__separatorExit(void) ;
