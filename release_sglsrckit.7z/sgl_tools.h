char *SGL_ProfileInit(char *fileName) ;
void SGL_ProfileStringGet(char *section, char *key, char *l, int size);
void SGL_ProfileStringSet(char *section, char *key, char *l);
int SGL_ProfileIntGet(char *section, char *key, int defValue);
int SGL_ProfileIntSet(char *section, char *key, int value, int hex);

COLORREF SGL_ColorDim(COLORREF color, int dimmed);
COLORREF SGL_ColorInterpolate(COLORREF color0, COLORREF color1, double k);

typedef void (*COLORS_CB)(int ix, COLORREF color) ;
int SGL_ColorsConfigure(char **colorKey, char *section, COLORS_CB colorCB) ;
void SGL_ColorsSet(void) ;
