/*================================================================================= SGL_IMAGE.C ==
SGL IMAGE class.

Under WindowsXP SP, multiframe TIFF are not visible (OK with Win7).

==================================================================================================
date       author			update
----       ------			------
14/06/..   h serindat		creation start
15/09/04					v1.0 - first release
15/09/29					minor update SGL__imageNew(): default args of CreateWindowEx()
16/01/11					v1.2 - winProc renamed sglProc to prevent confusion
================================================================================================*/

#include <wchar.h>
#include <math.h>
#include "sgl_base_.h"
#include "sgl_image.h"
#include "sgl_image_.h"
#include "sgl_gdiplus_.h"

#include <shlwapi.h>						/* required by SHCreateMemStream() in imageLoadRC()	*/
#pragma comment(lib, "shlwapi.lib")

typedef struct
{
	SGL_T *sgl ;
	PROPERTYITEM *propertyItem ;
	HANDLE exitEvent ;
	HANDLE hThread ;
	GP_GPIMAGE *gpImg ;
	GP_GPIMAGEATTRIBUTES *attr ;
	int fit ;
	GUID dimensionID ;
	int frameCount ;
	int frameIndex ;
	int speed100 ;
} SGL_IMAGE_T ;

/* debug condition */

#define DEBUG (sgl->debug ? STD : NONE)


/*============================================================================== GDI+ HANDLER ==*/


/*------------------------------------------------------------------------------- init & exit --*/

static ULONG_PTR gdiplusToken ;

static int sgimageInit(void)
{
	GDIPLUSSTARTUPINPUT gdiplusStartupInput = { 1, NULL, FALSE, FALSE } ;		/* no option!	*/

	int st = GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, NULL) ;
	return - st ;										/* return value is < 0 in case of error	*/
}

static void sgimageExit(void)
{
	GdiplusShutdown(gdiplusToken) ;
}

/*----------------------------------------------------------------------- Load & unload image --*/

static void createDimAttr(SGL_IMAGE_T *sgH)			/* should be compliant with SGL_ColorDim()	*/
{
	int dest = DIMCOLOR ;
	float matrix[5][5] =  { {0.3333, 0,      0,   0,   0},
							{0, 0.3333,      0,   0,   0},
							{0,      0, 0.3333,   0,   0},
							{0,      0,      0,   1,   0},
							{0,      0,      0,   0,   0} } ;
	matrix[4][0] = 0.002614F * GetRValue(dest) ;
	matrix[4][1] = 0.002614F * GetGValue(dest) ;
	matrix[4][2] = 0.002614F * GetBValue(dest) ;

	int e = GdipCreateImageAttributes(&(sgH->attr)) + 1 ;
	e = GdipSetImageAttributesColorMatrix(sgH->attr, 0, 1, matrix, NULL, 0) + 1 ;
	return ;
}

static GP_GPIMAGE* imageLoadRC(char *rName)					/* rName is a resource locator		*/
{															/* example ":RT_RCDATA:#8007"		*/
	GP_GPIMAGE *gpImg = NULL ;
	size_t l = strlen(rName++) ;
	char rscName[l] ;										/* resource name to extract			*/
	for (int i = 0 ; *rName ; i++, rName++)
	{
		rscName[i] = '\0' ;
		if (*rName == ':')
			break ;
		else
			rscName[i] = *rName ;
	}
	rName++ ;
	HRSRC resrc = FindResource(NULL, rName, rscName) ;
	int size = SizeofResource(NULL, resrc) ;
	LPVOID fByte = LockResource(LoadResource(NULL, resrc)) ;
	LPSTREAM lpstr = SHCreateMemStream(fByte, size) ; 
	GdipLoadImageFromStreamICM(lpstr, &gpImg) ; 
	return gpImg ;
}

static GP_GPIMAGE* imageLoadA(char *fName)
/*
	fName is either the name of an image file (ie. "beach.png") or a resource locator.
*/
{
	GP_GPIMAGE *gpImg = NULL ;

	if (fName[0] == ':')								/* case resource locator				*/
		gpImg = imageLoadRC(fName) ;
	else
	{
		size_t l = strlen(fName) + 1 ;
		wchar_t wName[2 * l] ;							/* convert fName to wide characters'	*/
		if (mbstowcs(wName, fName, l) < 1)
			return NULL ;
		GdipLoadImageFromFileICM(wName, &gpImg) ;
	}
	return gpImg ;
}

static GP_GPIMAGE* imageLoadW(wchar_t *fName)
/*
	fName is either the name of an image file (ie. "beach.png") or a resource locator.
*/
{
	GP_GPIMAGE *gpImg = NULL ;

	if (fName[0] == ':')								/* case resource locator				*/
	{
		size_t l = wcslen(fName) + 1 ;
		char aName[l] ;									/* convert fName to a multibyte string'	*/
		if (wcstombs(aName, fName, l) < 1)
			return NULL ;
		gpImg = imageLoadRC(aName) ;
	}
	else
		GdipLoadImageFromFileICM(fName, &gpImg) ;
	return gpImg ;
}

static void imageUnload(SGL_IMAGE_T *sgH)
{
	GdipDisposeImageAttributes(sgH->attr) ;
	GdipDisposeImage(sgH->gpImg) ;
}

/*-------------------------------------------------------------------------------- Image Size --*/
static int imageWidth(GP_GPIMAGE *gpImg)
{
	UINT width = 0 ;
	int e = GdipGetImageWidth(gpImg, &width) ;
	if (e) return - e ;								/* If the function fails, it result is <0	*/
	return width ;
}

static int imageHeight(GP_GPIMAGE *gpImg)
{
	UINT height = 0 ;
	int e = GdipGetImageHeight(gpImg, &height) ;
	if (e) return - e ;
	return height ;
}

/*-------------------------------------------------------------------------------- Draw image --*/
static int sgimagePaint(HDC hdc, RECT *rect, SGL_IMAGE_T *sgH)
/*
	This function is typically called in the windows's message loop (event WM_PAINT).
	
	If fit = 0, the image is not resized (cropped if too big).
	If fit = 1 and if too big, the image is shrinked to fit rectangle.
	If fit = 2 the image is resized (shrinked or enlarged) to fit the rectangle.
	In all cases, the image ratio is preserved.
*/
{
	GdipImageSelectActiveFrame(sgH->gpImg, &(sgH->dimensionID), sgH->frameIndex) ;

	int imgW = imageWidth(sgH->gpImg) ;							/* image size					*/
	int imgH = imageHeight(sgH->gpImg) ;
	if ((double) imgW * imgH == 0.0) return -2 ;				/* one dimension is null		*/
	
	int rectW = rect->right - rect->left ;						/* rectangle size				*/
	int rectH = rect->bottom - rect->top ;

	int destW = imgW, destH = imgH ;								/* destination size				*/

	if (sgH->fit > 0)
	{
		if ((double) rectW * rectH == 0.0) return -2 ;			/* one dimension is null		*/
		double ratio ;

		ratio = fmin((double) rectW / imgW, (double) rectH / imgH) ;
		if (sgH->fit > 1 && ratio > 1.0)		/* if fit > 1 and image is smaller: expand it	*/
		{
			destW = (int) (imgW * ratio) ;
			destH = (int) (imgH * ratio) ;
		}

		ratio = fmax((double) imgW / rectW, (double) imgH / rectH) ;
		if (ratio > 1.0)						/* if fit > 0 and image is bigger: shrink it	*/
		{
			destW = (int) (imgW / ratio) ;
			destH = (int) (imgH / ratio) ;
		}
	}

	int destX = rect->left + (rectW - destW) / 2 ;				/* horizontal centering			*/
	int destY = rect->top  + (rectH - destH) / 2 ;				/* vertical   centering			*/

	GP_GPGRAPHICS *graphx ;
	int e = GdipCreateFromHDC(hdc, &graphx) ;
	if (e)
		return - e ;

	GdipDrawImageRectRectI(graphx, sgH->gpImg,
							destX, destY, destW, destH, 		/* destination					*/
							0, 0, imgW, imgH,					/* source						*/
							2, (sgH->sgl->context.dimmed) ? sgH->attr : NULL, NULL, NULL) ;
	GdipDeleteGraphics(graphx) ;

	return - e ;
}


/*================================================================ FUNCTIONS FOR ANIMATED GIF ==*/

/*----------------------------------------------------------------------------------------------*/
static DWORD WINAPI threadAnimation(void *p)
{
	SGL_IMAGE_T *sgH = (SGL_IMAGE_T*) p ;
	HWND hwnd = sgH->sgl->hwnd ;
	sgH->frameIndex = 0 ;
	for ( ; sgH ; )
	{
		HDC hdc = GetDC(hwnd);
		if (hdc)
		{
			RECT rect ;
			GetClientRect(hwnd, &rect) ;
			sgimagePaint(hdc, &rect, sgH) ;
			ReleaseDC(hwnd, hdc);
		}

		sgH->frameIndex++ ;
		if (sgH->frameIndex >= sgH->frameCount)
			sgH->frameIndex = 0 ;
		DWORD lPause ;
		if (sgH->propertyItem)								/* GIF frame delay unit is 1/100 s	*/
			lPause = ((long*) sgH->propertyItem->value)[sgH->frameIndex] ;
		else
			lPause = 100 ;
		lPause  *= 1000.0 / sgH->speed100 ;							/* convert to ms			*/
		if (WAIT_OBJECT_0 == WaitForSingleObject(sgH->exitEvent, lPause))
			break ;
	}
	free(sgH->propertyItem) ;
	ExitThread(0) ;
	return 0 ;
}

/*----------------------------------------------------------------------------------------------*/
static unsigned int frameCount(GP_GPIMAGE *gpImg, GUID *dimensionID, PROPERTYITEM **frameDelays)
{
	GUID guid ;
	int e = GdipGetImageRawFormat(gpImg, &guid) ;
	if (e) return - e ;

	unsigned int count = 0;						/* number of frames in the first dimension		*/
	*frameDelays = NULL ;

	e = GdipImageGetFrameDimensionsList(gpImg, dimensionID, 1) ;
	if (e) return 0 ;
	e = GdipImageGetFrameCount(gpImg, dimensionID, &count) ;
	if (e) return 0 ;

	unsigned int size ;							/* allocate frameDelays							*/
	e = GdipGetPropertyItemSize(gpImg, PropertyTagFrameDelay, &size) ;
	if (e) return count ;
	*frameDelays = (PROPERTYITEM*) malloc(size) ;
	if (frameDelays == NULL)
		return - 3 ;													/* eOutOfMemory			*/
	e = GdipGetPropertyItem(gpImg, PropertyTagFrameDelay, size, *frameDelays) ;
	if (e) return count ;
	return count ;
}


/*======================================================================== EXPORTED FUNCTIONS ==*/

/*----------------------------------------------------------------------------------------------*/
int SGL__imageInit(void) { return sgimageInit() ; }
void SGL__imageExit(void) { sgimageExit() ; }

/*========================================================================= SET/GET FUNCTIONS ==*/

#define CHECK_OBJ(h, g)		SGL_T* _sgl = SGL__getStruct(h) ;								\
							if (_sgl == NULL)					return SGL_ERR_PARM - 0 ;	\
							if (_sgl->type != SGL_CTRL_IMAGE)	return SGL_ERR_TYPE ;		\
							SGL_IMAGE_T *g = _sgl->ex ;										\
							if (g == NULL)						return SGL_ERR_INT ;

int SGL_ImageLoad(HWND hwnd, char* fileName)
{
	CHECK_OBJ(hwnd, img) ;
	img->frameCount = img->frameIndex = 0 ;
	img->hThread = img->exitEvent = NULL ;

	img->gpImg = imageLoadA(fileName) ;
	if (img->gpImg == NULL)
		return SGL_ERR_PARM - 1 ;								/* could not load image			*/

	img->frameCount = frameCount(img->gpImg, &(img->dimensionID), &(img->propertyItem)) ;
	if (img->gpImg && img->frameCount > 1)
	{
		img->hThread = CreateThread(NULL, 0, threadAnimation, img, 
									CREATE_SUSPENDED, NULL) ;
		img->exitEvent = CreateEvent(NULL, TRUE, FALSE, NULL) ;
	}
	createDimAttr(img) ;
	return 0 ;
}

int SGL_ImageLoadW(HWND hwnd, wchar_t* fileName)				/* unpublished function !!	*/
{
	CHECK_OBJ(hwnd, img) ;
	img->frameCount = img->frameIndex = 0 ;
	img->hThread = img->exitEvent = NULL ;

	img->gpImg = imageLoadW(fileName) ;
	if (img->gpImg == NULL)
		return SGL_ERR_ALLOC ;									/* could not load image			*/
	img->frameCount = frameCount(img->gpImg, &(img->dimensionID), &(img->propertyItem)) ;
	if (img->gpImg && img->frameCount > 1)
	{
		img->hThread = CreateThread(NULL, 0, threadAnimation, img, 
									CREATE_SUSPENDED, NULL) ;
		img->exitEvent = CreateEvent(NULL, TRUE, FALSE, NULL) ;
	}
	createDimAttr(img) ;
	return 0 ;
}

int SGL_ImageUnload(HWND hwnd)
{
	CHECK_OBJ(hwnd, img) ;
	if (img->hThread)
	{
		SetEvent(img->exitEvent) ;							/* require thread exit				*/
		int suspend = 1 ; while (suspend)					/* resume thread if suspended		*/
			suspend = ResumeThread(img->hThread) ;
		WaitForSingleObject(img->hThread, 200) ;			/* wait for the thread to terminate	*/
		CloseHandle(img->exitEvent) ;						/* free internal resources			*/
		CloseHandle(img->hThread) ;
		img->hThread = NULL ;
	}
	imageUnload(img) ;
	return 0 ;
}

int SGL_ImageFittingSet(HWND hwnd, int fit)
{
	CHECK_OBJ(hwnd, img) ;
	if (fit < 0 || fit > 2)
		return SGL_ERR_PARM - 1 ;
	img->fit = fit ;
	return 0 ;
}

int SGL_ImageFittingGet(HWND hwnd)
{
	CHECK_OBJ(hwnd, img) ;
	return img->fit ;
}

int SGL_ImageFrameIndexSet(HWND hwnd, int frameIndex)
{
	CHECK_OBJ(hwnd, img) ;
	if (frameIndex < 0 || frameIndex >= img->frameCount)
		return SGL_ERR_PARM - 1 ;
	img->frameIndex = frameIndex ;
	return 0 ;
}

int SGL_ImageFrameIndexGet(HWND hwnd)
{
	CHECK_OBJ(hwnd, img) ;
	return img->frameIndex ;
}

int SGL_ImageFrameCountGet(HWND hwnd)
{
	CHECK_OBJ(hwnd, img) ;
	return img->frameCount ;
}

int SGL_ImagePlay(HWND hwnd, int speed100)
{
	CHECK_OBJ(hwnd, img) ;
	img->speed100 = speed100 ;
	if (img->hThread && img->speed100 > 0)
	{
		int suspend = 1 ;
		while (suspend)										/* decrement the suspend count		*/
			suspend = ResumeThread(img->hThread) ;						/*  down to 0			*/
	}
	else
		SuspendThread(img->hThread) ;
	return 0 ;
}


/*================================================================== EXPORTED LOCAL FUNCTIONS ==*/

static int parmIgnore(SGL_T *sgl, int check, int dum)
{
	if (check == CHECK_BORDERSTYLE || check == CHECK_BORDERTHICKNESS)
		return 1 ;
	return 0 ;
}

/*----------------------------------------------------------------------------------------------*/
static void imageResize(SGL_T *sgl)						/* resize an image						*/
{
	for (size_t i = 0 ; i < 2 ; i++)					/* 0: horizontal, 1: vertical			*/
	{
		int l = SIZE(sgl->uSize[i]) ;						/* width or heigth					*/

		if (l == 0)
		{
			SGL_IMAGE_T *sgH = sgl->ex ;
			l = i ? imageHeight(sgH->gpImg) : imageWidth(sgH->gpImg) ;
			if (l < 0)										/* case image is not loaded			*/
				l = 150 ;
		}
		if (sgl->scrollBars[1 - i])							/* add non client objects			*/
			l += GetSystemMetrics(i ? SM_CXHSCROLL : SM_CXVSCROLL) ;

		RECT_SETWH(i, sgl->rect, l)							/* store dimension					*/
	}
}

/*----------------------------------------------------------------------------------------------*/
static LRESULT imageProc(HWND hwnd, SGL_T *sgl, UINT message, WPARAM wParam, LPARAM lParam)
{
	LRESULT result = DEFPROC ;						/* default result: no message processed		*/

	switch (message)
	{
		case WM_PAINT :	
		{
			PAINTSTRUCT ps ;
			HDC hdc = BeginPaint(hwnd, &ps) ;
			 
			RECT rct ;										/* painting area					*/
			GetClientRect(hwnd, &rct) ;

			RECT rect ; GetClientRect(hwnd, &rect) ;		/* paint background					*/
			SetDCBrushColor(hdc, sgl->context.bgdColor) ;
		    FillRect(hdc, &rect, GetStockObject(DC_BRUSH)) ;

			sgimagePaint(hdc, &rct, (SGL_IMAGE_T*) sgl->ex) ;
			EndPaint(hwnd, &ps) ;
			result = 0 ;
			break ;
		}
	}
	return result ;
}

/*----------------------------------------------------------------------------------------------*/
int SGL__imageNew(SGL_T *sgl)								/* create a new image				*/
{
	if (sgl->type != SGL_CTRL_IMAGE) return SGL_ERR_TYPE ;
	if (sgl->hwndParent == NULL)	 return SGL_ERR_PARM - 0 ;	/* parent must exist			*/

	NEW(SGL_IMAGE_T, sgH) ;
	if (sgl->ex)											/* case duplicate					*/
	{
		sgH->fit		= ((SGL_IMAGE_T*) sgl->ex)->fit ;
		sgH->speed100	= ((SGL_IMAGE_T*) sgl->ex)->speed100 ;
	}
	else													/* case new							*/
	{
		sgl->typeName = "IMAGE" ;
		sgl->parmIgnore = parmIgnore ;							/* check for std attributes	*/
		sgl->resizeObj = imageResize ;
		sgl->sglProc = imageProc ;

		sgH->fit = 1 ;											/* default: shrink if too big	*/
	}

	sgl->ex = sgH ;
	sgH->sgl = sgl ;

	sgl->hwnd = CreateWindowEx(0, MAINCLASSNAME, sgl->title, sgl->winStyle | sgl->uStyle,
							    0, 0, 0, 0,
							    sgl->hwndParent, (HMENU) 0, SGL__instance, NULL) ;
	if (sgl->hwnd == NULL)
		return SGL_ERR_ALLOC ;

	return 0 ;
}
