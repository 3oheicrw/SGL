/*================================================================================= SGL_DEBUG.C ==
Debugging tools.
==================================================================================================
date       author			update
----       ------			------
14/06/..   h serindat		creation start
15/09/04					v1.0 first release
16/01/11					v1.2 SGL_Trace() updated, more details for WM_NOTIFY messages
16/07/06					v1.3 FATAL messages do not require the console any more
20/04/04					v1.3.5 SGL_Error(): bug corrected (case eresult < -6)
================================================================================================*/

#include <windows.h>
#include <stdio.h>
#include <conio.h>
#include "sgl_debug_.h"
#include "sgl_debug.h"

#define BEEP if (_cprintf("%s", "") >= 0) \
				MessageBeep(MB_ICONEXCLAMATION) ;

static char *fileName(char *fullPath)					/* returns a pointer on the file name	*/
{
	char *file = strrchr(fullPath, '\\') ;
	return file ? file + 1 : fullPath ;
}

void SGL_Fatal(char *file, int line, char *diag)
{
	if (line > 0)
		SGL_Log(FATAL, "%s - line %d - %s", fileName(file), line, diag) ;
	else
		SGL_Log(FATAL, "%s - %s", file, diag) ;
}

void SGL_Error(char *file, int line, int eresult)
{
	if (eresult >= 0)
		return ;
	char *label ;
	switch (eresult)
	{
		case -1 :	label = "INTERNAL FAILURE"	; break ;
		case -2 :	label = "ALLOCATION ERROR"	; break ;
		case -3 :	label = "WRONG TYPE"		; break ;

		case -4 :	label = "WRONG 1ST PARAMETER"	; break ;
		case -5 :	label = "WRONG 2ND PARAMETER"	; break ;
		case -6 :	label = "WRONG 3RD PARAMETER"	; break ;
		default :
		{
			char m[64] ;
			sprintf(m, "WRONG %dTH PARAMETER", - eresult -3) ;
			label = m ;
		}
	}
	if (line > 0)
		SGL_Log(ERR, "%s - line %d - %s", fileName(file), line, label) ;
	else
		SGL_Log(ERR, "%s - %s", file, label) ;
}

/*----------------------------------------------------------------------------------------------*/
void SGL_Log(int mask, char *fmt,...)			/* show std, warning, error or fatal message	*/
/*----------------------------------------------------------------------------------------------*/
{
	char head[32], body[224] ;					/* buffers for the message head and body		*/
	va_list ap ;

	if (mask == NONE) return ;

	switch (mask)
	{
		case ERR :
			BEEP ;													 
			strncpy(head, "** ERROR ** ", NELEMS(head) - 1) ;
			break ;

		case QUIT :
			strcpy(head, "\n") ;
			break ;

		case FATAL :
			BEEP ;
			break ;
			
		default :										/* no head								*/
			head[0] = '\0' ;
	}

	va_start(ap, fmt) ;									/* build the error message				*/
	vsnprintf(body, NELEMS(body) - 1, fmt, ap) ;
	va_end(ap) ;

	if (mask == FATAL)
		FatalAppExit(0, body) ;
	
	_cprintf("%s", head) ;
	_cprintf("%s", body) ;
	_cprintf("\n") ;

	if (mask == QUIT)
	{
		_cprintf("%s", "\nHit a key to quit") ;
		while (_kbhit()) ;
		while (_kbhit() == 0) ;
		exit(0) ;
	}
}

#define CASE(m, l) case l: m = #l ; break ;

void SGL__trace(const char func[], HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)												/* ignored messages			*/
	{
		case WM_NCMOUSEMOVE :
		case WM_MOUSEMOVE :
		case WM_SETCURSOR :
		case WM_NCHITTEST :
			return ;
	}

	char *m, unk[64] ;

	switch (message)
	{
		case WM_NOTIFY :
		{
			m = "WM_NOTIFY" ;
			NMHDR *ns = (NMHDR*) lParam ;
			sprintf(unk, "%08X", ns->code) ;
			SGL_Log(STD, "%-16s HWND:0x%P  %+18s  code:%s      from:%P", 
						  func, hwnd, m, unk, ns->hwndFrom) ;
			return ;
		}
	}

	switch (message)
	{
		CASE(m, WM_NULL)
		CASE(m, WM_CREATE)
		CASE(m, WM_DESTROY)
		CASE(m, WM_MOVE)
		CASE(m, WM_SIZE)
		CASE(m, WM_ACTIVATE)
		CASE(m, WM_SETFOCUS)
		CASE(m, WM_KILLFOCUS)
		CASE(m, WM_ENABLE)
		CASE(m, WM_SETREDRAW)
		CASE(m, WM_SETTEXT)
		CASE(m, WM_GETTEXT)
		CASE(m, WM_GETTEXTLENGTH)
		CASE(m, WM_PAINT)
		CASE(m, WM_CLOSE)
		CASE(m, WM_QUERYENDSESSION)
		CASE(m, WM_QUERYOPEN)
		CASE(m, WM_ENDSESSION)
		CASE(m, WM_QUIT)
		CASE(m, WM_ERASEBKGND)
		CASE(m, WM_SYSCOLORCHANGE)
		CASE(m, WM_SHOWWINDOW)
		CASE(m, WM_WININICHANGE)
		CASE(m, WM_DEVMODECHANGE)
		CASE(m, WM_ACTIVATEAPP)
		CASE(m, WM_FONTCHANGE)
		CASE(m, WM_TIMECHANGE)
		CASE(m, WM_CANCELMODE)
		CASE(m, WM_SETCURSOR)
		CASE(m, WM_MOUSEACTIVATE)
		CASE(m, WM_CHILDACTIVATE)
		CASE(m, WM_QUEUESYNC)
		CASE(m, WM_GETMINMAXINFO)
		CASE(m, WM_PAINTICON)
		CASE(m, WM_ICONERASEBKGND)
		CASE(m, WM_NEXTDLGCTL)
		CASE(m, WM_SPOOLERSTATUS)
		CASE(m, WM_DRAWITEM)
		CASE(m, WM_MEASUREITEM)
		CASE(m, WM_DELETEITEM)
		CASE(m, WM_VKEYTOITEM)
		CASE(m, WM_CHARTOITEM)
		CASE(m, WM_SETFONT)
		CASE(m, WM_GETFONT)
		CASE(m, WM_SETHOTKEY)
		CASE(m, WM_GETHOTKEY)
		CASE(m, WM_QUERYDRAGICON)
		CASE(m, WM_COMPAREITEM)
		CASE(m, WM_GETOBJECT)
		CASE(m, WM_COMPACTING)
		CASE(m, WM_COMMNOTIFY)
		CASE(m, WM_WINDOWPOSCHANGING)
		CASE(m, WM_WINDOWPOSCHANGED)
		CASE(m, WM_POWER)
		CASE(m, WM_COPYDATA)
		CASE(m, WM_CANCELJOURNAL)
		CASE(m, WM_NOTIFY)
		CASE(m, WM_INPUTLANGCHANGEREQUEST)
		CASE(m, WM_INPUTLANGCHANGE)
		CASE(m, WM_TCARD)
		CASE(m, WM_HELP)
		CASE(m, WM_USERCHANGED)
		CASE(m, WM_NOTIFYFORMAT)
		CASE(m, WM_CONTEXTMENU)
		CASE(m, WM_STYLECHANGING)
		CASE(m, WM_STYLECHANGED)
		CASE(m, WM_DISPLAYCHANGE)
		CASE(m, WM_GETICON)
		CASE(m, WM_SETICON)
		CASE(m, WM_NCCREATE)
		CASE(m, WM_NCDESTROY)
		CASE(m, WM_NCCALCSIZE)
		CASE(m, WM_NCHITTEST)
		CASE(m, WM_NCPAINT)
		CASE(m, WM_NCACTIVATE)
		CASE(m, WM_GETDLGCODE)
		CASE(m, WM_SYNCPAINT)
		CASE(m, WM_NCMOUSEMOVE)
		CASE(m, WM_NCLBUTTONDOWN)
		CASE(m, WM_NCLBUTTONUP)
		CASE(m, WM_NCLBUTTONDBLCLK)
		CASE(m, WM_NCRBUTTONDOWN)
		CASE(m, WM_NCRBUTTONUP)
		CASE(m, WM_NCRBUTTONDBLCLK)
		CASE(m, WM_NCMBUTTONDOWN)
		CASE(m, WM_NCMBUTTONUP)
		CASE(m, WM_NCMBUTTONDBLCLK)
		CASE(m, WM_NCXBUTTONDOWN)
		CASE(m, WM_NCXBUTTONUP)
		CASE(m, WM_NCXBUTTONDBLCLK)
		CASE(m, WM_INPUT)
		CASE(m, WM_KEYDOWN)
		CASE(m, WM_KEYUP)
		CASE(m, WM_CHAR)
		CASE(m, WM_DEADCHAR)
		CASE(m, WM_SYSKEYDOWN)
		CASE(m, WM_SYSKEYUP)
		CASE(m, WM_SYSCHAR)
		CASE(m, WM_SYSDEADCHAR)
		CASE(m, WM_UNICHAR)
		CASE(m, WM_IME_STARTCOMPOSITION)
		CASE(m, WM_IME_ENDCOMPOSITION)
		CASE(m, WM_IME_COMPOSITION)
		CASE(m, WM_INITDIALOG)
		CASE(m, WM_COMMAND)
		CASE(m, WM_SYSCOMMAND)
		CASE(m, WM_TIMER)
		CASE(m, WM_HSCROLL)
		CASE(m, WM_VSCROLL)
		CASE(m, WM_INITMENU)
		CASE(m, WM_INITMENUPOPUP)
		CASE(m, WM_GESTURE)
		CASE(m, WM_GESTURENOTIFY)
		CASE(m, WM_MENUSELECT)
		CASE(m, WM_MENUCHAR)
		CASE(m, WM_ENTERIDLE)
		CASE(m, WM_MENURBUTTONUP)
		CASE(m, WM_MENUDRAG)
		CASE(m, WM_MENUGETOBJECT)
		CASE(m, WM_UNINITMENUPOPUP)
		CASE(m, WM_MENUCOMMAND)
		CASE(m, WM_CHANGEUISTATE)
		CASE(m, WM_UPDATEUISTATE)
		CASE(m, WM_QUERYUISTATE)

		CASE(m, WM_CTLCOLORMSGBOX)
		CASE(m, WM_CTLCOLOREDIT)
		CASE(m, WM_CTLCOLORLISTBOX)
		CASE(m, WM_CTLCOLORBTN)
		CASE(m, WM_CTLCOLORDLG)
		CASE(m, WM_CTLCOLORSCROLLBAR)
		CASE(m, WM_CTLCOLORSTATIC)

		CASE(m, WM_MOUSEMOVE)
		CASE(m, WM_LBUTTONDOWN)
		CASE(m, WM_LBUTTONUP)
		CASE(m, WM_LBUTTONDBLCLK)
		CASE(m, WM_RBUTTONDOWN)
		CASE(m, WM_RBUTTONUP)
		CASE(m, WM_RBUTTONDBLCLK)
		CASE(m, WM_MBUTTONDOWN)
		CASE(m, WM_MBUTTONUP)
		CASE(m, WM_MBUTTONDBLCLK)
		CASE(m, WM_MOUSEWHEEL)
		CASE(m, WM_XBUTTONDOWN)
		CASE(m, WM_XBUTTONUP)
		CASE(m, WM_XBUTTONDBLCLK)
		CASE(m, WM_MOUSEHWHEEL)
		CASE(m, WM_PARENTNOTIFY)
		CASE(m, WM_ENTERMENULOOP)
		CASE(m, WM_EXITMENULOOP)

		CASE(m, WM_NEXTMENU)
		CASE(m, WM_SIZING)
		CASE(m, WM_CAPTURECHANGED)
		CASE(m, WM_MOVING)

		CASE(m, WM_POWERBROADCAST)
		CASE(m, WM_DEVICECHANGE)
		CASE(m, WM_MDICREATE)
		CASE(m, WM_MDIDESTROY)
		CASE(m, WM_MDIACTIVATE)
		CASE(m, WM_MDIRESTORE)
		CASE(m, WM_MDINEXT)
		CASE(m, WM_MDIMAXIMIZE)
		CASE(m, WM_MDITILE)
		CASE(m, WM_MDICASCADE)
		CASE(m, WM_MDIICONARRANGE)
		CASE(m, WM_MDIGETACTIVE)
		CASE(m, WM_MDISETMENU)
		CASE(m, WM_ENTERSIZEMOVE)
		CASE(m, WM_EXITSIZEMOVE)
		CASE(m, WM_DROPFILES)
		CASE(m, WM_MDIREFRESHMENU)
		CASE(m, WM_TOUCH)
		CASE(m, WM_IME_SETCONTEXT)
		CASE(m, WM_IME_NOTIFY)
		CASE(m, WM_IME_CONTROL)
		CASE(m, WM_IME_COMPOSITIONFULL)
		CASE(m, WM_IME_SELECT)
		CASE(m, WM_IME_CHAR)
		CASE(m, WM_IME_REQUEST)
		CASE(m, WM_IME_KEYDOWN)
		CASE(m, WM_IME_KEYUP)
		CASE(m, WM_MOUSEHOVER)
		CASE(m, WM_MOUSELEAVE)
		CASE(m, WM_NCMOUSEHOVER)
		CASE(m, WM_NCMOUSELEAVE)
		CASE(m, WM_WTSSESSION_CHANGE)
		CASE(m, WM_TABLET_FIRST)
		CASE(m, WM_TABLET_LAST)
		CASE(m, WM_CUT)
		CASE(m, WM_COPY)
		CASE(m, WM_PASTE)
		CASE(m, WM_CLEAR)
		CASE(m, WM_UNDO)
		CASE(m, WM_RENDERFORMAT)
		CASE(m, WM_RENDERALLFORMATS)
		CASE(m, WM_DESTROYCLIPBOARD)
		CASE(m, WM_DRAWCLIPBOARD)
		CASE(m, WM_PAINTCLIPBOARD)
		CASE(m, WM_VSCROLLCLIPBOARD)
		CASE(m, WM_SIZECLIPBOARD)
		CASE(m, WM_ASKCBFORMATNAME)
		CASE(m, WM_CHANGECBCHAIN)
		CASE(m, WM_HSCROLLCLIPBOARD)
		CASE(m, WM_QUERYNEWPALETTE)
		CASE(m, WM_PALETTEISCHANGING)
		CASE(m, WM_PALETTECHANGED)
		CASE(m, WM_HOTKEY)
		CASE(m, WM_PRINT)
		CASE(m, WM_PRINTCLIENT)
		CASE(m, WM_APPCOMMAND)
		CASE(m, WM_THEMECHANGED)
		CASE(m, WM_CLIPBOARDUPDATE)
		CASE(m, WM_DWMCOMPOSITIONCHANGED)
		CASE(m, WM_DWMNCRENDERINGCHANGED)
		CASE(m, WM_DWMCOLORIZATIONCOLORCHANGED)
		CASE(m, WM_DWMWINDOWMAXIMIZEDCHANGE)
		CASE(m, WM_DWMSENDICONICTHUMBNAIL)
		CASE(m, WM_DWMSENDICONICLIVEPREVIEWBITMAP)
		CASE(m, WM_GETTITLEBARINFOEX)

		CASE(m, WM_HANDHELDFIRST)
		CASE(m, WM_HANDHELDLAST)
		CASE(m, WM_AFXFIRST)
		CASE(m, WM_AFXLAST)
		CASE(m, WM_PENWINFIRST)
		CASE(m, WM_PENWINLAST)
		CASE(m, WM_APP)
		CASE(m, WM_USER)

		default:
			sprintf(unk, "?? %04X", message) ;
			m = unk ;
	}
	SGL_Log(STD, "%-16s HWND:0x%P  %+18s  wP:%P  lP:%P", func, hwnd, m, wParam, lParam) ;
}
