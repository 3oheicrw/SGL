int SGL__openglInit(void) ;
int SGL__openglNew(SGL_T *sgl) ;
void SGL__openglExit(void) ;
