int SGL__graphInit(void) ;
int SGL__graphNew(SGL_T *sgl) ;
void SGL__graphExit(void) ;
