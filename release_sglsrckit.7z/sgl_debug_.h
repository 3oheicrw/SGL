void SGL__trace(const char func[], HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam) ;

#ifdef __POCC__
	#pragma warn(disable: 2118 2216)	/* disable some warnings				*/
				/* 2118: Parameter {parameter_name} is not referenced.			*/
				/* 2216: The return value from {function_name} is never used.	*/
#endif
