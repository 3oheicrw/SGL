/*======================================================================================= SGL.C ==
SGL main core functions

The header files are:
  - sgl_base.h	for public functions (availabe to the application programmer)
  - sgl_base_.h	for SGL exclusive use 

==================================================================================================
date       author			update
----       ------			------
14/06/..   h serindat		creation start
15/09/04					v1.0 - first release
15/09/28					v1.1 - the normal font is the Windows menu font
								   new function SGL_RefSizeGet()
							       new macros in sgl_base.h: SGL_xBUTTON
16/01/11					v1.2 - winProc renamed sglProc to prevent confusion
16/03/16					v1.3 - SGL_Redraw also redraw the non client area
								 - SGL_ColorInperpolate renamed SGL_ColorInterpolate
								   now accept system colors
16/03/03					v1.3 - Default font for symbols
16/07/06					       SGL_Init() is now a void function (errors processed internally)
                                              it initialize automatically the in file
							       load/save size & position (cf. SGL_LayoutConfigure())
							       update of internal tools
16/07/17					       update for Windows10 compatibility
16/07/29					       SGL_Destroy(): now uses SendMessage(..WM_CLOSE..) ;
16/08/02					       sglFontInit(): HDC does not require a window
16/10/08					       SGL_FontLoad(): new function
16/11/18					v1.3.. new function regGetValue() for compatibility from XP to win10
18/07/22					v1.3.2 defaultFontGet() now uses the message font
20/04/04					v1.3.5 SGL_ParentGet(): never used, removed (use Win32 GetParent)
								   mouseWheelRouting is now static (not used outside)
================================================================================================*/

#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "gdi32.lib")
#include <windows.h>
#include <windowsx.h>
#include <fcntl.h>
#include <io.h>
#include <stdio.h>
#if __POCC_DEBUG__ > 0
	#include <conio.h>
#endif
#include "sgl_base_.h"
#include "sgl_objects_.h"

/* local functions */

static DWORD regGetValue(HKEY hkey, char* lpSubKey, char* lpValue, void* data, LPDWORD size) ;
static int sglFontInit(char faceNames[NFONTOPTION][LF_FACESIZE], int *fontSizes) ;
LRESULT CALLBACK SGL__WinProc(HWND hwnd, UINT event, WPARAM wParam, LPARAM lParam) ;

/* global debug condition */

#define DEBUG		(SGLdebug ? STD : NONE)

/* global data */

static int SGL__fontSize[NFONTSIZE] ;
static int SGL__fontHeight[NFONTOPTION][NFONTSIZE] ;
static HFONT SGL__font[NFONTOPTION][NFONTSIZE] ;

HINSTANCE SGL__instance = NULL ;
int SGL_refSize, SGL_defPad ;
int SGLdebug ;
static DWORD mouseWheelRouting ;							/* Windows10 status (registry)		*/

/* local data */

static char SGL__fontFace[NFONTOPTION][LF_FACESIZE] ;


/*=================================================================== INITIALIZATION AND EXIT ==*/

/*----------------------------------------------------------------------------------------------*/
void SGL_Init(HINSTANCE hInstance, char *iconRsc)
{
	atexit(SGL_Exit) ;

	if (SGL__instance == NULL)
	{												/*==== CLASS INIT (once) ===================*/
		SGL__instance = hInstance ;								/* set SGL__instance			*/

		WNDCLASS wndclass = 									/* register class				*/
		{
			.style         = CS_DBLCLKS | CS_HREDRAW | CS_VREDRAW | CS_OWNDC,
			.lpfnWndProc   = SGL__WinProc,
			.cbClsExtra    = 0,
			.cbWndExtra    = 0,
			.hInstance     = hInstance,
			.hIcon         = LoadIcon(hInstance, iconRsc),
			.hCursor       = LoadCursor (NULL, IDC_ARROW),
			.hbrBackground = NULL,
			.lpszMenuName  = NULL,
			.lpszClassName = MAINCLASSNAME
		} ;

		if (!RegisterClass(&wndclass))
			FatalAppExit(0, "SGL_Init - RegisterClass") ;		/* case error					*/

		SGL_ProfileInit("") ;									/* default iniialization file	*/

		DWORD size = sizeof(mouseWheelRouting) ;				/* windows10 specific			*/
//		if (RegGetValue(HKEY_CURRENT_USER, "Control Panel\\Desktop", "MouseWheelRouting", 
//					RRF_RT_REG_DWORD, NULL, &mouseWheelRouting, &size) != ERROR_SUCCESS)
		if (regGetValue(HKEY_CURRENT_USER, "Control Panel\\Desktop", "MouseWheelRouting", 
					&mouseWheelRouting, &size) != REG_DWORD)	/* if DWORD value not found		*/
			mouseWheelRouting = 0 ;
		else
			mouseWheelRouting = mouseWheelRouting > 1 ? 1 : 0 ;
		_cprintf("MouseWheelRouting = %d\n", mouseWheelRouting) ;
	}

	if (sglFontInit(NULL, NULL))								
			FatalAppExit(0, "SGL_Init - sglFontInit") ;
	if (SGL__objectsInit())
			FatalAppExit(0, "SGL_Init - SGL__objectsInit") ;
}

/*----------------------------------------------------------------------------------------------*/
static void defaultFontGet(LOGFONT *defFont)
/*----------------------------------------------------------------------------------------------*/
{
	NONCLIENTMETRICS ncm ;
	LOGFONT *fnt = &(ncm.lfMessageFont) ;

	ncm.cbSize = sizeof(ncm) ;
	int e = SystemParametersInfo(SPI_GETNONCLIENTMETRICS, ncm.cbSize, &ncm, 0) ;

	if (e == 0)							/* for old Windows version - cf Microsoft documentation	*/
	{
		ncm.cbSize -= 4 ;
		e = SystemParametersInfo(SPI_GETNONCLIENTMETRICS, ncm.cbSize, &ncm, 0) ;
	}

	if (e == 0)							/* if something is still wrong							*/
	{
		memset((void*) fnt, 0, sizeof(LOGFONT)) ;				/* defaults	values				*/
		fnt->lfHeight = - 11 ;
		fnt->lfCharSet = DEFAULT_CHARSET ;
		fnt->lfWeight = FW_NORMAL ;
		strcpy(fnt->lfFaceName, "Tahoma") ;
	}

	memcpy(defFont, fnt, sizeof(LOGFONT)) ;
}

/*----------------------------------------------------------------------------------------------*/
static int sglFontInit(char faceNames[NFONTOPTION][LF_FACESIZE], int fontSizes[NFONTSIZE])
/*------------------------------------------------------------------------------------------------
	faceName		face names														input
	fontSizes		font sizes for small, normal, large and big fonts				input
					a positive value is a magnifier factor
						for SGL_FONT_NORMAL the reference size is the system default
						for other sizes the reference size is the SGL_FONT_NORMAL size
					a negative value is interpreted as a font size

The normal result of the function is 0, or a negative value in case of error.

Note:
	a null array resets to default values
	a null element (or empty string) means no change
	this function also reinitialize the SGL objects
------------------------------------------------------------------------------------------------*/
{
	LOGFONT fnt ; defaultFontGet(&fnt) ;			/* get system font							*/
	int i ;

	static int sizes[NFONTSIZE] ;
	if (fontSizes == NULL)											/* default values			*/
	{
		sizes[SGL_FONT_SMALL]  =  82 ;
		sizes[SGL_FONT_NORMAL] = 100 ;
		sizes[SGL_FONT_LARGE]  = 135 ;
		sizes[SGL_FONT_BIG]    = 185 ;
		SGL_defPad = - 29 ;
	}
	else for (i = 0 ; i < NFONTSIZE ; i++)
	{
		if (fontSizes[i])											/* if 0: no change			*/
			sizes[i] = fontSizes[i] ;
	}

	if (faceNames == NULL)											/* default values			*/
	{
		strncpy(SGL__fontFace[SGL_FONT_FIXED],  "Lucida console",  LF_FACESIZE - 1) ;
		strncpy(SGL__fontFace[SGL_FONT_NORMAL], fnt.lfFaceName,    LF_FACESIZE - 1) ;
		strncpy(SGL__fontFace[SGL_FONT_BOLD],   fnt.lfFaceName,    LF_FACESIZE - 1) ;
		strncpy(SGL__fontFace[SGL_FONT_ITALIC], fnt.lfFaceName,    LF_FACESIZE - 1) ;
		strncpy(SGL__fontFace[SGL_FONT_SYMBOL], "WingDings",       LF_FACESIZE - 1) ;
		strncpy(SGL__fontFace[SGL_FONT_EXTRA],  "",                LF_FACESIZE - 1) ;
	}
	else for (i = 0 ; i < NFONTOPTION ; i++)
	{
		if (faceNames[i] && faceNames[i][0])
			strncpy(SGL__fontFace[i], faceNames[i], LF_FACESIZE - 1) ;
	}

	HDC hdc = GetDC(0) ;							/* font metrics require a device context	*/

	SGL_refSize = - fnt.lfHeight ;					/* set main size							*/
	if (sizes[SGL_FONT_NORMAL] < 0)
		SGL_refSize = - sizes[SGL_FONT_NORMAL] ;					/* pixels value				*/
	else
		SGL_refSize = SGL_refSize * sizes[SGL_FONT_NORMAL] / 100 ;	/* relative value / system	*/

													/*==== CREATE FONTS ========================*/
	for (int option = 0 ; option < NFONTOPTION ; option++)	/* for all options				*/
	{
		char *optionLabel = "", heightText[32] = "" ;
		for (i = 0 ; i < NFONTSIZE ; i++)						/* for all sizes					*/
		{
			if (sizes[i] < 0)										/* set size						*/
				SGL__fontSize[i] = - sizes[i] ;
			else
			{
				if (i == SGL_FONT_NORMAL)
					SGL__fontSize[i] = SGL_refSize ;
				else
					SGL__fontSize[i] = SGL_refSize * sizes[i] / 100 ;
			}

			if (SGL__font[option][i])								/* free previous fonts		*/
			{
				DeleteObject(SGL__font[option][i]) ;
				SGL__font[option][i] = NULL ;
			}

			LOGFONT newFont = fnt ;									/* modifiy default font		*/
			newFont.lfHeight = - SGL__fontSize[i] ;
			strncpy(newFont.lfFaceName, SGL__fontFace[option], LF_FACESIZE - 1) ;
			switch (option)
			{
				case SGL_FONT_NORMAL :
					optionLabel = "NORMAL" ;
					break ;
				case SGL_FONT_BOLD :
					optionLabel = "BOLD" ;
					newFont.lfWeight = FW_SEMIBOLD ;
					break ;
				case SGL_FONT_ITALIC :
					optionLabel = "ITALIC" ;
					newFont.lfItalic = 1 ;
					break ;
				case SGL_FONT_FIXED :
					optionLabel = "FIXED" ;
					newFont.lfPitchAndFamily = FIXED_PITCH ;
					break ;
				case SGL_FONT_SYMBOL :
					optionLabel = "SYMBOL" ;
					break ;
				case SGL_FONT_EXTRA :
					optionLabel = "EXTRA" ;
					break ;
				default :
					return SGL_ERR_INT ;
			}

			SGL__font[option][i] = CreateFontIndirect(&newFont) ;	/* create font				*/
			if (SGL__font[option][i] == NULL)
				return SGL_ERR_ALLOC ;

			SelectObject(hdc, SGL__font[option][i]) ;				/* get its height			*/
			TEXTMETRIC tm ; GetTextMetrics (hdc, &tm) ;
			SGL__fontHeight[option][i] = tm.tmHeight + tm.tmExternalLeading ;
			sprintf(&heightText[strlen(heightText)], "%d ",SGL__fontHeight[option][i]) ;
		}
		if (strlen(SGL__fontFace[option]))
			SGL_Log(DEBUG, "Option:%8s   Font:%18s   Size: %d   Height: %s",
					optionLabel, SGL__fontFace[option], 
					SGL__fontSize[SGL_FONT_NORMAL], heightText) ;
	}

	ReleaseDC(0, hdc) ;

	SGL_Log(DEBUG, "RefSize = %d\nDefautPad = %d", SGL_refSize, SGL_defPad) ;
	return 0 ;
}

/*----------------------------------------------------------------------------------------------*/
void SGL_Exit(void)
{
	SGL__objectsExit() ;
								/* If the console does not exist, FreeConsole() may hang about	*/
	GenerateConsoleCtrlEvent(CTRL_C_EVENT, 0) ;
}


/*=================================================================== PRIVATE AND LOCAL TOOLS ==*/

/*----------------------------------------------------------------------------------------------*/
static DWORD regGetValue(HKEY hkey, char* lpSubKey, char* lpValue, void* data, LPDWORD size)
/*------------------------------------------------------------------------------------------------
This function is similar to RegGetValue() (Windows versions above XP 32-bit). Differences are:
	- no input flags
	- the function returns the key's value type, or REG_NONE (0) in case of error.
------------------------------------------------------------------------------------------------*/
{
	HKEY key ;
	LONG e = RegOpenKeyEx(hkey, lpSubKey, 0, KEY_QUERY_VALUE, &key) ;
	if (e == ERROR_SUCCESS)
	{
		DWORD type ;
		e = RegQueryValueEx(key, lpValue, NULL, &type, data, size) ;
		RegCloseKey(key) ;
		if (e == ERROR_SUCCESS)
			return type ;
	}
	return REG_NONE ;
}

/*----------------------------------------------------------------------------------------------*/
SGL_T* SGL__getStruct(HWND hwnd)			/* get and check the SGL_T structure of a window	*/
{
	SGL_T *sgl = hwnd ? (SGL_T*) GetWindowLongPtr(hwnd, GWLP_USERDATA) : NULL ;
	if (sgl && sgl->type >= 0)
		return sgl ;
	else
		return NULL ;
}

/*----------------------------------------------------------------------------------------------*/
static void contextUpdate(HWND hwnd)					/* inherit parameters					*/
{
	SGL_T* sgl = SGL__getStruct(hwnd) ;
	if (sgl == NULL)									/* skip non SGL objects					*/
		return ;

	HWND hwndChild = GetTopWindow(hwnd) ;				/* first child							*/
    while (hwndChild)									/* scan children (recursive call)		*/
    {
        contextUpdate(hwndChild) ;
	    hwndChild = GetNextWindow(hwndChild, GW_HWNDNEXT) ;
    }

	SGL_CONTEXT_T *ctx = &(sgl->context) ;
	ctx->dimmed = 0 ;
	ctx->bgdColor = sgl->uBgColor ;
	ctx->fgdColor = sgl->uFgColor ;
	ctx->fontSizeIx = sgl->uFontSizeIx ;
	ctx->fontStyle = sgl->uFontStyle ;

	SGL_T *sglP ;											/* parent object					*/
	for (sglP = sgl ; sglP ; sglP = sglP->sglParent)		/* scan parents						*/
	{
		if (sglP->uDimmed == 1)				ctx->dimmed = 1 ;
		if (ctx->bgdColor == -1)	ctx->bgdColor = sglP->uBgColor ;
		if (ctx->fgdColor == -1)	ctx->fgdColor = sglP->uFgColor ;
		if (ctx->fontSizeIx == -1)	ctx->fontSizeIx = sglP->uFontSizeIx ;
		if (ctx->fontStyle == -1)	ctx->fontStyle = sglP->uFontStyle ;
	}
															/* default values					*/
	if (ctx->bgdColor == -1)	ctx->bgdColor	= SGL_LTGRAY ;
	if (ctx->fgdColor == -1)	ctx->fgdColor	= SGL_BLACK ;
	if (ctx->fontSizeIx == -1)	ctx->fontSizeIx	= SGL_FONT_NORMAL ;
	if (ctx->fontStyle == -1)	ctx->fontStyle	= SGL_FONT_NORMAL ;

															/* adjust colors					*/
	ctx->bgdColor = SGL_ColorDim(SYSCOLOR(ctx->bgdColor), ctx->dimmed) ;
	ctx->fgdColor = SGL_ColorDim(SYSCOLOR(ctx->fgdColor), ctx->dimmed) ;
}

int SGL__getFontHeight(SGL_T *sgl)
{
	return SGL__fontHeight[sgl->context.fontStyle][sgl->context.fontSizeIx] ;
}

HFONT SGL__getFont(SGL_T *sgl)
{
	return SGL__font[sgl->context.fontStyle][sgl->context.fontSizeIx] ;
}


/*============================================================================== PUBLIC TOOLS ==*/


/*----------------------------------------------------------------------------------------------*/
int SGL_BorderDraw(HDC hdc, RECT *rect, int style, int width, int color, int dim)
{
	if (hdc  == NULL) 	return SGL_ERR_PARM - 0 ;
	if (rect == NULL)	return SGL_ERR_PARM - 1 ;

	if (style == SGL_BORDER_NONE || width == 0)					/* case no border				*/
		return 0 ;
	if (style == SGL_BORDER_FLAT || style == SGL_BORDER_RFLAT)
	{
		HPEN pen = CreatePen(PS_INSIDEFRAME, width, SYSCOLOR(color)) ;
		if (pen == NULL)
			return SGL_ERR_ALLOC ;
		SelectObject(hdc, pen) ;
		SelectObject(hdc, GetStockObject(NULL_BRUSH)) ;
		if (style == SGL_BORDER_RFLAT)
			RoundRect(hdc, rect->left, rect->top, rect->right, rect->bottom, width, width) ;
		else
			Rectangle(hdc, rect->left, rect->top, rect->right, rect->bottom) ;
		InflateRect(rect, - width, - width) ;
		DeleteObject(pen) ;
	}
	else
	{
		int nc ;												/* number of gradient pens		*/
		switch (style)
		{
			case SGL_BORDER_BEVEL_UP :
			case SGL_BORDER_BEVEL_DOWN :
				nc = 2 * width + 1 ;
				break ;
			case SGL_BORDER_ETCHED_DOWN :
			case SGL_BORDER_ETCHED_UP :
				nc = max (2, width) ;
				break ;
			default :
				return SGL_ERR_PARM - 3 ;
		}
		HPEN fpen[nc] ;											/* gradient pens				*/
		int error = 0 ;

		int i ;
		for (i = 0 ; i < nc ; i++)
		{
			double k ;
			COLORREF cb ;

			if (i < nc / 2)										/* first are light				*/
			{
				k = 2. * i / max(1, nc - 1) ;
				cb = SGL_ColorInterpolate(SGL_ColorDim(SGL_WHITE, dim), color, k) ;
			}
			else
			{
				k = 2. * (nc - i - 1) / max(1, nc - 1) ;
				cb = SGL_ColorInterpolate(SGL_ColorDim(GetSysColor(COLOR_3DDKSHADOW), dim), 
										  color, k * k) ; 
			}
			fpen[i] = CreatePen(PS_SOLID, 1, cb) ;
			if (fpen[i] == NULL)
				error = 1 ;
		}

		for (i = 0 ; error == 0 && i < width ; i++)				/* draw frame					*/
		{
			int clt = 0, crb = 0 ;
			switch (style)
			{
				case SGL_BORDER_BEVEL_UP :
				case SGL_BORDER_ETCHED_UP :
					clt = i ;
					crb = nc - 1 - clt ;
					break ;
				case SGL_BORDER_BEVEL_DOWN :
				case SGL_BORDER_ETCHED_DOWN :
					crb = i ;
					clt = nc - 1 - crb ;
					break ;
			}
			rect->bottom-- ;
			rect->right-- ;
			SelectObject(hdc, fpen[clt]) ;
			MoveToEx(hdc, rect->left, rect->bottom, NULL) ;
			LineTo(hdc, rect->left, rect->top) ;
			LineTo(hdc, rect->right, rect->top) ;
			SelectObject(hdc, fpen[crb]) ;
			LineTo(hdc, rect->right, rect->bottom) ;
			LineTo(hdc, rect->left, rect->bottom) ;
			rect->top++ ;
			rect->left++ ;
		}

		for (i = 0 ; i < nc ; i++)
			if (fpen[i])
				DeleteObject(fpen[i]) ;
		if (error)
			return SGL_ERR_ALLOC ;
	}
	return 0 ;
}

/*----------------------------------------------------------------------------------------------*/
double SGL_Timer(void)									/* elapsed time (s) since first call	*/
/*----------------------------------------------------------------------------------------------*/
{
	static double perfFrequency = 0.0 ;
	static double startCounter ;
	LARGE_INTEGER ll ;

	if (perfFrequency == 0.0)
	{
		QueryPerformanceFrequency(&ll) ;
		perfFrequency = (double) ll.QuadPart ;
		QueryPerformanceCounter(&ll) ;
		startCounter = (double) ll.QuadPart ;
		return 0.0 ;

	}
	QueryPerformanceCounter(&ll) ;
	return ((double) (ll.QuadPart - startCounter)) / ((double) perfFrequency) ; 
}


/*========================================================================== COMMON FUNCTIONS ==*/


/*----------------------------------------------------------------------------------------------*/
int SGL_Run(void)
{
	MSG uMsg ;												/* event loop						*/
	int e ;

	while ((e = GetMessage(&uMsg, NULL, 0, 0)) != 0)
	{  
		if (e == -1)
			return SGL_ERR_INT ;
		TranslateMessage (&uMsg) ;
		DispatchMessage (&uMsg) ;
	}
	return 0 ;
}

/*----------------------------------------------------------------------------------------------*/
HWND SGL_New(HWND parent, int type, DWORD style, char *title, int left, int top)
{
	if (SGL__panelCheckMaxPos(parent, left, top)) return NULL ;		/* check position			*/
	if (parent && (left < 0 || top < 0))		  return NULL ;

	SGL_T *sgl = calloc(1, sizeof(SGL_T)) ;							/* SGL data					*/
	if (sgl == NULL)
		return NULL ;

	if (sgl->hwndParent = parent)									/* window's style			*/
		sgl->winStyle = WS_CHILD | WS_VISIBLE ;						/* child window				*/
	else
		sgl->winStyle = WS_CAPTION | WS_SYSMENU ;					/* main window				*/

	if (title == NULL || strlen(title) == 0)
		sgl->title = "unnamed" ;
	else
		sgl->title 		= title ;

	sgl->sglParent		= SGL__getStruct(parent) ;
	sgl->type			= type ;									/* must be >= 0				*/

	sgl->uStyle			= style ;									/* user style				*/
	sgl->scrollBars[0]	= (style & WS_HSCROLL) ? 1 : 0 ;
	sgl->scrollBars[1]	= (style & WS_VSCROLL) ? 1 : 0 ;

	sgl->uPos[0]		= left ;
	sgl->uPos[1]		= top ;
	sgl->uSize[0]		= 0 ;
	sgl->uSize[1]		= 0 ;

	sgl->uBgColor		= - 1 ;
	sgl->uFgColor		= - 1 ;
	sgl->uFontSizeIx	= - 1 ;
	sgl->uFontStyle	    = - 1 ;
	sgl->borderColor	= - 1 ;

	for (size_t i = 0 ; i < 2 ; i++)				/* default padding							*/
		for (size_t j = 0 ; j < 2 ; j++)
			sgl->pad[i][j] = SGL_defPad ;

	int e = SGL__objectsNew(sgl) ;					/* create object's window and attributes	*/
	if (e)
	{													/* if object could not be created		*/
		char l[64] ;												/* log error				*/
		snprintf(l, 64, "%s object \"%s\" not created", sgl->typeName, sgl->title) ;
		SGL_Error(l, -1, e) ;

		if (sgl->ex)												/* free memory				*/
			free(sgl->ex) ;
		free(sgl) ;
		if (sgl->hwnd)
			DestroyWindow(sgl->hwnd) ;
		return NULL ;
	}
	SetWindowLongPtr(sgl->hwnd, GWLP_USERDATA, (LONG_PTR) sgl) ;	/* link window to SGL		*/

	SGL_Log(DEBUG, "HWND:0x%P  %16s - NEW %s", sgl->hwnd, sgl->title, sgl->typeName) ;
	return sgl->hwnd ;
}

/*----------------------------------------------------------------------------------------------*/
HWND SGL_Duplicate(HWND parentDest, HWND childSource, char *title, int left, int top)
{
	if (parentDest == NULL || SGL__panelCheckMaxPos(parentDest, left, top))
		return NULL ;

	SGL_T* sglSource = SGL__getStruct(childSource) ;
	if (sglSource == NULL)
		return NULL ;						/* wrong child source								*/

	SGL_T *sgl = calloc(1, sizeof(SGL_T)) ;							/* SGL data					*/
	if (sgl == NULL)
		return NULL ;
	*sgl = *sglSource ;												/* copy from source			*/

	if (title)		sgl->title = title ;
	if (left >= 0)	sgl->uPos[0] = left ;
	if (top  >= 0)	sgl->uPos[1] = top ;

	sgl->hwndParent = parentDest ;
	sgl->sglParent	= SGL__getStruct(parentDest) ;

	if (SGL__objectsNew(sgl))						/* create object's window and attributes	*/
	{													/* if object could not be created		*/
		if (sgl->ex)												/* free memory				*/
			free(sgl->ex) ;
		free(sgl) ;
		if (sgl->hwnd)
			DestroyWindow(sgl->hwnd) ;
		return NULL ;
	}
	SetWindowLongPtr(sgl->hwnd, GWLP_USERDATA, (LONG_PTR) sgl) ;	/* link window to SGL		*/

	SGL_Log(DEBUG, "HWND:0x%P  %16s - NEW %s", sgl->hwnd, sgl->title, sgl->typeName) ;
	return sgl->hwnd ;
}

/*----------------------------------------------------------------------------------------------*/
void SGL_Destroy(HWND hwnd)						/* destroys a window and its childs				*/
{
	SendMessage(hwnd, WM_CLOSE, 0, 0) ;					/* may work between diffrent threads	*/
}

/*----------------------------------------------------------------------------------------------*/
void SGL_Layout(HWND hwnd)
{
	contextUpdate(hwnd) ;
	SGL__panelLayout(hwnd) ;

	return ;
}

/*----------------------------------------------------------------------------------------------*/
int SGL_Redraw(HWND hwnd)
{
	SGL_T* sgl = SGL__getStruct(hwnd) ;
	if (sgl == NULL)
		return SGL_ERR_PARM - 0 ;

	contextUpdate(hwnd) ;
	int e = (0 == RedrawWindow(hwnd, NULL, NULL, RDW_FRAME | RDW_INVALIDATE | RDW_ERASE)) ;

	return e ;
}


/*========================================================================== WINDOW PROCEDURE ==*/

/*----------------------------------------------------------------------------------------------*/
LRESULT CALLBACK SGL__WinProc(HWND hwnd, UINT event, WPARAM wParam, LPARAM lParam)
/*------------------------------------------------------------------------------------------------
If a window receives a event from a child control, processing is transfered to this control.
The user callback - if it exists - receives then wParam instead of event.
------------------------------------------------------------------------------------------------*/
{
	LRESULT result = DEFPROC ;
	int dialogControl = 0 ;

	switch (event)
	{
		case WM_MOUSEWHEEL :
		{
			if (mouseWheelRouting == 0)					/* send the mouse wheel event to the	*/
			{												/* window under the mouse pointer	*/
				POINT pt ; SGL_CursorPositionGet(0, 0, &pt) ;
				HWND hwndC = WindowFromPoint(pt) ;
				if (hwndC != hwnd)
				{
					PostMessage(hwndC, event, wParam, lParam) ;
					return 0 ;
				}
				
			}
			break ;
		}

		case WM_COMMAND :									/* in case of a child control		*/
			if (HIWORD(wParam) == 0)							/* skip if menu					*/
				break ;
		case WM_CTLCOLORSTATIC :							/*	change window to this child		*/
		case WM_CTLCOLOREDIT :
			hwnd = (HWND) lParam ;
			if (hwnd == 0)									/* case not a control event			*/
				return 0 ;
			dialogControl = 1 ;
			break ;
	}

	SGL_T *sgl = SGL__getStruct(hwnd) ;
	if (sgl)
	{
		if (SGLdebug == -1 || sgl->debug)
			SGL__trace(__func__, hwnd, event, wParam, lParam) ;

		switch (event)
		{
			case WM_MOVE :					/* move window										*/
				if (GetParent(hwnd) == NULL)
				{									/* save the position of top windows			*/
					GetWindowRect(hwnd, &(sgl->rect)) ;
					sgl->uPos[0] = sgl->rect.left ;
					sgl->uPos[1] = sgl->rect.top ;
				}
				if (sgl->saveSection && (sgl->saveOp & SGL_SAVE_POSITION))
				{
					SGL_ProfileIntSet(sgl->saveSection, "left", sgl->uPos[0], 0) ;
					SGL_ProfileIntSet(sgl->saveSection, "top",  sgl->uPos[1], 0) ;
				}
				break ;

			case WM_LBUTTONDOWN :			/* set focus on any mouse click						*/
			case WM_MBUTTONDOWN :
			case WM_RBUTTONDOWN :
				SetFocus(hwnd) ;
				break ;

			case WM_NCDESTROY :				/* free ressources and exit							*/
			{									/* prefered to WM_DESTROY: it is the last event	*/
				if (sgl)						/* and sent upwards (ends with top window)		*/
				{	
					if (sgl->ex) free(sgl->ex) ;
					free(sgl) ;
					sgl = NULL ;
					SetWindowLongPtr(hwnd, GWLP_USERDATA, 0) ;		/* unlink window to SGL		*/
					PostQuitMessage(0) ;							/* exit application			*/
					return 0 ;
				}
			}
		}
	}
						/* sgl must be tested again (may have been destroyed by WM_NCDESTROY	*/

	SGL_CB func = sgl ? sgl->CBfunction : NULL ;	/* process user callback					*/

	switch (event)
	{
		case WM_KEYDOWN :
		case WM_SYSKEYDOWN :
		case WM_KEYUP :
		case WM_SYSKEYUP :
		{
			HWND hwndP ; SGL_T* sglP ;					/* parent object		*/
			for (hwndP = hwnd, sglP = sgl ; sglP ; )
			{
				if (func == NULL ||
					func(hwndP, dialogControl ? (UINT) HIWORD(wParam) : event, 
						 wParam, lParam) == 0)			/* object not processed	*/
				{
					if ((sglP = sglP->sglParent) != NULL)	/* try parent		*/
					{
						hwndP = sglP->hwnd, 
						func = sglP->CBfunction ;
					}
				}
				else
					break ;
			}
			break ;
		}
		default :
			if (func && func(hwnd, dialogControl ? (UINT) HIWORD(wParam) : event, wParam, lParam))
				return 0 ;
	}

	if (sgl && sgl->sglProc)						/* process object callback					*/
		result = sgl->sglProc(hwnd, sgl, event, wParam, lParam) ;
								/*--------------------------------------------------------------*/
								/* The result must be DEFPROC if the object callback did not	*/
								/* process the event or if standard processing must resume.		*/
								/*--------------------------------------------------------------*/
	if (result == DEFPROC)
	{
		if (sgl && sgl->defWinProc)
			return CallWindowProc(sgl->defWinProc, hwnd, event, wParam, lParam) ;
		else
			return DefWindowProc(hwnd, event, wParam, lParam) ;
	}
	else
		return result ;
}


/*======================================================================= SET & GET FUNCTIONS ====

CHECK_OBJ(h, s, o) is the first instruction of set/get function related an object
	HWND	h	windows object
	SGL_T	s	internal SGL object
	int		o	set/get parameter

If the object's check function does not exist, the set/get operation is allowed for all parameters.

If this function exists, it checks for the concerned parameter defined by CHECK_ARG and option o. 
If it returns 0, the set/get can be performed.

------------------------------------------------------------------------------------------------*/

#define CHECK_OBJ(h, s, o)	SGL_T* s = SGL__getStruct(h) ;								\
							if (s == NULL)												\
								return SGL_ERR_PARM - 0 ;								\
							if (s->parmIgnore && s->parmIgnore(s, CHECK_ARG, o))		\
								return SGL_ERR_TYPE ;
#define CHECK_ARG 0			/* set to CHECK_xx to check if the parameter xx can bet set/get		*/
							/* the default value is 0 (no checking)								*/

/*------------------------------------------------------------------------------------- Debug --*/

void SGL_DebugSet(HWND hwnd, int debugLevel)
{
	SGL_T* sgl = SGL__getStruct(hwnd) ;
	if (sgl == NULL)
		SGLdebug = debugLevel ;
	else
		sgl->debug = debugLevel ;
	return ;
}

int SGL_DebugGet(HWND hwnd)
{
	SGL_T* sgl = SGL__getStruct(hwnd) ;
	if (sgl == NULL)
		return SGLdebug ;
	else
		return sgl->debug ;
	return 0 ;
}

/*------------------------------------------------------------------------------- SGL Metrics --*/

int SGL_RefSizeGet(void)
{
	return SIZE(SGL_refSize) ;
}

void SGL_DefPaddingSet(int l)
{
	SGL_defPad = l ;
}

int SGL_DefPaddingGet(void)
{
	return SIZE(SGL_defPad) ;
}

/*--------------------------------------------------------------------------------- SGL Fonts --*/

int SGL_FontLoad(char* fName)							/* temporary font load					*/
{
	char* mem = NULL ;
	int size = 0 ;

	if (fName[0] == ':')									/* case resource locator			*/
	{
		char rscName[strlen(fName++)] ;								/* resource name to extract	*/
		for (int i = 0 ; *fName ; i++, fName++)
		{
			rscName[i] = '\0' ;
			if (*fName == ':')
				break ;
			else
				rscName[i] = *fName ;
		}
		fName++ ;													/* resource ID				*/
		HRSRC resrc = FindResource(NULL, fName, rscName) ;
		size = SizeofResource(NULL, resrc) ;
		mem = LockResource(LoadResource(NULL, resrc)) ;
	}
	else													/* case file						*/
	{
		int fh = _open(fName, _O_RDONLY) ;
		if (fh >= 0)
		{
			size = _filelength(fh) ;
			if (size > 0)
			{
				mem = malloc(size) ;
				_read(fh, mem, size) ;
			}
			else
				size = 0 ;
			_close(fh);
		}
	}

	DWORD nFonts = 0 ;
	if (mem) AddFontMemResourceEx(mem, size, 0, &nFonts) ;
	return nFonts ;
}

int SGL_FontFaceSet(int option, char *name)				/* set a global font face 				*/
{
	if (option < 0 || option >= NFONTOPTION)
		return SGL_ERR_PARM - 0 ;

	int sizes[NFONTSIZE] ;
	for (size_t i = 0 ; i < NFONTSIZE ; i++) sizes[i] = 0 ;

	char fontFaces[NFONTOPTION][LF_FACESIZE] ;
	for (size_t i = 0 ; i < NFONTOPTION ; i++) fontFaces[i][0] = '\0' ;
	strncpy(fontFaces[option], name, LF_FACESIZE - 1) ;

	int result = sglFontInit(fontFaces, sizes) ;
	if (result < 0) return result ;

	return SGL__objectsInit() ;								/* objects reinitialization			*/
}

int SGL_FontFaceGet(int option, char *name)				/* get a global font face				*/
{
	if (option < 0 || option > NFONTOPTION)
		return SGL_ERR_PARM - 0 ;

	if (name == NULL)
	return SGL_ERR_PARM - 1 ;
		strncpy(name, SGL__fontFace[option], LF_FACESIZE - 1) ;
	return 0 ;
}

int SGL_FontSizeSet(int sizeIx, int size)				/* set a global font size				*/
{
	if (sizeIx < 0 || sizeIx >= NFONTSIZE)
		return SGL_ERR_PARM - 0 ;

	int sizes[NFONTSIZE] ;
	for (size_t i = 0 ; i < NFONTSIZE ; i++) sizes[i] = 0 ;
	sizes[sizeIx] = - size ;							/* size >0: pixel, <0: % / normal		*/

	char fontFaces[NFONTOPTION][LF_FACESIZE] ;
	for (size_t i = 0 ; i < NFONTOPTION ; i++) fontFaces[i][0] = '\0' ;

	int result = sglFontInit(fontFaces, sizes) ;
	if (result < 0) return result ;

	return SGL__objectsInit() ;								/* objects reinitialization			*/
}

HFONT SGL_FontHandleGet(HWND hwnd, int sizeIx, int option)		/* get a font handle			*/
{
	SGL_T* sgl = SGL__getStruct(hwnd) ;
	if ((sizeIx < 0 || option < 0) && sgl == NULL)
		return NULL ;

	if (sizeIx > NFONTSIZE || option > NFONTOPTION)
		return NULL ;
	if (sizeIx < 0)									/* if <0: use the object setting			*/
		sizeIx = sgl->context.fontSizeIx ;
	if (option < 0)												/* idem							*/
		option = sgl->context.fontStyle ;

	return SGL__font[option][sizeIx] ;
}

#undef  CHECK_ARG
#define CHECK_ARG CHECK_FONT

int SGL_FontSizeGet(HWND hwnd)						/* get the font size of an object			*/
{
	CHECK_OBJ(hwnd, sgl, 0) ;											/* get and check sgl	*/
	return SGL__fontSize[sgl->context.fontSizeIx] ;
}

int SGL_FontHeightGet(HWND hwnd)					/* get the font height of an object			*/
{
	CHECK_OBJ(hwnd, sgl, 0) ;											/* get and check sgl	*/
	return SGL__getFontHeight(sgl) ;
}

int SGL_FontSizeIxSet(HWND hwnd, int sizeIx)		/* set the font size index of an object		*/
{
	CHECK_OBJ(hwnd, sgl, 0) ;											/* get and check sgl	*/

	if (sizeIx < 0 || sizeIx >= NFONTSIZE)
		return SGL_ERR_PARM - 1 ;
	else
		sgl->uFontSizeIx = sizeIx ;
	return 0 ;
}

int SGL_FontSizeIxGet(HWND hwnd)					/* get the font size index of an object		*/
{
	CHECK_OBJ(hwnd, sgl, 0) ;											/* get and check sgl	*/
	return sgl->context.fontSizeIx ;
}

int SGL_FontStyleSet(HWND hwnd, int option)			/* set the font option of an object			*/
{
	CHECK_OBJ(hwnd, sgl, 0) ;											/* get and check sgl	*/

	if (option < 0 || option >= NFONTOPTION)
		return SGL_ERR_PARM - 1 ;
	else
		sgl->uFontStyle = option ;
	return 0 ;
}

int SGL_FontStyleGet(HWND hwnd)						/* get the font option of an object			*/
{
	CHECK_OBJ(hwnd, sgl, 0) ;											/* get and check sgl	*/
	return sgl->context.fontStyle ;
}

#undef  CHECK_ARG
#define CHECK_ARG 0

/*--------------------------------------------------------------------------- Cursor Position --*/

int SGL_CursorPositionSet(HWND hwnd, POINT *pt)
{
	if (hwnd && (IsWindow(hwnd) == 0))
		return SGL_ERR_PARM - 0 ;
	if (pt == NULL)
		return SGL_ERR_PARM - 1 ;

	if (hwnd)										/* if a window is defined:					*/
		ClientToScreen(hwnd, pt) ;					/*	convert from client coordinates			*/

	int e = SetCursorPos(pt->x, pt->y) ;
	return e ? 0 : SGL_ERR_INT ;
}

int SGL_CursorPositionGet(HWND hwnd, int current, POINT *pt)
{
	if (hwnd && (IsWindow(hwnd) == 0))
		return SGL_ERR_PARM - 0 ;
	if (pt == NULL)
		return SGL_ERR_PARM - 2 ;

	if (current)
		GetCursorPos(pt) ;							/* 1: current cursor position				*/
	else
	{
		DWORD p = GetMessagePos() ;					/* 0: position occupied by the cursor when	*/
		pt->x = GET_X_LPARAM(p) ;					/*    the last event was retrieved			*/
		pt->y = GET_Y_LPARAM(p) ;
	}

	if (hwnd)										/* if a window is defined:					*/
		ScreenToClient(hwnd, pt) ;					/*	convert to client coordinates			*/
	return 0 ;
}

/*------------------------------------------------------------------------ Object Environment --*/

int SGL_ContextGet(HWND hwnd, SGL_CONTEXT_T *context)
{
	CHECK_OBJ(hwnd, sgl, 0) ;											/* get and check sgl	*/
	if (context == NULL)
		return SGL_ERR_PARM - 1 ;
	*context = sgl->context ;
	return 0 ;
}

/*------------------------------------------------------------------------------------- Title --*/

int SGL_TitleSet(HWND hwnd, char* title)
{
	CHECK_OBJ(hwnd, sgl, 0) ;											/* get and check sgl	*/
	sgl->title = title ;
	int e = SetWindowText(hwnd, sgl->title) ;
	return e ? 0 : SGL_ERR_PARM - 1 ;
}

int SGL_TitleGet(HWND hwnd, char** title)
{
	CHECK_OBJ(hwnd, sgl, 0) ;											/* get and check sgl	*/
	if (title == NULL)
		return SGL_ERR_PARM - 1 ;
	*title = sgl->title ;
	return 0 ;
}

/*------------------------------------------------------ Position (grid coordinates) and Size --*/

int SGL_PositionSet(HWND hwnd, int left, int top)
{
	CHECK_OBJ(hwnd, sgl, 0) ;											/* get and check sgl	*/

	if (SGL__panelCheckMaxPos(sgl->hwndParent, left, 0))
		return SGL_ERR_PARM - 1 ;
	if (SGL__panelCheckMaxPos(sgl->hwndParent, 0, top))
		return SGL_ERR_PARM - 2 ;

	if (left >= 0) sgl->uPos[0] = left ;
	if (top  >= 0) sgl->uPos[1] = top ;
	return 0 ;
}

int SGL_PositionGet(HWND hwnd, int *left, int *top)
{
	CHECK_OBJ(hwnd, sgl, 0) ;											/* get and check sgl	*/
	int result = 0 ;

	if (top == NULL)
		result = SGL_ERR_PARM - 2 ;
	else
		*top  = sgl->uPos[1] ;

	if (left == NULL)
		result = SGL_ERR_PARM - 1 ;
	else
		*left = sgl->uPos[0] ;
	return result ;
}

int SGL_LayoutConfigure(HWND hwnd, char *section, int op)
{
	CHECK_OBJ(hwnd, sgl, 0) ;											/* get and check sgl	*/
	sgl->saveSection = section ;
	sgl->saveOp = op ;

	if (section)
	{
		int left   = SGL_ProfileIntGet(section, "left", 20) ;
		int top    = SGL_ProfileIntGet(section, "top", 20) ;
		if (op & SGL_SAVE_POSITION)
			SetWindowPos(hwnd, HWND_TOP, left, top, 0, 0, SWP_NOZORDER | SWP_NOSIZE) ;

		int width  = SGL_ProfileIntGet(section, "width", 0) ;
		int height = SGL_ProfileIntGet(section, "height", 0) ;
		if (op & SGL_SAVE_SIZE)
		{
			if (width)	sgl->uSize[0] = width ;
			if (height)	sgl->uSize[1] = height ;
		}
	}
	return 0 ;
}

#undef  CHECK_ARG
#define CHECK_ARG CHECK_SIZE

int SGL_SizeSet(HWND hwnd, int sizeID, int size)
{
	CHECK_OBJ(hwnd, sgl, sizeID) ;										/* get and check sgl	*/

	int ix ;											/* index of sgl->uSize[]				*/
	if (sizeID == SGL_WIDTH)
		ix = 0 ;
	else if (sizeID == SGL_HEIGHT)
		ix = 1 ;
	else
		return SGL_ERR_PARM - 1 ;

	sgl->uSize[ix] = size ;

	if (sgl->saveSection && (sgl->saveOp & SGL_SAVE_SIZE))
		SGL_ProfileIntSet(sgl->saveSection, ix ? "height" : "width", size, 0) ;
	return 0 ;
}

int SGL_SizeGet(HWND hwnd, int sizeID, int *size)
{
	CHECK_OBJ(hwnd, sgl, sizeID) ;										/* get and check sgl	*/

	int ix ;											/* index of sgl->uSize[]				*/
	if (sizeID == SGL_WIDTH)
		ix = 0 ;
	else if (sizeID == SGL_HEIGHT)
		ix = 1 ;
	else
		return SGL_ERR_PARM - 1 ;
	if (size == NULL)
		return SGL_ERR_PARM - 2 ;
	*size = sgl->uSize[ix] ;
	return 0 ;
}

#undef  CHECK_ARG
#define CHECK_ARG 0

/*--------------------------------------------------------------------  Alignment and Padding --*/

#undef  CHECK_ARG
#define CHECK_ARG CHECK_ALIGNMENT

int SGL_AlignmentSet(HWND hwnd, int align)
{
	CHECK_OBJ(hwnd, sgl, 0) ;											/* get and check sgl	*/
	if (sgl->hwndParent == 0) return SGL_ERR_TYPE ;
	sgl->align = align ;
	return 0 ;
}

int SGL_AlignmentGet(HWND hwnd)
{
	CHECK_OBJ(hwnd, sgl, 0) ;											/* get and check sgl	*/
	if (sgl->hwndParent == 0) return SGL_ERR_TYPE ;
	return sgl->align ;
}

#undef  CHECK_ARG
#define CHECK_ARG 0

int SGL_PaddingSet(HWND hwnd, RECT *padding)
{
	CHECK_OBJ(hwnd, sgl, 0) ;											/* get and check sgl	*/
	if (sgl->hwndParent == 0) return SGL_ERR_TYPE ;
	if (padding == NULL)
	{															/* reset to 0 if null pointer	*/
		sgl->pad[0][0] = sgl->pad[0][1] = 0 ;
		sgl->pad[1][0] = sgl->pad[1][1] = 0 ;
	}
	else
	{
		sgl->pad[0][0] = padding->left ;
		sgl->pad[0][1] = padding->right ;
		sgl->pad[1][0] = padding->top ;
		sgl->pad[1][1] = padding->bottom ;
	}
	return 0 ;
}

int SGL_PaddingGet(HWND hwnd, RECT *padding)
{
	CHECK_OBJ(hwnd, sgl, 0) ;											/* get and check sgl	*/
	if (sgl->hwndParent == 0) return SGL_ERR_TYPE ;
	if (padding == NULL)
		return SGL_ERR_PARM - 0 ;
		padding->left	= sgl->pad[0][0] ;
		padding->right	= sgl->pad[0][1] ;
		padding->top	= sgl->pad[1][0] ;
		padding->bottom	= sgl->pad[1][1] ;
	return 0 ;
}

/*------------------------------------------------------------------------ Visible and Dimmed --*/

int SGL_VisibleSet(HWND hwnd, int visible)
{
	CHECK_OBJ(hwnd, sgl, 0) ;											/* get and check sgl	*/
	ShowWindow(hwnd, visible ? SW_SHOW : SW_HIDE) ;
	return 0 ;
}

int SGL_VisibleGet(HWND hwnd)
{
	CHECK_OBJ(hwnd, sgl, 0) ;											/* get and check sgl	*/
	return IsWindowVisible(hwnd) ? 1 : 0 ;
}

int SGL_DimmedSet(HWND hwnd, int dimmed)
{
	CHECK_OBJ(hwnd, sgl, 0) ;											/* get and check sgl	*/

	sgl->uDimmed = dimmed ? 1 : 0 ;
	EnableWindow(hwnd, dimmed ? 0 : 1) ;
	return 0 ;
}

int SGL_DimmedGet(HWND hwnd)
{
	CHECK_OBJ(hwnd, sgl, 0) ;											/* get and check sgl	*/
	return sgl->context.dimmed ;										/* actual dim status	*/
}

/*---------------------------------------------------------- Background and Foreground Colors --*/

#undef  CHECK_ARG
#define CHECK_ARG CHECK_COLORS

int SGL_BGcolorSet(HWND hwnd, COLORREF color)
{
	CHECK_OBJ(hwnd, sgl, 0) ;											/* get and check sgl	*/
	sgl->uBgColor = color ;
	return 0 ;
}

int SGL_BGcolorGet(HWND hwnd)
{
	CHECK_OBJ(hwnd, sgl, 0) ;											/* get and check sgl	*/
	return sgl->context.bgdColor ;
}

int SGL_FGcolorSet(HWND hwnd, COLORREF color)
{
	CHECK_OBJ(hwnd, sgl, 0) ;											/* get and check sgl	*/
	sgl->uFgColor = color ;
	return 0 ;
}

int SGL_FGcolorGet(HWND hwnd)
{
	CHECK_OBJ(hwnd, sgl, 0) ;											/* get and check sgl	*/
	return sgl->context.fgdColor ;
}

#undef  CHECK_ARG
#define CHECK_ARG 0

/*------------------------------------------------------------------------------------ Border --*/

#undef  CHECK_ARG
#define CHECK_ARG CHECK_BORDERSTYLE

int SGL_BorderStyleSet(HWND hwnd, int style)
{
	CHECK_OBJ(hwnd, sgl, 0) ;											/* get and check sgl	*/
	sgl->borderStyle = style ;
	return 0 ;
}

int SGL_BorderStyleGet(HWND hwnd)
{
	CHECK_OBJ(hwnd, sgl, 0) ;											/* get and check sgl	*/
	return sgl->borderStyle ;
}

#undef  CHECK_ARG
#define CHECK_ARG CHECK_BORDERTHICKNESS

int SGL_BorderThicknessSet(HWND hwnd, int e)
{
	CHECK_OBJ(hwnd, sgl, 0) ;											/* get and check sgl	*/
	sgl->borderThickness = e ;
	return 0 ;
}

int SGL_BorderThicknessGet(HWND hwnd, int *e)
{
	CHECK_OBJ(hwnd, sgl, 0) ;											/* get and check sgl	*/
	if (e == NULL)
		return SGL_ERR_PARM - 1 ;
	*e = sgl->borderThickness ;
	return 0 ;
}

int SGL_BorderColorSet(HWND hwnd, COLORREF color)
{
	CHECK_OBJ(hwnd, sgl, 0) ;											/* get and check sgl	*/
	sgl->borderColor = color ;
	return 0 ;
}

int SGL_BorderColorGet(HWND hwnd, COLORREF *color)
{
	CHECK_OBJ(hwnd, sgl, 0) ;											/* get and check sgl	*/
	if (color == NULL)
		return SGL_ERR_PARM - 1 ;
	*color = sgl->borderColor ;
	return 0 ;
}

#undef CHECK_ARG
#define CHECK_ARG 0

/*---------------------------------------------------------------------------------- Callback --*/

int SGL_CallbackFunctionSet(HWND hwnd, SGL_CB func)
{
	CHECK_OBJ(hwnd, sgl, 0) ;											/* get and check sgl	*/
	sgl->CBfunction = func ;
	return 0 ;
}

int SGL_CallbackFunctionGet(HWND hwnd, SGL_CB *func)
{
	CHECK_OBJ(hwnd, sgl, 0) ;											/* get and check sgl	*/
	if (func == NULL)
		return SGL_ERR_PARM - 1 ;
	*func = sgl->CBfunction ;
	return 0 ;
}

int SGL_CallbackDataSet(HWND hwnd, void *dataPtr)
{
	CHECK_OBJ(hwnd, sgl, 0) ;											/* get and check sgl	*/
	sgl->CBdataPtr = dataPtr ;
	return 0 ;
}

int SGL_CallbackDataGet(HWND hwnd, void ** dataPtr)
{
	CHECK_OBJ(hwnd, sgl, 0) ;											/* get and check sgl	*/
	if (dataPtr == NULL)
		return SGL_ERR_PARM - 1 ;
	*dataPtr = sgl->CBdataPtr ;
	return 0 ;
}
