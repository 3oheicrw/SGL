#define SGL_CTRL_GRAPH	1500				/* object type										*/

typedef void (*SGL_GRAPH_PLOTCB)(HWND hwnd, HDC hdc, int layer, int item);
typedef void (*SGL_GRAPH_LABELCB)(HWND hwnd, HDC hdc, double value, RECT *rect, int axisID);

typedef struct								/* axis definition									*/
{
	double lowValue;
	double highValue;
	double interval;
	int ntick;								/* number of ticks or values						*/
	SGL_GRAPH_LABELCB labelCB ;
	int grid;
	COLORREF color;
} SGL_GRAPH_AXIS_T;

int SGL_GraphAxisSet(HWND hwnd, int axisID, SGL_GRAPH_AXIS_T* uAxis);
int SGL_GraphAxisGet(HWND hwnd, int axisID, SGL_GRAPH_AXIS_T* uAxis);
int SGL_GraphMarginSet(HWND hwnd, RECT *margin);
int SGL_GraphMarginGet(HWND hwnd, RECT *margin);
int SGL_GraphPlotRectGet(HWND hwnd, RECT *plotRect);
int SGL_GraphTickLengthSet(HWND hwnd, int tickLen);
int SGL_GraphTickLengthGet(HWND hwnd, int *tickLen);
int SGL_GraphBGcolorSet(HWND hwnd, int layer, COLORREF bgColor);
int SGL_GraphBGcolorGet(HWND hwnd, int layer, COLORREF *bgColor);
int SGL_GraphPlotFunctionSet(HWND hwnd, SGL_GRAPH_PLOTCB plotFunc);
int SGL_GraphPlotFunctionGet(HWND hwnd, SGL_GRAPH_PLOTCB *plotFunc);
int SGL_GraphPlotRequest(HWND hwnd, int layer, int item);
int SGL_GraphClear(HWND hwnd, int layer);
int SGL_GraphUserToPixel(HWND hwnd, int axisID, double x);
int SGL_GraphPixelToUser(HWND hwnd, int axisID, int xp, double *x);

