/*============== THIS FILE CONTAINS THE PRIVATE DEFINITIONS OF THE SGL KERNEL ==================*/

#include <time.h>
#include <conio.h>

#define __STDC_WANT_LIB_EXT1__ 1

#include "sgl_base.h"
#include "sgl_tools.h"

/* CONSTANTS */

#define MAINCLASSNAME	"SGLWINDOW"
#define DEFPROC 		-99999
#define TEXTSTYLE0		DT_NOPREFIX | DT_SINGLELINE | DT_VCENTER | DT_END_ELLIPSIS

									/* constants used by the set/get functions - cf. SGL_CHECK	*/
#define CHECK_SIZE				100
#define CHECK_ALIGNMENT			101
#define CHECK_COLORS			102
#define CHECK_FONT				103
#define CHECK_BORDERTHICKNESS	104										/* thickness and color	*/
#define CHECK_BORDERSTYLE		105


/* MACROS */

#define SYSCOLOR(color)	(((color) & SGL_SYSCOLOR) ? GetSysColor((color) & 0x1f) : (color))
#define DIMCOLOR (GetSysColor(COLOR_BTNFACE))

																/* used by the get functions	*/
#define APRESULT(arg_type, val)	{ arg_type _pt_ = va_arg(ap, arg_type) ;		\
								if (_pt_ != NULL) *_pt_ = (val) ; }

#define SIZE(l) ((l) < 0 ? - (l) * SGL_refSize / 100 : (l))		/* size macro					*/

																/* rectangle macro				*/
#define RECT_GETORIGIN(i, rect) ((i) ? (rect).top : (rect).left)
#define RECT_MOVE(i, rect, z) { if (i) {(rect).bottom += (z) - (rect).top ; (rect).top = (z) ;} \
							      else {(rect).right += (z) - (rect).left ; (rect).left = (z) ;}}
#define RECT_GETWH(i, rect) ((i) ? (rect).bottom - (rect).top : (rect).right - (rect).left)
#define RECT_SETWH(i, rect, w) { if (i) (rect).bottom = (rect).top + (w) ;	\
								else (rect).right = (rect).left + (w) ; }

																/* allocate and check			*/
#define NEW(type, data) type *data = (type*) calloc(1, sizeof(type)) ;	\
						if (data == NULL) return SGL_ERR_ALLOC ;


/* DATA TYPES */

typedef struct sgl_t_
{
	int type ;								/* object type (must be the first member)			*/
	char *title ;							/* title (displayed or not)							*/
	char* typeName ;						/* used for debug									*/
	int debug ;								/* used for debug messages							*/
	DWORD uStyle ;							/* style (used only for duplication)				*/
	DWORD winStyle ;						/* win32 specific style (idem)						*/

	HWND hwnd ;								/* window handle									*/
	HWND hwndParent ;						/* handle of the parent window						*/
	struct sgl_t_ *sglParent ;				/* not mandatory but used for faster access			*/

	int align ;
	int pad[2][2] ;							/* external padding [hor|vert][before|after]		*/
	int uPos[2], uSize[2] ;					/* user defined origin & width						*/

	char *saveSection ;
	int saveOp ;

	int scrollBars[2] ;						/* index 0: hor, 1: vert; value 0: off, 1: on		*/
	int borderStyle ;
	int borderThickness ;
	COLORREF borderColor ;

	SGL_CB CBfunction ;						/* user callback function and data					*/
	void* CBdataPtr ;

											/* standard object functions						*/
	void (*resizeObj)(struct sgl_t_*) ;
	int (*parmIgnore)(struct sgl_t_*, int, int) ;		/* retuns 0 if set/get is allowed		*/
	LRESULT (*sglProc)(HWND, struct sgl_t_*, UINT, WPARAM, LPARAM) ;
	WNDPROC defWinProc ;

											/* user attributes (not the actual values)			*/
	int uDimmed ;							/* aspect											*/
	COLORREF uBgColor, uFgColor ;			/* background and foreground colors					*/
	int uFontSizeIx, uFontStyle ;			/* font attributes									*/

											/* dynamic data										*/
	RECT rect ;								/* window rectangle									*/
	SGL_CONTEXT_T context ;					/* drawing context									*/
	void* ex ;								/* extra allocated data - cf. SGL__xxxNew()			*/
} SGL_T ;

typedef LRESULT (*SGL__WINPROC)(HWND hwnd, struct sgl_t_ *sgl, UINT message, WPARAM wParam, LPARAM lParam) ;


/* SHARED DATA */

#define NFONTSIZE 4							/* number of font sizes								*/
#define NFONTOPTION 6						/* number of font options (styles)					*/

extern HINSTANCE SGL__instance ;
extern int SGL_refSize, SGL_defPad ;
extern int SGLdebug ;


/* OTHER TOOLS */

LRESULT CALLBACK SGL__WinProc(HWND hwnd, UINT event, WPARAM wParam, LPARAM lParam) ;
SGL_T *SGL__getStruct(HWND hwnd) ;
int SGL__getFontHeight(SGL_T *sgl);
HFONT SGL__getFont(SGL_T *sgl);


#include "sgl_panel_.h"
#include "sgl_debug_.h"
