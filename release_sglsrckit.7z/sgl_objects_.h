int SGL__objectsInit(void) ;
int SGL__objectsNew(SGL_T *sgl) ;
void SGL__objectsExit(void) ;
