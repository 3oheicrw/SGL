/*================================================================================= SGL_GRAPH.C ==
SGL GRAPH class.

Drawing uses several layers:
	0						SGL background (color and axis), can be overwritten by user
	1 .. MAX_LAYERS - 1		layers for user drawing (from back to front)
	MAX_LAYERS				SGL temporary layer (the previous ones are first stacked here)

SGL draws in the background layer when the graph is installed (setting size or scales).
When SGL receives a WM_PAINT message:
	- it copy the background to the temporary layer, 
	- then the user layers with transparency,
	- and finally copy the temporary layer to the screen.

Devices contexts are built at start for all layers. SGL layer are also created at start; user 
bitmaps are automatically created or deleted (on demand).
 
The user cannot paint directly: he is only allowed to post a request which sends a WM_USER in the
message queue. The processing of this message will the call the user ploting function (callback).

==================================================================================================
date       author			update
----       ------			------
14/06/..   h serindat		creation start
15/09/04					v1.0 - first release
15/10/12					minor update SGL__graphNew(): no more default size (default = 0),
                                                          default args of CreateWindowEx()
16/01/11					v1.2 - winProc renamed sglProc to prevent confusion
16/03/16					v1.3 - SGL_ColorInperpolate() replaced by SGL_ColorInterpolate()
16/06/29					       SGL_GraphBGColor..() renamed SGL_GraphBGcolor..()
16/07/06					       update of internal tools
16/07/13					       graphProc() processing WM_MOUSEWHEEL
================================================================================================*/

#pragma comment(lib, "msimg32.lib")
#include <math.h>
#include <stdio.h>
#include "sgl_base_.h"
#include "sgl_graph.h"
#include "sgl_graph_.h"

#define MAX_LAYERS 25
#define SCALE_LIN  1					/* scale type if 0 for unused axis						*/
#define SCALE_LOG  2

typedef struct							/* AXIS DATA											*/
{
										/* user parameters (static)								*/
	double lowValue, highValue ;
	double interval ;
	int ntick ;
	void (*labelCB) (HWND, HDC, double, RECT*, int) ;
	int grid ;
	COLORREF color ;

	int scale ;							/* scale type - cf. SCALE_xxx							*/
	
										/* depends on graph size								*/
	int gbeg ;							/* begin of grid line:	common coordinate of intersect	*/
	int s0 ; double sc ;				/* scale coefficients compatible with screen (Prect)	*/
} SGL_AXIS_T ;

typedef struct sgl_graph_t_				/* GRAPH DATA											*/
{
	SGL_T *sgl ;							/* back pointer (not duplicated)					*/
	RECT Prect ;							/* plot rectangle (client window minus margin)		*/
	RECT margin ;							/* margin between the client rectangle and Prect	*/
	int tickl ;								/* tick length										*/

	SGL_GRAPH_PLOTCB plotCB ;				/* plot callback function							*/

	HDC hdcMem[MAX_LAYERS + 1] ;			/* device context handle: screen, memory image		*/
	HBITMAP hBitmap[MAX_LAYERS + 1] ;		/* bitmap used as memory image						*/
	COLORREF trColor[MAX_LAYERS] ;			/* color in bitmap to treat as transparent			*/

	SGL_AXIS_T axis[2][2] ;					/* axis indexes: [horizontal|vertical][begin|end]	*/
}
SGL_GRAPH_T ;

										/* debug condition										*/
#define DEBUG (sgl->debug ? STD : NONE)								/* sgl must be defined!		*/

static int parmIgnore(SGL_T *sgl, int dum, int check) ;
static void graphResize(SGL_T *sgl) ;
static LRESULT graphProc(HWND hwnd, SGL_T *sgl, UINT message, WPARAM wParam, LPARAM lParam) ;


/*==================================================================== LOCAL BITMAP FUNCTIONS ==*/

/*----------------------------------------------------------------------------------------------*/
static int bitmapRemove(SGL_GRAPH_T *graph, int layer)				/* destroy a bitmap			*/
{
	if (graph == NULL || layer < 0 || layer > MAX_LAYERS)
		return - 1 ;

	if (graph->hBitmap[layer])										/* if exists				*/
	{
		DeleteObject(graph->hBitmap[layer]) ;
		graph->hBitmap[layer] = NULL ;
	}
	return 0 ;
}

/*----------------------------------------------------------------------------------------------*/
static int bitmapClear(SGL_GRAPH_T *graph, int layer)				/* clear a bitmap			*/
{
	if (graph == NULL || layer < 1 || layer >= MAX_LAYERS)			/* user layers only			*/
		return  - 1 ;
	
	if (graph->hBitmap[layer] == NULL)								/* case does not exist		*/
		return - 2 ;

	HWND hwnd = graph->sgl->hwnd ;									/* paint background color	*/
	RECT rect ;
	GetClientRect(hwnd, &rect) ;
	SetDCBrushColor(graph->hdcMem[layer], graph->trColor[layer]) ;
	FillRect(graph->hdcMem[layer], &rect, GetStockObject(DC_BRUSH)) ;
	return 0 ;
}

/*----------------------------------------------------------------------------------------------*/
static int bitmapCreate(SGL_GRAPH_T *graph, int layer)				/* create a bitmap			*/
{
	if (graph == NULL || layer < 0 || layer > MAX_LAYERS)
		return - 1 ;

	if (graph->hBitmap[layer])
		bitmapRemove(graph, layer) ;

	HWND hwnd = graph->sgl->hwnd ;
	HDC hdc = GetDC(hwnd) ;
	graph->hBitmap[layer] = CreateCompatibleBitmap(hdc, graph->Prect.right, 
														graph->Prect.bottom) ;
	if (graph->hBitmap[layer] == NULL)
		return - 2 ;												/* case creation failed		*/
	else
	{
		ReleaseDC(hwnd, hdc) ;
		SelectObject(graph->hdcMem[layer], graph->hBitmap[layer]) ;
	}
	return 0 ;
}


/*==================================================================== COORDINATES TRANSFORMS ==*/

/*----------------------------------------------------------------------------------------------*/
static int pixel2user(SGL_AXIS_T *ax, int xp, double *x)				/* get user coordinate 	*/
{
	xp -= ax->s0 ;														/* offset				*/
	switch (ax->scale)													/* apply scale factor	*/
	{
		case SCALE_LIN :
			*x = xp / ax->sc + ax->lowValue ;
			break ;
		case SCALE_LOG :
			*x = ax->lowValue * pow(10.0, xp / ax->sc) ;
			break ;
		default :
			return SGL_ERR_INT ;
	}
	return 0 ;
}


/*----------------------------------------------------------------------------------------------*/
static int user2pixel(SGL_AXIS_T *ax, double x)						/* get pixel coordinate 	*/
{
	double xscaled ;
	switch (ax->scale)													/* apply scale factor	*/
	{
		case SCALE_LIN :
			xscaled = ax->sc * (x - ax->lowValue) ;
			break ;
		case SCALE_LOG :
			if (x <= 0.0)
				return - 1 ;
			xscaled = ax->sc * log10(x / ax->lowValue) ;
			break ;
		default :
			return - 1 ;
	}
	int result = ax->s0 + lround(xscaled) ;					/* round to integer and offset		*/
	return result ;
}


/*===================================================================== OTHER LOCAL FUNCTIONS --*/

/*----------------------------------------------------------------------------------------------*/
static int gridPos(SGL_AXIS_T *ax, int major, int *stcont, double *x)
/*------------------------------------------------------------------------------------------------
	This function, called repeatedly returns the user coordinate of the next tick.

	RTG_i		: graph structure index 											input
	iaxis		: axis number (TOP, LEFT..) 										input
	major		: search mode: 0: minor tick, 1: major tick 						input
	stcont		: saved status, must be 0 to get first position 					input/output
	x			: grid line position in user unit									output
	result		: 0: past end (x not valid), 1: x is valid 							result
------------------------------------------------------------------------------------------------*/
{
	switch (ax->scale)
	{
		case SCALE_LOG :
		{
			int tickIndex = ax->ntick ;						/* 1st index in major/minorTicks[]	*/
			if (tickIndex > 3) tickIndex = 3 ;

			int minorTicks[4][12] = {
				{10, 0},
				{10, 20, 30, 50, 0},
				{10, 15, 20, 30, 40, 50, 70, 0},
				{10, 15, 20, 25, 30, 40, 50, 60, 70, 80, 90, 0} } ;
			int majorTicks[4][12] = {
				{10, 0},
				{10, 20, 50, 0},
				{10, 20, 30, 40, 50, 70, 0},
				{10, 20, 30, 40, 50, 60, 80, 0} } ;

			int e10, mant ;								/* exponent base10 and mantisse * 100	*/
			if (*stcont == 0)							/* initalize							*/
			{
				e10 = (int) log10(ax->lowValue) ;
				mant = (int) (100.0 * ax->lowValue / pow(10.0, (double) e10) - 1) ;
			}
			else										/* get values from stcont				*/
			{
				e10 = *stcont / 100  ;
				mant = *stcont % 100 + 1 ;
			}
			for (int i = 0 ; ; i++)						/* search next tick						*/
			{
				int *nextMant = major ? majorTicks[tickIndex] : 
										minorTicks[tickIndex] ;
				if (nextMant[i] == 0)								/* new decade				*/
				{
					mant = nextMant[0] ;
					e10++ ;
					break ;
				}
				if (nextMant[i] > mant)								/* next tick				*/	
				{
					mant = nextMant[i] ;
					break ;
				}
			}
			*stcont = 100 * e10 + mant ;
			*x = pow(10.0, (double) e10) * mant / 100 ;
			return (ax->highValue - *x >= 0) ? 1 : 0 ;
		}

		case SCALE_LIN :
		{
			int cdir = (ax->lowValue > ax->highValue) ? -1 : 1 ;			/* in[de]creasing	*/
			double d = cdir * ax->interval / (major ? 1 : ax->ntick + 1) ;	/* signed increment	*/
			*x = d * (*stcont + ceil(ax->lowValue / d)) ;
			*stcont += 1 ;
			return ((ax->highValue - *x) * cdir >= 0) ? 1 : 0 ;
		}
		default :
			return 0 ;
	}
}

/*----------------------------------------------------------------------------------------------*/
static void backgroundPaint(SGL_GRAPH_T *graph, HDC hdc, int draw)
/*----------------------------------------------------------------------------------------------*/
{
	if (graph->hBitmap[0] == NULL) return ;					/* case no background				*/

	SGL_T *sgl = graph->sgl ;
	RECT rect ;														/* client rectangle			*/
	GetClientRect(sgl->hwnd, &rect) ;

	COLORREF bgColor = sgl->context.bgdColor ;				/* background color - window		*/
	SetDCBrushColor(hdc, bgColor) ;
	FillRect(hdc, &rect, GetStockObject(DC_BRUSH)) ;
															/* background color - plot area		*/
	bgColor = SGL_ColorDim(graph->trColor[0], sgl->context.dimmed) ;
	if (bgColor != -1)
	{
		SetDCBrushColor(hdc, bgColor) ;
		FillRect(hdc, &graph->Prect, GetStockObject(DC_BRUSH)) ;
	}

	SelectObject(hdc, SGL__getFont(sgl)) ;
	SetTextColor(hdc, sgl->context.fgdColor) ;
	SetBkMode(hdc, TRANSPARENT) ;

	if (draw == 0)											/* case bakground color only		*/
		return ;

	int tw[2][2] = {{1,-1},{0,0}} ;							/* size factors for ticks and		*/
	int th[2][2] = {{0,0},{1,-1}} ;										/*  grid lines			*/

	HPEN hpen ;

	for (int i = 0 ; i < 2 ; i++)							/* for all axis						*/
		for (int j = 0 ; j < 2 ; j++)
		{
			SGL_AXIS_T *ax = &graph->axis[i][j] ;
			if (ax->scale == 0) continue ;					/* case not used					*/

			COLORREF axColor = SGL_ColorDim(ax->color, sgl->context.dimmed) ;
			int major ;										/* minor/major ticks				*/
			
															/* DRAW GRID						*/
			for (major = 2 - ax->grid ; major < 2 ; major++)
			{
				int gridw = tw[i][j] * RECT_GETWH(i, graph->Prect) ;	/* size of a grid line	*/
				int gridh = th[i][j] * RECT_GETWH(i, graph->Prect) ;
				COLORREF gridColor = SGL_ColorInterpolate(bgColor, axColor, major ? 0.6 : 0.3) ;
				hpen = CreatePen(PS_SOLID, 1, gridColor) ;
				SelectObject(hdc, hpen) ;
				int stcont = 0 ;
				double z = 0.0 ;								/* value or tick position		*/
				while (gridPos(ax, major, &stcont, &z))
				{
					int xp, yp ;									/* tick origin on axis		*/
					xp = yp = user2pixel(&(graph->axis[i][j]), z) ;
					if (xp < 0)											/* case error			*/
						continue ;
					if (i == 0)	xp = ax->gbeg ;							/* case vertical axis	*/
					else		yp = ax->gbeg ;							/* case horizontal axis	*/

					MoveToEx(hdc, xp, yp, NULL) ;
					LineTo(hdc, xp + gridw, yp + gridh) ;
				}
				DeleteObject(hpen) ;
			}

			hpen = CreatePen(PS_SOLID, 1, axColor) ;		/* DRAW TICKS AND LABELS			*/
			SelectObject(hdc, hpen) ;

			int tickw = - tw[i][j] * SIZE(graph->tickl) ;				/* tick size			*/
			int tickh = - th[i][j] * SIZE(graph->tickl) ;

			for (major = 0 ; major < 2 ; major++)
			{
				int stcont = 0 ;								/* RTG_GridDraw loop status 	*/
				double z ;										/* value or tick position		*/
				while (gridPos(ax, major, &stcont, &z))				/* for all positions		*/
				{
					int xp, yp ;									/* tick end on axis		*/
					xp = yp = user2pixel(&(graph->axis[i][j]), z) ;
					if (xp < 0)											/* case error			*/
						continue ;
					if (i == 0)	xp = ax->gbeg ;							/* case vertical axis	*/
					else		yp = ax->gbeg ;							/* case horizontal axis	*/

					if (major == 0)
					{
						MoveToEx(hdc, xp + tickw, yp + tickh, NULL) ;	/* draw tick			*/
						LineTo(hdc, xp, yp) ;
					}
					else if (ax->labelCB)
					{										/* draw labels						*/
						int dta = tickw - tw[i][j] * SIZE(SGL_defPad) ;	/* distance to axis		*/
						RECT trect ;								/* text bounding rectangle	*/
						trect.left = trect.right  = xp + dta ;		/* start at tick end	*/
						trect.top  = trect.bottom = yp + tickh ;
						if (i == 0)										/* inflate				*/
						{
							trect.top    -= (SGL__getFontHeight(sgl) + 1) / 2 ;
							trect.bottom  = trect.top + SGL__getFontHeight(sgl) ;
							if (j == 0) trect.left  = 0 ;
							else		trect.right = rect.right ;
						}
						else
						{
							trect.left  -= 4 * SGL__getFontHeight(sgl) ;
							trect.right += 4 * SGL__getFontHeight(sgl) ;
							if (j == 0) trect.top    -= SGL__getFontHeight(sgl) ;
							else		trect.bottom += SGL__getFontHeight(sgl) ;
						}
						
						int RECTID[2][2] = { {SGL_LEFT, SGL_RIGHT}, {SGL_TOP, SGL_BOTTOM} } ;
						ax->labelCB(sgl->hwnd, hdc, z, &trect, RECTID[i][j]) ;
					}
				}
			}
			DeleteObject(hpen) ;
		}
}


/*========================================================================== OBJECT FUNCTIONS ==*/

/*----------------------------------------------------------------------------------------------*/
int  SGL__graphInit(void) { return 0 ; }
void SGL__graphExit(void) { return ; }

/*----------------------------------------------------------------------------------------------*/
int SGL__graphNew(SGL_T *sgl)							/* create a new graph					*/
{
	if (sgl->type != SGL_CTRL_GRAPH) return SGL_ERR_TYPE ;
	if (sgl->hwndParent == NULL)	 return SGL_ERR_PARM - 0 ;	/* parent must exist			*/

	NEW(SGL_GRAPH_T, graph) ;
	if (sgl->ex)											/* case duplicate					*/
		*graph = *(SGL_GRAPH_T*)sgl->ex ;
	else													/* case new							*/
	{															/* default values				*/
		sgl->typeName = "GRAPH" ;
		graph->tickl  = - 40 ;										/* tick length				*/

		sgl->parmIgnore =	parmIgnore ;							/* check for std attributes	*/
		sgl->resizeObj =	graphResize ;
		sgl->sglProc =		graphProc ;
	}

	sgl->ex = graph ;
	graph->sgl = sgl ;

	sgl->hwnd = CreateWindowEx(0, MAINCLASSNAME, sgl->title, sgl->winStyle | sgl->uStyle,
							    0, 0, 0, 0,
							    sgl->hwndParent, (HMENU) 0, SGL__instance, NULL) ;
	if (sgl->hwnd == NULL)
		return SGL_ERR_ALLOC ;

	HDC hdc = GetDC(sgl->hwnd) ;								/* get the device context		*/
	for (size_t layer = 0 ; layer < MAX_LAYERS + 1 ; layer++)	/* create new layers (HDC)		*/
		graph->hdcMem[layer] = CreateCompatibleDC(hdc) ;
	ReleaseDC(sgl->hwnd, hdc) ;

	return 0 ;
}

/*----------------------------------------------------------------------------------------------*/
static int parmIgnore(SGL_T *sgl, int check, int dum)
{
	if (check == CHECK_BORDERSTYLE || check == CHECK_BORDERTHICKNESS)
		return 1 ;
	return 0 ;
}

/*----------------------------------------------------------------------------------------------*/
static void graphResize(SGL_T *sgl)						/* resize a graph						*/
/*----------------------------------------------------------------------------------------------*/
{
	for (int i = 0 ; i < 2 ; i++)							/* 0: horizontal, 1: vertical		*/
	{
		int l = SIZE(sgl->uSize[i]) ;						/* size in pixels					*/
		RECT_SETWH(i, sgl->rect, l) ;
	}
	return ;												/* done								*/
}

/*========================================================================= SET/GET FUNCTIONS ==*/

#define CHECK_OBJ(h, g)		SGL_T* _sgl = SGL__getStruct(h) ;								\
							if (_sgl == NULL)					return SGL_ERR_PARM - 0 ;	\
							if (_sgl->type != SGL_CTRL_GRAPH)	return SGL_ERR_TYPE ;		\
							SGL_GRAPH_T *g = _sgl->ex ;										\
							if (g == NULL)						return SGL_ERR_INT ;

/*----------------------------------------------------------------------------- Axis & Scales --*/

/*
	User functions use an ID {SGL_LEFT, SGL_BOTTOM,..} to designate an axis.
	This module uses 2 indexes to identiify an axis:
		i = {0: left or right axis, 1: top or bottom axis}
		j = {0: left or top axis, 1: right or bottom axis}

	The RectMember macro returns the ID from the i & j indexes.
	The getAxis returns a pointer on the axis selected by its ID.
*/

static SGL_AXIS_T* getAxis(SGL_GRAPH_T *graph, int iaxis)	/* returns a pointer on an axis		*/
{
	int i, j ;												/* [H|V][begin|end]					*/	
	switch(iaxis)
	{
		case SGL_LEFT :		i = 0 ; j = 0 ; break ;
		case SGL_RIGHT :	i = 0 ; j = 1 ; break ;
		case SGL_TOP :		i = 1 ; j = 0 ; break ;
		case SGL_BOTTOM :	i = 1 ; j = 1 ; break ;
		default :			return NULL ;
	}
	
	return &(graph->axis[i][j]) ;
}

int SGL_GraphAxisSet(HWND hwnd, int axisID, SGL_GRAPH_AXIS_T* uAxis)
{
	CHECK_OBJ(hwnd, graph) ;
	SGL_AXIS_T *ax = getAxis(graph, axisID) ;				/* current axis						*/
	if (ax == NULL)		return SGL_ERR_PARM - 1 ;
	ax->scale = 0 ;											/* guess wrong parameters			*/

	if (uAxis == NULL)	return 0 ;							/* axis removal						*/
	if (uAxis->lowValue == uAxis->highValue)				/* check high/low					*/
		return SGL_ERR_PARM - 2 ;

	if (uAxis->interval != 0.0)								/* linear scale						*/
	{
		ax->scale = SCALE_LIN ;
		uAxis->ntick = max(0, uAxis->ntick) ;
	}
	else													/* log scale						*/
	{
		ax->scale = SCALE_LOG ;
		if (uAxis->lowValue <= 0.0 ||						/* check high/low					*/
			uAxis->lowValue >= uAxis->highValue) 
				return -1 ;									/* values must be >0 and increasing	*/
	}

	if (uAxis->grid < 0) uAxis->grid = 0 ;
	if (uAxis->grid > 2) uAxis->grid = 2 ;

	ax->highValue = uAxis->highValue ;						/* success							*/
	ax->lowValue = uAxis->lowValue ;
	ax->interval = fabs(uAxis->interval) ;					/* ignore the sign of the interval	*/
	ax->ntick = uAxis->ntick ;
	ax->labelCB = uAxis->labelCB ;
	ax->grid = uAxis->grid ;
	ax->color = uAxis->color ;
	return 0 ;
}

int SGL_GraphAxisGet(HWND hwnd, int axisID, SGL_GRAPH_AXIS_T* uAxis)
{
	CHECK_OBJ(hwnd, graph) ;
	SGL_AXIS_T *ax = getAxis(graph, axisID) ;				/* current axis						*/
	if (ax == NULL)		return SGL_ERR_PARM - 1 ;
	if (uAxis == NULL)	return SGL_ERR_PARM - 2 ;

	uAxis->lowValue		= ax->lowValue ;
	uAxis->highValue	= ax->highValue ;
	uAxis->interval		= ax->interval ;
	uAxis->ntick		= ax->ntick ;
	uAxis->labelCB		= ax->labelCB ;
	uAxis->grid			= ax->grid ;
	uAxis->color		= ax->color ;
	return 0 ;
}

int SGL_GraphUserToPixel(HWND hwnd, int axisID, double x)
{
	CHECK_OBJ(hwnd, graph) ;
	SGL_AXIS_T *ax = getAxis(graph, axisID) ;				/* current axis						*/
	if (ax == NULL)		return SGL_ERR_PARM - 1 ;

	int result = user2pixel(ax, x) ;
	if (result < 0)
		result = SGL_ERR_PARM - 2 ;
	return result ;
}

int SGL_GraphPixelToUser(HWND hwnd, int axisID, int xp, double *x)
{
	CHECK_OBJ(hwnd, graph) ;
	SGL_AXIS_T *ax = getAxis(graph, axisID) ;				/* current axis						*/
	if (ax == NULL)		return SGL_ERR_PARM - 1 ;
	if (x == NULL)		return SGL_ERR_PARM - 3 ;
	return pixel2user(ax, xp, x) ;
}

/*----------------------------------------------------------------------------------- Aspects --*/

int SGL_GraphMarginSet(HWND hwnd, RECT *margin)
{
	CHECK_OBJ(hwnd, graph) ;
	if (margin == NULL)								/* if NULL: reset values to 0		*/
	{
		graph->margin.left = graph->margin.left   = 0 ;
		graph->margin.top  = graph->margin.bottom = 0 ;
	}
	else
		graph->margin = *margin ;
	return 0 ;
}

int SGL_GraphMarginGet(HWND hwnd, RECT *margin)
{
	CHECK_OBJ(hwnd, graph) ;
	if (margin == NULL)		return SGL_ERR_PARM - 1 ;
	*margin = graph->margin ;
	return 0 ;
}

int SGL_GraphPlotRectGet(HWND hwnd, RECT *plotRect)
{
	CHECK_OBJ(hwnd, graph) ;
	if (plotRect == NULL)	return SGL_ERR_PARM - 1 ;
	*plotRect = graph->Prect ;
	return 0 ;
}

int SGL_GraphTickLengthSet(HWND hwnd, int tickLen)
{
	CHECK_OBJ(hwnd, graph) ;
	graph->tickl = tickLen ;
	return 0 ;
}

int SGL_GraphTickLengthGet(HWND hwnd, int *tickLen)
{
	CHECK_OBJ(hwnd, graph) ;
	if (tickLen == NULL)		return SGL_ERR_PARM - 1 ;
	*tickLen = graph->tickl ;
	return 0 ;
}

int SGL_GraphBGcolorSet(HWND hwnd, int layer, COLORREF bgColor)
{
	CHECK_OBJ(hwnd, graph) ;
	if (layer < 0 || layer >= MAX_LAYERS)
		return SGL_ERR_PARM - 1 ;
	else
		graph->trColor[layer] = bgColor ;
	return 0 ;
}

int SGL_GraphBGcolorGet(HWND hwnd, int layer, COLORREF *bgColor)
{
	CHECK_OBJ(hwnd, graph) ;
	if (layer < 0 || layer >= MAX_LAYERS)	return SGL_ERR_PARM - 1 ;
	if (bgColor == NULL)					return SGL_ERR_PARM - 2 ;
	*bgColor = graph->trColor[layer] ;
	return 0 ;
}

/*-------------------------------------------------------------------------------------- Plot --*/

int SGL_GraphPlotFunctionSet(HWND hwnd, SGL_GRAPH_PLOTCB plotFunc)
{
	CHECK_OBJ(hwnd, graph) ;
	graph->plotCB = plotFunc ;
	return 0 ;
}

int SGL_GraphPlotFunctionGet(HWND hwnd, SGL_GRAPH_PLOTCB *plotFunc)
{
	CHECK_OBJ(hwnd, graph) ;
	if (plotFunc == NULL)
		return SGL_ERR_PARM - 1 ;
	*plotFunc = graph->plotCB ;
	return 0 ;
}

int SGL_GraphPlotRequest(HWND hwnd, int layer, int item)
{
	CHECK_OBJ(hwnd, graph) ;
	if (layer >= MAX_LAYERS)
		return SGL_ERR_PARM - 1 ;
	else
		PostMessage(hwnd, WM_USER, (WPARAM) layer, (LPARAM) item) ;
	return 0 ;
}

int SGL_GraphClear(HWND hwnd, int layer)
{
	CHECK_OBJ(hwnd, graph) ;
	if (layer < 0 || layer >= MAX_LAYERS)
		return SGL_ERR_PARM - 1 ;
	else if (layer == 0)											/* case background			*/
		backgroundPaint(graph, graph->hdcMem[layer], 0) ;			/* background color only	*/
	else
		bitmapClear(graph, layer) ;
	return 0 ;
}


/*========================================================================== WINDOW PROCEDURE ==*/

static LRESULT graphProc(HWND hwnd, SGL_T *sgl, UINT message, WPARAM wParam, LPARAM lParam)
{
	LRESULT result = DEFPROC ;						/* default result: no message processed		*/
	SGL_GRAPH_T *graph = sgl->ex ;
	HDC hdc ;
	int layer ;

	switch (message)
	{
		case WM_SIZE :										/* resize all						*/
		    GetClientRect(sgl->hwnd, &(graph->Prect)) ;		/* get the working window			*/
			hdc = GetDC(sgl->hwnd) ;
			for (layer = 0 ; layer < MAX_LAYERS + 1 ; layer++)
			{
				bitmapRemove(graph, layer) ;				/* purge layers (bitmap)			*/
				if (layer == 0 || layer == MAX_LAYERS)		/* create background and stacked	*/
					bitmapCreate(graph, layer) ;						/* layers only			*/
			}
			ReleaseDC(graph->sgl->hwnd, hdc) ;

		    graph->Prect.left   += SIZE(graph->margin.left) ;	/* substract margins			*/
		    graph->Prect.right  -= SIZE(graph->margin.right) ;
		    graph->Prect.top    += SIZE(graph->margin.top) ;
		    graph->Prect.bottom -= SIZE(graph->margin.bottom) ;

			for (size_t i = 0 ; i < 2 ; i++)				/* for all axes						*/
			{
				for (size_t j = 0 ; j < 2 ; j++)			/* compute the scale factors		*/
				{
			        SGL_AXIS_T *ax = &graph->axis[i][j] ;
			        if (ax->scale == 0) continue ;				/* case axis not used			*/

			        int alen ;									/* axis (or grid) length		*/
			        if (i == 0)										/* for left or right axis	*/
			        {
						ax->gbeg = (j == 0) ? graph->Prect.left : graph->Prect.right - 1 ;
		                ax->s0 = graph->Prect.bottom - 1 ;
		                alen = graph->Prect.top - graph->Prect.bottom + 1 ;
					}
					else										/* for top or bottom axis		*/
					{
						ax->gbeg = (j == 0) ? graph->Prect.top : graph->Prect.bottom - 1 ;
						ax->s0 = graph->Prect.left ;
						alen = graph->Prect.right - graph->Prect.left - 1 ;
			        }

					if (ax->scale == SCALE_LOG)					/* user to pixel coefficients	*/
						ax->sc = (double) alen / (log10(ax->highValue / ax->lowValue)) ;
					else
						ax->sc = (double) alen / (ax->highValue - ax->lowValue) ;
				}
		    }

			if (graph->plotCB)									/* request a user redraw		*/
				graph->plotCB(sgl->hwnd, NULL, -1, 0) ;
			result = 0 ;
			break ;

	    case WM_DESTROY :
			for (layer = 0 ; layer < MAX_LAYERS + 1 ; layer++)
			{
				bitmapRemove(graph, layer) ;
				DeleteDC(graph->hdcMem[layer]) ;
			}
	        return 0 ;

		case WM_MOUSEWHEEL :								/* mouse wheel event, don't remove!	*/
			return 1 ;												/* undocumented behavior	*/

		case WM_USER :										/* RTG message: plot something		*/
		{
			if (graph->plotCB == NULL) break ;

			layer = (int) wParam ;
			if (layer < 0)
				graph->plotCB(sgl->hwnd, NULL, -1, 0) ;
			else
			{
				if (graph->hBitmap[layer] == NULL)				/* if not found: create layer	*/
				{
					bitmapCreate(graph, layer) ;
					bitmapClear(graph, layer) ;
				}

				int item = (int) lParam ;
				if (layer == 0)
					backgroundPaint(graph, graph->hdcMem[layer], item) ;
				else
					graph->plotCB(sgl->hwnd, graph->hdcMem[layer], layer, item) ;
			}
			break ;
		}

		case WM_ERASEBKGND :
			result = -1 ; 
			break ;

 		case WM_PAINT :	
		{
			PAINTSTRUCT ps ;
			HDC hdcTemp = graph->hdcMem[MAX_LAYERS] ;
			hdc = BeginPaint(hwnd, &ps) ;
			RECT rect ;
			GetClientRect(graph->sgl->hwnd, &rect) ;

			layer = 0 ;										/* copy background layer first		*/
			if (graph->hBitmap[0] == NULL)
				SGL_Log(ERR, "No background bitmap") ;
			BitBlt(hdcTemp, 0, 0, RECT_GETWH(0, rect), RECT_GETWH(1, rect),	/* to client area	*/
						graph->hdcMem[layer], 0, 0, SRCCOPY) ;
															/* next layers:						*/
			int x0 = graph->Prect.left ;							/* destination: plot area	*/
			int y0 = graph->Prect.top ;
			int w = RECT_GETWH(0, graph->Prect) ;
			int h = RECT_GETWH(1, graph->Prect) ;

			for (layer = 1 ; layer < MAX_LAYERS ; layer++)
			{														/* copy if exists			*/
				if (graph->hBitmap[layer])							/* with transparency		*/
				{
					TransparentBlt(hdcTemp, x0, y0, w, h, graph->hdcMem[layer], x0, y0, w, h, 
										graph->trColor[layer]) ;
				}
			}
			BitBlt(hdc, 0, 0, RECT_GETWH(0, rect), RECT_GETWH(1, rect),		/* to client area	*/
						hdcTemp, 0, 0, SRCCOPY) ;

			EndPaint(hwnd, &ps) ;
			result = 0 ;
			break ;
		}
	}
	return result ;
}
