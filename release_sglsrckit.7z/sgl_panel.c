/*================================================================================= SGL_PANEL.C ==
SGL PANEL class.

This part of the SGL core handles panels and the grid layout.

==================================================================================================
date       author			update
----       ------			------
14/06/..   h serindat		creation start
15/09/04					v1.0 - first release
15/10/15					v1.1 - new feature: panel sizing - new function SGP_ResizeInstall()
															 - updated: SGL_PANEL_T, panelProc()
								   resize process corrected  - new function paneResize()
                                                             - updated: layoutResize()
								   SGL__panelNew() minor update: default args of CreateWindowEx()
								   resize functions updated
16/01/11					v1.2 - winProc renamed sglProc to prevent confusion
16/03/27					v1.3 - panelProc: no resize if move event happens first
16/07/06					       SGL_PanelNoExitSet[Get] functions removed
							       update of internal tools
================================================================================================*/

#include "sgl_base_.h"
#include "sgl_panel.h"
#include "sgl_panel_.h"
#include <stdio.h>

#define GRIDMAX	60
typedef struct								/* specific object data (not duplicated)			*/
{
	int ipad[2][2] ;						/* internal padding [hor|vert][before|after]		*/
	int gridWidth[2][GRIDMAX] ;				/* grid size (with/heigh of cells)					*/

											/* used by top windows only							*/
	SGL_RESIZECB resizeCB ;							/* resize callback function					*/
	HWND resizedHwnd ;								/* resized panel or control					*/
	int widthMin, heightMin ;						/* minimum size of resizedHwnd				*/
} SGL_PANEL_T ;

#define ISPANEL(sgl) ((sgl)->type == SGL_PANEL ||					\
					  (sgl)->type == SGL_ROUNDEDFRAME ||			\
					  (sgl)->type == SGL_HIDDENFRAME)

static void panelResize(SGL_T *sgl) ;
static int parmIgnore(SGL_T *sgl, int check, int opt) ;


/*========================================================================== LAYOUT FUNCTIONS ==*/

#define PDEBUG (SGLdebug & 0x0002 ? STD : NONE)				/* debug message option				*/

/*----------------------------------------------------------------------------------------------*/
static void objStrech(SGL_T *sgl, int i, int availableSize)
{
	int sizeIncrease = availableSize - RECT_GETWH(i, sgl->rect) ;
	if (sizeIncrease <= 0)
		return ;

	SGL_Log(PDEBUG, "STRETCH %16s  %s=%d", sgl->title, i ? "H" : "W", availableSize) ;
	RECT_SETWH(i, sgl->rect, availableSize) ;			/* strech object						*/

	if (ISPANEL(sgl))									/* stretch grid							*/
	{
		int n, o ;
		int *gSize = ((SGL_PANEL_T*) sgl->ex)->gridWidth[i] ;
		for (o = n = 0 ; o < GRIDMAX ; o++)
		{
			if (gSize[o])
				n++ ;									/* number of cells containing an object	*/
		}

		for (o = 0 ; o < GRIDMAX ; o++)
		{
			if (gSize[o])
			{
				int add = sizeIncrease / (n--) ;		/* procedure to prevent rounding error	*/
				gSize[o] += add ;						/* and reach exactly sizeIncrease		*/
				sizeIncrease -= add ;
			}
		}
	}
	return ;
}

/*----------------------------------------------------------------------------------------------*/
static int layoutResize(HWND hwnd, int level)	/* set the size of layout cells 				*/
{
	int i, j ;

	SGL_T* sgl = SGL__getStruct(hwnd) ;
	if (sgl == NULL)								/* skip non SGL objects						*/
		return - 1 ;

	RECT *rect = &(sgl->rect) ;

	int (*gridWidth)[GRIDMAX] = NULL ;				/* object size + parent internal padding	*/
	if (ISPANEL(sgl))
	{
		SGL_PANEL_T *panel = sgl->ex ;
		gridWidth = panel->gridWidth ;

		for (i = 0 ; i < 2 ; i++)						/* reset all sizes						*/
		{
			for (j = 0 ; j < GRIDMAX ; j++)
				gridWidth[i][j] = 0 ;
		}

		HWND hwndChild = GetTopWindow(hwnd) ;			/* scan children (recursive call)		*/
	    while (hwndChild)
	    {
			int e = layoutResize(hwndChild, level + 1) ;
	        if (e)
				return e ;
		    hwndChild = GetNextWindow(hwndChild, GW_HWNDNEXT) ;
	    }
	}

	SetRectEmpty(rect) ;							/* initialize the object size				*/
	int w = SIZE(sgl->borderThickness) ;			/* thickness of the SGL border				*/

	if (ISPANEL(sgl))								/* case panel								*/
		panelResize(sgl) ;
	else											/* case control								*/
	{
		if (sgl->resizeObj)
			sgl->resizeObj(sgl) ;
		else
			SGL_Log(ERROR, "%s object does not have a resize function", sgl->typeName) ;

		rect->right += 2 * w ;
		rect->bottom += 2 * w ;
	}

	RECT wRect = *rect ;							/* add the Win32 non client area			*/
	int hasMenu = ISPANEL(sgl) && GetMenu(sgl->hwnd) ;
	AdjustWindowRect(&wRect, (DWORD) GetWindowLongPtr(sgl->hwnd, GWL_STYLE), hasMenu) ;
	for (i = 0 ; i < 2 ; i++)
		RECT_SETWH(i, *rect, RECT_GETWH(i, wRect)) ;

	SGL_Log(PDEBUG, "SIZE    %16s WH=(%d, %d)",
				sgl->title, RECT_GETWH(0, *rect), RECT_GETWH(1, *rect)) ;

	if (sgl->sglParent)									/* update the size of the parent layout	*/
	{
		int (*parentWidth)[GRIDMAX] = ((SGL_PANEL_T*) sgl->sglParent->ex)->gridWidth ;
		for (i = 0 ; i < 2 ; i++)									/* for rows & columns		*/
		{
			int ow = RECT_GETWH(i, *rect) + SIZE(sgl->pad[i][0])
										  + SIZE(sgl->pad[i][1]) ;
			if (parentWidth[i][sgl->uPos[i]] < ow)
				parentWidth[i][sgl->uPos[i]] = ow ;
		}
	}
	return 0 ;
}

/*----------------------------------------------------------------------------------------------*/
static void layoutMove(HWND hwnd, int level)
/*
	This function processes recursively child objets.
	For each one, if not a top window, it computes its coordinates in its parent window:
	  - Origin of the grid in the parent window (that includes internal paddind).
	  - Width of previous objects in the grid (panelParent->gridWidth[][] computed previously
		by layourResize()).
	  - some offset if the object is not left aligned.
	The position of top windows is directly issued from the objet position, or centered on screen
	if the corrdinate is < 0.

*/
{
	SGL_T *sgl = SGL__getStruct(hwnd) ;
	if (sgl == NULL) return ;

	HWND hwndChild = GetTopWindow(hwnd) ;				/* first child							*/
    while (hwndChild)									/* scan children (recursive call)		*/
    {
        layoutMove(hwndChild, level + 1) ;
	    hwndChild = GetNextWindow(hwndChild, GW_HWNDNEXT) ;
    }

	RECT *rect = &(sgl->rect) ;							/* process object						*/
	SGL_T *sglParent = sgl->sglParent ;					/* the parent contains the layout		*/
	if (sglParent)										/* move in parent's layout				*/
	{
		SGL_PANEL_T *panelParent = (SGL_PANEL_T*) sglParent->ex ;
		for (int i = 0 ; i < 2 ; i++)					/* 1st index 0: horizontal, 1: vertical	*/
		{
			int *gridSize = panelParent->gridWidth[i] ;
			int gridOrigin[GRIDMAX + 1] ;				/* colum/row start coordinates			*/

			gridOrigin[0] = SIZE(panelParent->ipad[i][0]) ;	/* first: left/top internal padding	*/
			for (int j = 0 ; j < GRIDMAX ; j++)
				gridOrigin[j + 1] = gridOrigin[j] + gridSize[j] ;

			int maskLT = i ? SGL_TOP : SGL_LEFT ;			/* mask for left/top				*/
			int maskRB = i ? SGL_BOTTOM : SGL_RIGHT ;		/* mask for top/bottom				*/

			int offset = 0 ;								/* position offet in a cell			*/
			if (sgl->align & maskLT)						/* if left/top or strech			*/
				offset = SIZE(sgl->pad[i][0]) ;
			else if ((sgl->align & (maskLT | maskRB)) == 0)	/* if center						*/
				offset = (SIZE(sgl->pad[i][0]) - SIZE(sgl->pad[i][1]) + 
						  gridSize[sgl->uPos[i]] - RECT_GETWH(i, *rect)) / 2 ;
			else											/* if right/bottom					*/
				offset = gridSize[sgl->uPos[i]] - RECT_GETWH(i, *rect) - SIZE(sgl->pad[i][1]) ;

			RECT_MOVE(i, *rect, gridOrigin[sgl->uPos[i]] + offset) ;
		}
	}
	else												/* uPos[] is a screen position (pixel)	*/
	{
		for (int i = 0 ; i < 2 ; i++)
		{
			if (sgl->uPos[i] < 0)
				sgl->uPos[i] = (GetSystemMetrics(i ? SM_CYSCREEN : SM_CXSCREEN)
								- RECT_GETWH(i, *rect)) / 2 ;
			RECT_MOVE(i, *rect, sgl->uPos[i]) ;
		}
	}

	SetWindowPos(sgl->hwnd, 0, rect->left, rect->top,	/* set the new size and posion			*/
					RECT_GETWH(0, *rect), RECT_GETWH(1, *rect),
					SWP_FRAMECHANGED |							/* send a WM_NCCALCSIZE message	*/
					SWP_NOZORDER) ;								/* keep the Z order				*/

	if (level == 0)										/* redraw only the top window			*/
		RedrawWindow(hwnd, NULL, NULL, 0) ;

	SGL_Log(PDEBUG, "MOVE    %16s LT=(%d, %d)  WH=(%d, %d)", 
				sgl->title, rect->left, rect->top, 
				RECT_GETWH(0, *rect), RECT_GETWH(1, *rect)) ;
	return ;
}

/*----------------------------------------------------------------------------------------------*/
static void layoutStretch(HWND hwnd, int i)				/* i = 0 for columns, 1 for rows		*/
{
	SGL_T* sgl = SGL__getStruct(hwnd) ;
	if (sgl == NULL) return ;

	int mask = i ? (SGL_TOP | SGL_BOTTOM) : (SGL_LEFT | SGL_RIGHT) ;
	if (((sgl->align & mask) == mask) && sgl->sglParent)	/* stretch required					*/
	{
		int (*parentGrid)[GRIDMAX] = ((SGL_PANEL_T*) sgl->sglParent->ex)->gridWidth ;
		int size = parentGrid[i][sgl->uPos[i]]			/* size available in the parent's grid	*/
				 - SIZE(sgl->pad[i][0])					/* minus object padding					*/
				 - SIZE(sgl->pad[i][1]) ;
		objStrech(sgl, i, size) ;
	}

	HWND hwndChild = GetTopWindow(hwnd) ;				/* first child							*/
    while (hwndChild)									/* scan children (recursive call)		*/
    {
        layoutStretch(hwndChild, i) ;
	    hwndChild = GetNextWindow(hwndChild, GW_HWNDNEXT) ;
    }
	return ;
}

/*----------------------------------------------------------------------------------------------*/
void SGL__panelLayout(HWND hwnd)
{
	if (layoutResize(hwnd, 0) < 0)
		return ;										/* skip non SGL objects					*/

	layoutStretch(hwnd, 0) ;							/* process stretched objects			*/
	layoutStretch(hwnd, 1) ;
	layoutMove(hwnd, 0) ;
}


/*=============================================================================== PANEL TOOLS ==*/

/*----------------------------------------------------------------------------------------------*/
int SGL__panelCheckMaxPos(HWND parent, int left, int top)
{
	if (parent)									/* child object - coordinates are colum & row	*/
	{														/* check layout coordinates			*/
		if (left >= GRIDMAX || top >= GRIDMAX)				/* NOTE: the min value is tested	*/
			return -1 ;										/*			elswhere				*/
	}
	return 0 ;												/* OK								*/
}


/*============================================================================= PANEL OBJECTS ==*/

static LRESULT panelProc(HWND hwnd, SGL_T *sgl, UINT message, WPARAM wParam, LPARAM lParam) ;

/*----------------------------------------------------------------------------------------------*/
int  SGL__panelInit(void) { return 0 ; }			/* set the local data						*/
void SGL__panelExit(void) { return ; }

/*----------------------------------------------------------------------------------------------*/
int SGL__panelNew(SGL_T *sgl)						/* create a new panel						*/
/*------------------------------------------------------------------------------------------------
Design notes:

	When creating the window, the size and position could be set to 0; the layout functions will
	set the right values later. But things go wrong if a menu is intalled before the doing the
	layout: the window remains sticked top left.
	In fact, the position should be set when created.
------------------------------------------------------------------------------------------------*/
{
	if (!ISPANEL(sgl)) return SGL_ERR_TYPE ;

	NEW(SGL_PANEL_T, panel) ;
	size_t i, j ;

	if (sgl->ex)											/* case duplicate					*/
		*panel = *(SGL_PANEL_T*)sgl->ex ;
	else													/* case new							*/
	{															/* default values				*/
		sgl->parmIgnore = parmIgnore ;							/* check for std attributes		*/
		sgl->align = SGL_LEFT | SGL_RIGHT | SGL_TOP | SGL_BOTTOM ;
		switch (sgl->type)
		{
			case SGL_PANEL :
				sgl->typeName = "PANEL" ;
				if (sgl->sglParent && sgl->uStyle)					/* check uStyle				*/
					return SGL_ERR_PARM - 2 ;						/*	3rd arg of SGL_New()	*/
				sgl->borderThickness = sgl->sglParent ? SGL_defPad : 0 ;
				sgl->borderStyle = SGL_BORDER_ETCHED_DOWN ;
				sgl->sglProc = panelProc ;
				for (i = 0 ; i < 2 ; i++)						/* default padding				*/
					for (j = 0 ; j < 2 ; j++)
						panel->ipad[i][j] = SGL_defPad ;
				break ;

			case SGL_HIDDENFRAME :
				sgl->typeName = "HIDDEN_FRAME" ;
				if (sgl->sglParent == NULL)							/* check parent				*/
					return SGL_ERR_PARM ;							/*	1st arg of SGL_New		*/
				if (sgl->uStyle)
					return SGL_ERR_PARM - 2 ;
				for (i = 0 ; i < 2 ; i++)						/* default padding				*/
					for (j = 0 ; j < 2 ; j++)
						panel->ipad[i][j] = sgl->pad[i][j] = 0 ;
				break ;

			case SGL_ROUNDEDFRAME :
				sgl->typeName = "ROUNDED_FRAME" ;
				if (sgl->sglParent == NULL)
					return SGL_ERR_PARM ;
				switch (sgl->uStyle)
				{
					case DT_LEFT :
					case DT_CENTER :
					case DT_RIGHT :
						break ;
					default :
						return  SGL_ERR_PARM - 2 ;
				}
				sgl->borderThickness = - 12 ;
				sgl->sglProc = panelProc ;
				for (i = 0 ; i < 2 ; i++)							/* default padding			*/
					for (j = 0 ; j < 2 ; j++)
						panel->ipad[i][j] = SGL_defPad ;
				break ;
		}
	}

	sgl->ex = panel ;

	int createStyle = sgl->winStyle | ((sgl->sglParent == NULL) ? sgl->uStyle : 0) ;
	sgl->hwnd = CreateWindowEx(0, MAINCLASSNAME, sgl->title, createStyle,
							    sgl->uPos[0], sgl->uPos[1], 0, 0,
							    sgl->hwndParent, (HMENU) 0, SGL__instance, NULL) ;
	if (sgl->hwnd == NULL)
		return SGL_ERR_ALLOC ;

	return 0 ;
}

/*----------------------------------------------------------------------------------------------*/
static void panelResize(SGL_T *sgl)					/* resize a panel (client area only)		*/
{
	RECT *rect = &(sgl->rect) ;
	SGL_PANEL_T *panel = sgl->ex ;

	SetRectEmpty(rect) ;							/* initialize the object size				*/

	int w = SIZE(sgl->borderThickness) ;			/* thickness of the SGL border				*/
	if (sgl->type == SGL_ROUNDEDFRAME)
		w = max(w, SGL__getFontHeight(sgl)) ; 

	for (int i = 0 ; i < 2 ; i++)					/* for width and height						*/
	{
		int pixelSize ;
		if (sgl->uSize[i])								/* size defined by user					*/
			pixelSize = SIZE(sgl->uSize[i]) ;
		else
		{												/* automatic size						*/
			pixelSize = SIZE(panel->ipad[i][0]) 			/* internal padding					*/
					+ SIZE(panel->ipad[i][1]) ;
			for (int j = 0 ; j < GRIDMAX ; j++)				/* plus size of the children		*/
				pixelSize += panel->gridWidth[i][j] ;
		}

		pixelSize += 2 * w ;								/* plus 2 x SGL border thickness	*/
		RECT_SETWH(i, *rect, pixelSize) ;
	}
	return ;
}


/*========================================================================= SET/GET FUNCTIONS ==*/

#define CHECK_OBJ(h, p)		SGL_T* _sgl = SGL__getStruct(h) ;								\
							if (_sgl == NULL)					return SGL_ERR_PARM - 0 ;	\
							if (!ISPANEL(_sgl))					return SGL_ERR_TYPE ;		\
							SGL_PANEL_T *p = _sgl->ex ;										\
							if (p == NULL)						return SGL_ERR_INT ;

int SGL_PanelIpaddingSet(HWND hwnd, RECT *ipad)
{
	CHECK_OBJ(hwnd, panel) ;
	if (ipad == NULL)									/* if NULL: reset values to 0			*/
	{
		panel->ipad[0][0] = panel->ipad[0][1] = 0 ;
		panel->ipad[1][0] = panel->ipad[1][1] = 0 ;
	}
	else
	{
		panel->ipad[0][0] = ipad->left ;
		panel->ipad[0][1] = ipad->right ;
		panel->ipad[1][0] = ipad->top ;
		panel->ipad[1][1] = ipad->bottom ;
	}
	return 0 ;
}

int SGL_PanelIpaddingGet(HWND hwnd, RECT *ipad)
{
	CHECK_OBJ(hwnd, panel) ;
	if (ipad == NULL)		return SGL_ERR_PARM - 1 ;
	ipad->left	= panel->ipad[0][0] ;
	ipad->right	= panel->ipad[0][1] ;
	ipad->top	= panel->ipad[1][0] ;
	ipad->bottom	= panel->ipad[1][1] ;
	return 0 ;
}

int SGL_ResizeInstall(HWND hwnd, int widthMin, int heightMin, SGL_RESIZECB resizeCB)
{
	HWND main = hwnd ;											/* top window resized			*/
	for ( ; GetParent(main) ; )
		main = GetParent(main) ;

	DWORD style = (DWORD) GetWindowLongPtr(main, GWL_STYLE) ;	/* set its border				*/
	if (widthMin || heightMin)
		style |= WS_SIZEBOX ;
	else
		style &= ~WS_SIZEBOX ;
	SetWindowLongPtr(main, GWL_STYLE, style) ;

	SGL_T *sgl = SGL__getStruct(main) ;							/* set its resizing parameters	*/
	if (sgl == NULL || sgl->type != SGL_PANEL)
		return SGL_ERR_TYPE ;
	SGL_PANEL_T *panel = sgl->ex ;

	panel->widthMin  = widthMin ;
	panel->heightMin = heightMin ;
	panel->resizedHwnd = hwnd ;
	panel->resizeCB = resizeCB ;
	return 0 ;
}


/*================================================================== EXPORTED LOCAL FUNCTIONS ==*/

/*----------------------------------------------------------------------------------------------*/
static int parmIgnore(SGL_T *sgl, int check, int opt)
{
	switch (sgl->type)
	{
		case SGL_PANEL :
			if (sgl->hwndParent == NULL && 
				(check == CHECK_BORDERSTYLE || check == CHECK_BORDERTHICKNESS))
				return 1 ;
			break ;
		case SGL_HIDDENFRAME :
			if (check == CHECK_COLORS || 
				check == CHECK_BORDERSTYLE || 
				check == CHECK_BORDERTHICKNESS)
				return 1 ;
			break ;
		case SGL_ROUNDEDFRAME :
			if (check == CHECK_BORDERSTYLE)
				return 1 ;
			break ;
	}
	return 0 ;
}

/*----------------------------------------------------------------------------------------------*/
static LRESULT panelProc(HWND hwnd, SGL_T *sgl, UINT message, WPARAM wParam, LPARAM lParam)
{
	LRESULT result = DEFPROC ;						/* default result: no message processed		*/

	if (sgl->sglParent) switch (message)				/*======= FOR CHILD WINDOWS ONLY =======*/
	{													/* draw the non client area				*/
		case WM_NCCALCSIZE :
		{
			int w = 0 ;										/* width of the non client area		*/
			switch (sgl->type)
			{
				case SGL_ROUNDEDFRAME :
					w = max(SIZE(sgl->borderThickness), SGL__getFontHeight(sgl)) ;
					break ;
				case SGL_PANEL :
					w = SIZE(sgl->borderThickness) ;
					break ;
			}
			RECT *clientRect = (RECT*) lParam ;				/* stretch the client area			*/
			InflateRect(clientRect, - w, - w) ;
			break ;
		}

		case WM_NCPAINT :
		{
			HDC hdcW = GetWindowDC(hwnd) ;
				RECT rectW ;								/* non client rectangle				*/
				GetWindowRect(hwnd, &rectW) ;
				rectW.right -= rectW.left ; rectW.left = 0 ;		/* left = 0, right = width	*/
				rectW.bottom -= rectW.top ; rectW.top = 0 ;			/* top = 0, bottom = height	*/

				COLORREF color ;							/* border color						*/
				if (sgl->borderColor != -1)							/* case defined				*/
					color = SGL_ColorDim(SYSCOLOR(sgl->borderColor), sgl->context.dimmed) ;

				if (sgl->type == SGL_ROUNDEDFRAME)
				{
					if (sgl->borderColor == -1)						/* case undefined color		*/
						color = sgl->context.fgdColor ;						/* idem foreground	*/
					HPEN pen = CreatePen(PS_SOLID, SIZE(sgl->borderThickness), color) ;
					SelectObject(hdcW, pen) ;
					SelectObject(hdcW, GetStockObject(NULL_BRUSH)) ;

					RECT frame = rectW ;							/* draw rounded rectangle	*/
					int fh1 = SGL__getFontHeight(sgl) + 1 ;
					InflateRect(&frame, - fh1 / 2, - fh1 / 2) ;
					RoundRect(hdcW, frame.left, frame.top, frame.right, frame.bottom, fh1, fh1) ;

					DeleteObject(pen) ;

					if (sgl->title && strlen(sgl->title))			/* draw title				*/
					{
						char lTitle[128] ;
						sprintf_s(lTitle, 128, " %s ", sgl->title) ;
						SetTextColor(hdcW, sgl->context.fgdColor) ;
						SetBkColor(hdcW, sgl->sglParent->context.bgdColor) ;
						SelectObject(hdcW, SGL__getFont(sgl)) ;

						InflateRect(&rectW, - 1.4 * fh1, 0) ;		/* left/right margin		*/
						DrawText(hdcW, lTitle, -1, &rectW, 
								 DT_NOPREFIX | DT_SINGLELINE | DT_TOP | sgl->uStyle) ;
					}
				}
				else
				{
					if (sgl->borderColor == -1)						/* case undefined color		*/
						color = sgl->context.bgdColor ;						/* idem background	*/
					SGL_BorderDraw(hdcW, &rectW, sgl->borderStyle, SIZE(sgl->borderThickness), 
							color, sgl->context.dimmed) ;
				}
			ReleaseDC(hwnd, hdcW) ;

			ShowScrollBar(hwnd, SB_HORZ, sgl->scrollBars[0]) ;
			ShowScrollBar(hwnd, SB_VERT, sgl->scrollBars[1]) ;
			break ;
		}
	}
	else												/*========== FOR TOP WINDOWS ===========*/
	{													/* resize processing					*/
		static RECT *rectMain, rectMainPrev, rectMainNew ;
		SGL_PANEL_T *panel = sgl->ex ;

		switch (message)
		{
			case WM_NCLBUTTONDBLCLK :								/* prevent auto size		*/
				result = 0 ;
				break ;

			case WM_ENTERSIZEMOVE :
				if (panel->resizedHwnd)
				{
					GetWindowRect(hwnd, &rectMainPrev) ;
					rectMainNew = rectMainPrev ;
				}
				result = 0 ;
				break ;

			case WM_SIZING :
				if (panel->resizedHwnd)
				{
					rectMain = (RECT*) lParam;
					if (panel->widthMin == 0)
					{
						rectMain->left   = rectMainPrev.left ;
						rectMain->right  = rectMainPrev.right ;
					}
					if (panel->heightMin == 0)
					{
						rectMain->top    = rectMainPrev.top ;
						rectMain->bottom = rectMainPrev.bottom ;
					}
					rectMainNew = *rectMain ;
					result = 1 ;
				}
				break;

			case WM_EXITSIZEMOVE :
			{
				if (panel->resizedHwnd)
				{
					int wo = rectMainNew.right  - rectMainNew.left
						  - (rectMainPrev.right - rectMainPrev.left) ;
					int ho = rectMainNew.bottom  - rectMainNew.top
						  - (rectMainPrev.bottom - rectMainPrev.top) ;

					if (wo || ho)						/* do nothing if no resizing occurred	*/
					{
						if (panel->resizeCB)
						{
							if (panel->resizeCB(panel->resizedHwnd, wo, ho) == 0)
								SGL_Layout(hwnd) ;
						}
						else
						{
							RECT rectResize ; 
							GetClientRect(panel->resizedHwnd, &rectResize) ;

							if (hwnd == panel->resizedHwnd)
								wo = ho = 0 ;
							int widthNew  = max(wo + rectResize.right,  SIZE(panel->widthMin)) ;
							int heightNew = max(ho + rectResize.bottom, SIZE(panel->heightMin)) ;

							SGL_SizeSet(panel->resizedHwnd, SGL_WIDTH, widthNew) ;
							SGL_SizeSet(panel->resizedHwnd, SGL_HEIGHT, heightNew) ;
							SGL_Layout(hwnd) ;
						}
					}

					result = 0 ;
				}
				break;
			}
		}
	}

	switch (message)									/*========== FOR ALL WINDOWS ===========*/
	{
		case WM_ERASEBKGND :							/* erase background						*/
		{
			HDC hdc = (HDC) wParam ;
			RECT rect ; GetClientRect(hwnd, &rect) ;
			SetDCBrushColor(hdc, sgl->context.bgdColor) ;
		    FillRect(hdc, &rect, GetStockObject(DC_BRUSH)) ;
			result = 1 ;
		}
	}

	return result ;
}
