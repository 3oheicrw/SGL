int SGL__popupInit(void) ;
void SGL__popupExit(void) ;
