int SGL__editInit(void) ;
int SGL__editNew(SGL_T *sgl) ;
void SGL__editExit(void) ;
