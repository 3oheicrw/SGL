/*================================================================================= SGL_TOOLS.C ==
SGL main core functions

The header files are:
  - sgl_base.h	for public functions (availabe to the application programmer)
  - sgl_base_.h	for SGL exclusive use 

==================================================================================================
date       author			update
----       ------			------
16/07/06   h serindat		v1.3 - creation
16/08/26					       string label updated
18/08/22					v1.3.2 color selector
								- minor changes (COLORS_CB and appearance)
								- SGL_ColorsConfigure() : return codes
								- SGL_ColorsSet(): new argument
18/11/23					v1.3.3 SGL_ProfileIntGet()
								- bug corrected (processing bad formatted strings)
								- no more use of toupper()
================================================================================================*/
#include <stdio.h>
#include <math.h>

#include "sgl_base_.h"
#include "sgl_tools.h"
#include "sgl_button.h"
#include "sgl_popup.h"
#include "sgl_graph.h"

#pragma warn(disable: 2118 2216)	/* disable some warnings					*/
				/* 2118: Parameter {parameter_name} is not referenced.			*/
				/* 2216: The return value from {function_name} is never used.	*/

/*==============================================================================================*/
/*																								*/
/*				INIFILE TOOLS																	*/
/*																								*/
/*==============================================================================================*/

static char iniFile[MAX_PATH] = { 0 } ;

/*----------------------------------------------------------------------------------------------*/
char *SGL_ProfileInit(char *fileName)
{
	if (fileName)											/* new configuration file			*/
	{
		if (fileName[0])
			strncpy(iniFile, fileName, MAX_PATH - 1) ;
		else												/* default configuration file		*/
		{
			GetModuleFileName(0, iniFile, MAX_PATH) ;			/* build iniFile				*/
			char *cp = strrchr(iniFile, '.') ;					/* search '.'					*/
			if (cp)
				strcpy(cp, ".ini") ;							/* if found: replace extension	*/
			else
				strcpy(iniFile, "*") ;							/* else: error					*/
		}
	}
	return iniFile ;
}

/*----------------------------------------------------------------------------------------------*/
void SGL_ProfileStringGet(char *section, char *key, char *l, int size)
{
	GetPrivateProfileString(section, key, "", l, size, iniFile) ;	/* get string				*/

	char *p = strchr(l, ';') ;										/* remove comment			*/
	if (p) *p = '\0' ;

	for (p = l + strlen(l) - 1 ; p > l ; p--)						/* remove trailing spaces	*/
	{																/*	and tabs				*/
		if (*p == ' ' || *p == '\t')
			*p = '\0' ;
		else
			break ;
	}
}

/*----------------------------------------------------------------------------------------------*/
void SGL_ProfileStringSet(char *section, char *key, char *l)
{
	WritePrivateProfileString(section, key, l, iniFile) ;
}

/*----------------------------------------------------------------------------------------------*/
int SGL_ProfileIntGet(char *section, char *key, int defValue)
{
	char l[64], *endptr ;
	SGL_ProfileStringGet(section, key, l, 64) ;					/* get string field				*/
	for (char *c = l ; *c ; c++)								/* convert to lower case		*/
		if (*c > 9) *c |= 0x20 ;

	int hex = (l[0] == '0' && l[1] == 'x') ? 1 : 0 ;			/* set format					*/
	int result = strtol(l, &endptr, hex ? 16 : 10) ;			/* convert field				*/

	if (*l == 0 || endptr == NULL || *endptr)					/* failed						*/
		result = defValue ;
	return result ;
}

/*----------------------------------------------------------------------------------------------*/
int SGL_ProfileIntSet(char *section, char *key, int value, int hex)
{
	char l[64] ;
	sprintf(l, hex ? "0X%X" : "%d", value) ;
	return WritePrivateProfileString(section, key, l, iniFile) ? 0 : -1 ;
}


/*==============================================================================================*/
/*																								*/
/*				COLOR TOOLS																		*/
/*																								*/
/*==============================================================================================*/

/*----------------------------------------------------------------------------------------------*/
COLORREF SGL_ColorInterpolate(COLORREF color0, COLORREF color1, double k)
{
	color0 = SYSCOLOR(color0) ;
	color1 = SYSCOLOR(color1) ;

	if (k <= 0.0) return color0 ;
	if (k >= 1.0) return color1 ;

	int r, g, b ;
	r = (int) (k * GetRValue(color1) + (1. - k) * GetRValue(color0)) ;
	g = (int) (k * GetGValue(color1) + (1. - k) * GetGValue(color0)) ;
	b = (int) (k * GetBValue(color1) + (1. - k) * GetBValue(color0)) ;
	return RGB(r, g, b) ;
}

/*----------------------------------------------------------------------------------------------*/
COLORREF SGL_ColorDim(COLORREF color, int dimmed)			/* returns a dimmed color			*/
{
	color = SYSCOLOR(color) ;
	if (dimmed)
	{
		int r, g, b ;
		int dest = DIMCOLOR ;
		r = (GetRValue(color) + 2 * GetRValue(dest)) / 3 ;
		g = (GetGValue(color) + 2 * GetGValue(dest)) / 3 ;
		b = (GetBValue(color) + 2 * GetBValue(dest)) / 3 ;
		return RGB(r, g, b) ;
	}
	else
		return color ;
}


/*========================================================================== HSL COLOR PICKER ==*/

static char **colorKeys ;								/* application data						*/
static char *colorSection ;
static COLORS_CB colorCB ;

#define MAX_COLORS	64
#define CMIN 0
#define CMAX 255

#define BAR	0
#define NUM	1

#define HUE 0
#define SAT	1
#define LUM	2

static HWND mainPanel = NULL ;
static HWND indexBtn, colorSample, rgbHex ;
static HWND slider[2][3] ;								/* slider[BAR|NUM][HUE|SAT|LUM]			*/

static int cColorIx ;									/* selected color: index in colorKeys	*/
static double cHSL[3] ;									/* hue (0..360), sat (..1), lum (0..1)	*/
static char aHSL[3][8] = { "", "", "" } ;				/* text representations					*/
static char aRGB[12] = "" ;

static void colorUpdate(COLORREF rgb) ;					/* update all from a RGB value			*/
static void displayUpdate(int ix) ;						/* update from cHSL value				*/
static void notif(void) ;

/*-------------------------------------------------------------------------- COLOR CONVERSION --*/
static void rgb2hsl(COLORREF rgb, double *hsl)
{
	double dr = GetRValue(rgb) / 255.0 ;
	double dg = GetGValue(rgb) / 255.0 ;
	double db = GetBValue(rgb) / 255.0 ;

	double Cmin = min(dr, min(dg, db)) ;
	double Cmax = max(dr, max(dg, db)) ;

	double mmSum  = Cmax + Cmin ;

	hsl[LUM] = mmSum / 2.0 ;
	if (Cmin == Cmax)
	{
		hsl[HUE] = 0.0 ;
		hsl[SAT] = 0.0 ;
	}
	else
	{
		double mmDiff = Cmax - Cmin ;
		if (hsl[LUM] < 0.5)
			hsl[SAT] = mmDiff / mmSum ;
		else
			hsl[SAT] = mmDiff / (2.0 - mmSum) ;

		double H ;
		if (dr == Cmax) 		H = (dg - db) / mmDiff ;
		else if (dg == Cmax)	H = (db - dr) / mmDiff + 2.0 ;
		else					H = (dr - dg) / mmDiff + 4.0 ;

		H *= 60.0 ;
		if (H < 0.0) H += 360.0 ;
		hsl[HUE] = H ;
	}
}

static double hue2rgb(double p, double q, double t)
{
	if (t < 0.0) t += 1.0 ;
	if (t > 1.0) t -= 1.0 ;
	if (t < 1.0 / 6.0)	return p + (q - p) * 6.0 * t ;
	if (t < 0.5)		return q ;
	if (t < 2.0 / 3.0)	return p + (q - p) * (2.0 / 3.0 - t) * 6.0 ;
	return p ;
}

static COLORREF hsl2rgb(double *hsl)
{
	if (hsl[SAT] == 0.0)
	{
		int c = 255.0 * hsl[LUM] ;
		return RGB(c, c, c) ;
	}
	else
	{
		double q = (hsl[LUM] < 0.5) ? hsl[LUM] * (1.0 + hsl[SAT])
									: hsl[LUM] + hsl[SAT] - hsl[LUM] * hsl[SAT] ;
		double p = 2.0 * hsl[LUM] - q ;
		double H = hsl[HUE] / 360.0 ;
		double dr = hue2rgb(p, q, H + 1.0 / 3.0) ;
        double dg = hue2rgb(p, q, H) ;
        double db = hue2rgb(p, q, H - 1.0 / 3.0) ;
		return RGB(lround(255.0 * dr), lround(255.0 * dg), lround(255.0 * db)) ; 
	}
}

/*---------------------------------------------------------------------------- COLOR SELECTOR --*/

static void selectIndex(int ix)
{
	SGL_TitleSet(indexBtn, colorKeys[ix]) ;						/* update the select button		*/
	SGL_Redraw(indexBtn) ;

	cColorIx = ix ;
																/* get value from inifile		*/
	colorUpdate(GetPrivateProfileInt(colorSection, colorKeys[ix], -1, iniFile)) ;
}

static int indexCB(HWND hwnd, UINT event, WPARAM wParm, LPARAM lParm)
{
	if (event == WM_USER)
	{
		SGL_ButtonValueSet(hwnd, 1) ;							/* maintain aspect until return	*/

		RECT rect ;												/* position of the popup menu	*/
		GetClientRect(hwnd, &rect) ;
		MapWindowPoints(hwnd, NULL, (POINT*) &rect, 2) ;

		SGL_POPUPMENU_OPTIONS_T ppm[MAX_COLORS + 1] ;			/* set menu options				*/
		int ix ;
		for (ix = 0 ; colorKeys[ix] && ix < MAX_COLORS ; ix++)
		{
			ppm[ix].state = 0 ;
			ppm[ix].text = colorKeys[ix] ;
		}
		ppm[ix].state = 0 ;
		ppm[ix].text = NULL ;

		rect.right = rect.left ;
		ix = SGL_PopupMenu(hwnd, ppm, &rect, SGL_RIGHT) ;
		if (ix >= 0)
			selectIndex(ix) ;

		SGL_ButtonValueSet(hwnd, 0) ;
	}
	return 0 ;													/* default event processing		*/
}

/*----------------------------------------------------------------------- SLIDER - BAR OBJECT --*/

static void sliderBarDraw(HWND hwnd, HDC hdc, int layer, int ix)		/* ix: the slider index	*/
{
	if (layer < 0)											/*==== SYSTEM REQUEST [draw all] ===*/
	{
		SGL_GraphPlotRequest(hwnd, 0, 1) ;								/* background			*/
		SGL_GraphPlotRequest(hwnd, 1, ix) ;								/* color background		*/
		SGL_GraphPlotRequest(hwnd, 2, ix) ;								/* slider				*/
	}

    else													/*==== USER REQUEST ================*/
	{
		RECT rect ; SGL_GraphPlotRectGet(hwnd, &rect) ;
		switch (layer)
		{
			case 1 :												/* draw background			*/
			{
				double hsl[3] = {cHSL[HUE], ix == HUE ? 1.0 : cHSL[SAT], 0.5} ;
				for (int i = 0 ; i < rect.right ; i++)
				{
					SGL_GraphPixelToUser(hwnd, SGL_BOTTOM, i, hsl + ix) ;
					SetDCPenColor(hdc, hsl2rgb(hsl)) ;
					SelectObject(hdc, GetStockObject(DC_PEN)) ;
					MoveToEx(hdc, i, rect.top, NULL) ;
					LineTo(hdc, i, rect.bottom) ;
				}
				break ;
			}

			case 2 :												/* draw cursor				*/
			{								
				SGL_GraphClear(hwnd, layer) ;						/* clear previous drawings	*/

				int markerHaffThickness = SGL_DefPaddingGet() / 2 ;	/* draw cursor				*/
				int pos = SGL_GraphUserToPixel(hwnd, SGL_BOTTOM, cHSL[ix]);
				rect.left = pos - markerHaffThickness ;
				rect.right = pos + markerHaffThickness + 1 ;
				HGDIOBJ h = GetStockObject(WHITE_BRUSH) ;
				if (ix == LUM && cHSL[LUM] >= 0.5)
					h = GetStockObject(BLACK_BRUSH) ;
				FillRect(hdc, &rect, h) ;

				switch (ix)											/* update the numeric value	*/
				{
					case HUE : sprintf(aHSL[ix], "%.0f �", cHSL[ix]) ;			break ;
					case SAT : sprintf(aHSL[ix], "%.0f %%", 100.0 * cHSL[ix]) ;	break ;
					case LUM : sprintf(aHSL[ix], "%.0f %%", 100.0 * cHSL[ix]) ;	break ;
				}
				SGL_Redraw(slider[NUM][ix]) ;
				break ;
			}
		}
	}
	SGL_Redraw(hwnd) ;
    return ;
}

static int sliderBarCB(HWND hwnd, UINT event, WPARAM wParam, LPARAM lParam)
{
	static int dragging = 0 ;
	POINT cursorPos ;
	RECT  plotRect ;

	int ix ; 
	SGL_CallbackDataGet(hwnd, (void**) &ix) ;
	switch (event)
    {
	    case WM_LBUTTONDOWN :										/* start dragging			*/
			if (dragging == 0)
			{
				SGL_CursorPositionGet(hwnd, 0, &cursorPos) ;
				SGL_GraphPlotRectGet(hwnd, &plotRect) ;
				if (PtInRect(&plotRect, cursorPos))
				{
					dragging = 1 ;
					SetCapture(hwnd) ;

					SGL_GraphPixelToUser(slider[BAR][ix], SGL_BOTTOM, cursorPos.x, cHSL + ix) ;
					displayUpdate(ix) ;
					notif() ;
				}
			}
			break ;

		case WM_MOUSEMOVE :											/* drag						*/
			if (dragging)
			{
				cursorPos.x = (short) LOWORD(lParam) ;
				SGL_GraphPlotRectGet(hwnd, &plotRect) ;
				cursorPos.x = max(cursorPos.x, plotRect.left) ;					/* clip value	*/
				cursorPos.x = min(cursorPos.x, plotRect.right - 1) ;

				SGL_GraphPixelToUser(slider[BAR][ix], SGL_BOTTOM, cursorPos.x, cHSL + ix) ;
				displayUpdate(ix) ;
				notif() ;
			}
			break ;

	    case WM_LBUTTONUP :											/* end of dragging			*/
		{
	       	dragging = 0 ;
			ReleaseCapture() ;
	        break ;
		}
	}
	return 0 ;
}

/*------------------------------------------------------------------- SLIDER - NUMERIC OBJECT --*/

static int sliderNumEditCB(WPARAM virtKey, char* s, int len, int caret, void *cbd)
{
	if (virtKey == VK_ESCAPE)
		return -1 ;
	else if (virtKey == VK_RETURN)
	{
		COLORREF c = strtol(s, NULL, 16) ;
		BYTE b = (BYTE) c ;
		BYTE g = (BYTE) (c >> 8) ;
		BYTE r = (BYTE) (c >> 16) ;
		c = RGB(r, g, b) ;
		colorUpdate(c) ;
		notif() ;
		return -1 ;
	}

	return 0 ;
}

static int sliderNumCB(HWND hwnd, UINT event, WPARAM wParam, LPARAM lParam)		/* top callback	*/
{
	if (event == WM_LBUTTONDOWN)
	{																/* install an edit popup	*/
		RECT rect ;
		GetClientRect(rgbHex, &rect) ;
		MapWindowPoints(rgbHex, NULL, (POINT*) &rect, 2) ;

		SGL_PopupEdit(rgbHex, &rect, ES_CENTER, 
						aRGB, sizeof(aRGB), sliderNumEditCB, NULL) ;
		return 1 ;
	}
	return 0 ;
}

/*------------------------------------------------------------------------------- SLIDER MAIN --*/

static int mainCB(HWND hwnd, UINT event, WPARAM wParam, LPARAM lParam)			/* close		*/
{
	if (event == WM_SYSCOMMAND && wParam == SC_CLOSE)
	{
		SGL_VisibleSet(hwnd, 0) ;
		return 1 ;
	}
	return 0 ;
}

static void notif(void)
{
	COLORREF c = hsl2rgb(cHSL) ;
	char m[16] ;
	sprintf(m, "0x%06x", c) ;

	WritePrivateProfileString(colorSection, colorKeys[cColorIx], m, iniFile) ;
	if (colorCB)
		colorCB(cColorIx, c) ;
}

static void displayUpdate(int ix)						/* update from the cHSL value			*/
{
	if (ix < 0)											/* update all bars						*/
	{
		for (ix = 0 ; ix < 3 ; ix++)
		{
			SGL_GraphPlotRequest(slider[BAR][ix], 1, ix) ;		/* update background			*/
			SGL_GraphPlotRequest(slider[BAR][ix], 2, ix) ;		/* update cursor				*/
		}
	}
	else												/* update from bar [ix]					*/
	{
		SGL_GraphPlotRequest(slider[BAR][ix], 2, ix) ;			/* update cursor				*/
		for (ix++ ; ix < 3 ; ix++)								/* and next slider backgroungs	*/
			SGL_GraphPlotRequest(slider[BAR][ix], 1, ix) ;
	}

	COLORREF rgb = hsl2rgb(cHSL) ;						/* update color sample					*/
	SGL_BGcolorSet(colorSample, rgb) ;

	sprintf(aRGB, "%02x%02x%02x", GetRValue(rgb), GetGValue(rgb), GetBValue(rgb)) ;
	int lum = GetRValue(rgb) + GetGValue(rgb) + GetBValue(rgb) ;
	SGL_FGcolorSet(colorSample, lum < 384 ? SGL_WHITE : SGL_BLACK) ;
	SGL_Redraw(colorSample) ;
}

static void colorUpdate(COLORREF rgb)				/* update all from a RGB value				*/
{
	rgb2hsl(rgb, cHSL) ;
	displayUpdate(-1) ;
}

static void sliderNew(HWND parent, int ix)
{
	static SGL_GRAPH_AXIS_T axis ;
	axis.lowValue = 0.0 ;
	axis.grid = 2 ;
	axis.color = 0 ;
	axis.labelCB = NULL ;

	HWND panel = SGL_New(parent, SGL_PANEL, 0, "Slider", 0, ix) ;
	SGL_AlignmentSet(panel, 0) ;
	SGL_PanelIpaddingSet(panel, 0) ;

	HWND h = NULL ;																	/* bar		*/
	switch (ix)
	{
		case HUE :
			h = SGL_New(panel, SGL_CTRL_GRAPH, 0, "HUE", 0, 0) ;
			SGL_GraphPlotFunctionSet(h, sliderBarDraw) ;
			axis.highValue =	360.0 ;
			axis.interval =  60.0 ;
			axis.ntick =		1 ;
			break ;
		case SAT :
			h = SGL_New(panel, SGL_CTRL_GRAPH, 0, "SAT", 0, 0) ;
			SGL_GraphPlotFunctionSet(h, sliderBarDraw) ;
			axis.highValue =	1.0 ;
			axis.interval =  0.5 ;
			axis.ntick =		1 ;
			break ;
		case LUM :
			h = SGL_New(panel, SGL_CTRL_GRAPH, 0, "LUM", 0, 0) ;
			SGL_GraphPlotFunctionSet(h, sliderBarDraw) ;
			axis.highValue =	1.0 ;
			axis.interval =  0.5 ;
			axis.ntick =		1 ;
			break ;
	}
	RECT margin = { 0 } ;
	margin.bottom = 2 * SGL_DefPaddingGet() ;
	SGL_GraphMarginSet(h, &margin);

	SGL_SizeSet(h, SGL_WIDTH,  361) ;
	SGL_SizeSet(h, SGL_HEIGHT,-200) ;

	int e = SGL_CallbackFunctionSet(h, sliderBarCB) ;
	e = SGL_CallbackDataSet(h, (void*) ix) ;
	SGL_GraphAxisSet(h, SGL_BOTTOM, &axis) ;
	slider[BAR][ix] = h ;

	h = SGL_New(panel, SGL_CTRL_BUTTON, 0, "hue", 1, 0) ;							/* num		*/
	SGL_BorderThicknessSet(h, 0) ;
	SGL_TitleSet(h, aHSL[ix]) ;
	SGL_SizeSet(h, SGL_WIDTH, -3) ;
	slider[NUM][ix] = h ;
}

/*------------------------------------------------------------------------ EXPORTED FUNCTIONS --*/

void SGL_ColorsSet(void)
{
	selectIndex(0) ;
	BringWindowToTop(mainPanel) ;
	SGL_VisibleSet(mainPanel, 1) ;
}

int SGL_ColorsConfigure(char **colorKey, char *section, COLORS_CB func)
/*------------------------------------------------------------------------------------------------
	colorKey	array of color keys												input
	section		section name for colors in the ini file							input
	func		function to be called after loading the colors					input
------------------------------------------------------------------------------------------------*/
{
	if (mainPanel == NULL)
	{
		mainPanel = SGL_New(0, SGL_PANEL, 0, "Select color", -1, -1) ;
		if (mainPanel == NULL) return (SGL_ERR_ALLOC) ;

		SGL_CallbackFunctionSet(mainPanel, mainCB) ;

		indexBtn = SGL_New(mainPanel, SGL_CTRL_PUSHBUTTON, 0, "Color index", 0, 0) ;
		SGL_CallbackFunctionSet(indexBtn, indexCB) ;
		SGL_AlignmentSet(indexBtn, SGL_LEFT | SGL_RIGHT) ;			/* width: span				*/

		HWND panel = SGL_New(mainPanel, SGL_HIDDENFRAME, 0, "Slider", 0, 1) ;
		for (int i = 0 ; i < 3 ; i++)
			sliderNew(panel, i) ;

		colorSample = SGL_New(mainPanel, SGL_PANEL, 0, "Color", 0, 3) ;
		SGL_AlignmentSet(colorSample, SGL_LEFT | SGL_RIGHT) ;		/* width: span				*/
		SGL_CallbackFunctionSet(colorSample, sliderNumCB) ;

		RECT nullRect = { 0 } ;
		HWND tmp = SGL_New(colorSample, SGL_CTRL_BUTTON, SGL_RIGHT,  "RGB", 0, 0) ;
		SGL_BorderStyleSet(tmp, SGL_BORDER_NONE) ;
		SGL_PaddingSet(tmp, &nullRect) ;
		SGL_AlignmentSet(tmp, SGL_RIGHT) ;
		SGL_CallbackFunctionSet(tmp, sliderNumCB) ;

		rgbHex = SGL_New(colorSample, SGL_CTRL_BUTTON, SGL_LEFT, "RGB hex value", 1, 0) ;
		SGL_TitleSet(rgbHex, aRGB) ;
		SGL_SizeSet(rgbHex, SGL_WIDTH, -5) ;
		SGL_BorderStyleSet(rgbHex, SGL_BORDER_NONE) ;
		SGL_AlignmentSet(rgbHex, SGL_LEFT) ;
		SGL_PaddingSet(rgbHex, &nullRect) ;
		SGL_CallbackFunctionSet(rgbHex, sliderNumCB) ;

		SGL_Layout(mainPanel) ;
		for (int ix = 0 ; ix < 3 ; ix++)					/* set background & transparency	*/
		{
			COLORREF bg = SGL_BGcolorGet(mainPanel) ;
			SGL_GraphBGcolorSet(slider[BAR][ix], 0, bg) ;
			SGL_GraphBGcolorSet(slider[BAR][ix], 1, bg) ;
			SGL_GraphBGcolorSet(slider[BAR][ix], 2, bg) ;
		}
	}

	if (section)	colorSection = section ;	else return SGL_ERR_PARM - 1 ;
	if (colorKey)	colorKeys = colorKey ;		else return SGL_ERR_PARM - 2 ;
	if (func)		colorCB = func ;			else return SGL_ERR_PARM - 3 ;
												
	for (int ix = 0 ; colorKeys[ix] && ix < MAX_COLORS ; ix++)	/* set application colors		*/
		colorCB(ix, GetPrivateProfileInt(colorSection, colorKeys[ix], -1, iniFile)) ;
	return 0 ;
}

