#define SGL_CTRL_EDIT 1300

int SGL_EditTextSet(HWND hwnd, char *text);
int SGL_EditTextAppend(HWND hwnd, char *text);
int SGL_EditTextLengthGet(HWND hwnd);
int SGL_EditTextGet(HWND hwnd, char *text, int maxLen);
