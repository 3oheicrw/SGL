/*================================================================================= SGL_POPUP.C ==
SGL POPUP controls.

The popup is automatically closed when the user hits the [return] or [Esc] keys, or clicks
outside the control.

The edit popup uses 2 windows:

	A frame window with its own class which is just a rectangle with the background color.
	It provides the necessary area between the edit control whose height and position cannot be
	precisely set. It is also receives window messages from the edit control.

	An standard popup control which is subclassed to handle some key hits, mouse scroll and
	the lost of focus.

The menu popup is very basic.
Note that the font is not rescaled by SGL. It is defined by Microsoft and only follows the
Windows desktop aspect.

==================================================================================================
date       author			update
----       ------			------
14/06/..   h serindat		creation start
15/09/04					v1.0 - first release
16/01/14					v1.2 - SGL_PopupEdit(): the background color is now white (fixed) 
							       new datetime popup  
16/06/29					v1.3 - edit popup stringProcess(): virtKey type and value
16/07/06					       update of internal tools
16/07/13					       no more debug messages
							       editProc() WM_NCDESTROY: lost focus now works!
18/08/18					v1.3.2 type handling for stringProcess()
19/03/02					v1.3.4 editProc(): bug corrected (WM_NCDESTROY)
================================================================================================*/

#include "sgl_base_.h"
#include <commctrl.h>
#include "sgl_popup.h"
#include "sgl_popup_.h"

#pragma comment(lib, "comctl32.lib")

/*============================================================================= COMMON FRAME ===*/

#define FRAMECLASSNAME	"POPUPFRAME"
static LRESULT CALLBACK frameProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam) ;

typedef struct
{
	int type ;											/* object type (must be the 1st member)	*/
	HWND frameW, ctrlW ;								/* frame and win32 control				*/
	void (*eventProc)(void*, int, int) ;				/* WM_COMMAND notification callback		*/
} SGL_FRAME_T ;

static WNDPROC defaultPopupProc ;					/* used for subclassing						*/


/*----------------------------------------------------------------------------------------------*/
int  SGL__popupInit(void)							/* set the local data						*/
{
	static int done = 0 ;
	if (done) return 0 ;

	WNDCLASS wndclass = 							/* register the frame class					*/
	{
		.style         = 0 ,
		.lpfnWndProc   = frameProc ,
		.cbClsExtra    = 0 ,
		.cbWndExtra    = 0 ,
		.hInstance     = SGL__instance ,
		.hIcon         = 0 ,
		.hCursor       = LoadCursor (NULL, IDC_ARROW) ,
		.hbrBackground = NULL ,
		.lpszMenuName  = NULL ,
		.lpszClassName = FRAMECLASSNAME
	} ;
	if (!RegisterClass(&wndclass))
		return SGL_ERR_ALLOC ;						/* case error								*/

    INITCOMMONCONTROLSEX icex = {					/* register the used common controls:		*/
    	.dwSize = sizeof(icex),
    	.dwICC = ICC_DATE_CLASSES } ;							/* the date-time picker			*/
	if (!InitCommonControlsEx(&icex))
		return SGL_ERR_ALLOC ;

	done = 1 ;
	return 0 ;
}

void SGL__popupExit(void) { return ; }

/*----------------------------------------------------------------------------------------------*/
static LRESULT CALLBACK frameProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
//	SGL__trace(__func__, hwnd, message, wParam, lParam) ;

	SGL_FRAME_T *frame = (SGL_FRAME_T*) GetWindowLongPtr(hwnd, GWLP_USERDATA) ;
	if (frame) switch (message)
	{
		case WM_DESTROY :						/* popup close									*/
			free(frame) ;
			break ;

		case WM_PAINT :							/* paint the frame window (background only)		*/
		{
			PAINTSTRUCT ps ;
			HDC hdc = BeginPaint(hwnd, &ps) ;
			RECT rect ; GetClientRect(hwnd, &rect) ;
			SetDCBrushColor(hdc, SGL_WHITE) ;
			FillRect(hdc, &rect, GetStockObject(DC_BRUSH)) ;
			EndPaint(hwnd, &ps) ;
			return 0 ;															/* done			*/
		}

		case WM_MOUSEWHEEL :
			SendMessage(frame->ctrlW, message, wParam, lParam) ;
			break ;

		case WM_NOTIFY :
		{
			NMHDR *ns = (NMHDR*) lParam ;
			SendMessage(ns->hwndFrom, message, wParam, lParam) ;
			break ;
		}

		case WM_COMMAND :						/* edit control notification					*/
		{
			if (frame->eventProc)
				frame->eventProc(frame, HIWORD(wParam), 0) ;
			else
				SGL_Error(__FILE__, __LINE__, -1) ;
			break ;
		}
	}
	return DefWindowProc(hwnd, message, wParam, lParam) ;
}

/*================================================================================ EDIT POPUP ====

When running the edit popup, 4 functions are involved:

frameProc()
    
    This function receives all the messages. WM_DESTROY and WM_PAINT (bacground paint) 
	are processed locally. The EN_UPDATE is handled by stringProcess()
    
editProc()

    This is the window procedure of the edit control. It handles keyboard events, mouse events, 
	lost of focus and destroy events and calls strinProcess().
    
stringProcess()

    This function is called by frameproc() when it receives EN_UPDATE (when the edit control 
    is about to display altered text), and by editProc().
    
editCB()

    This is the optionnal user callback function. It is called by stringProcess().

================================================================================================*/

typedef struct sgl_ppd_t
{
	SGL_FRAME_T frame ;									/* frame (must be the 1st member)		*/
	SGL_EDITCB CBpopup ;								/* user callback (default: NULL)		*/
	void* CBdataPtr ;									/* user callback data (optionnal)		*/
	char *textVal ;										/* user string							*/
	int textLen ;										/* length of the user string			*/
} SGL_EDITPOPUP_T ;

static void stringProcess(void *ptr, int notif, int virtKey) ;
static LRESULT CALLBACK editProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) ;

/*----------------------------------------------------------------------------------------------*/
HWND SGL_PopupEdit(HWND hwnd, RECT *rect, DWORD style, char *text, int textLen,
						SGL_EDITCB editCB, void* CBdataPtr)
/*
	This function installs first a frame window to fill the gap between the popup control and 
	to receive messages from the popup window it-self.

	Both windows own the same structure which receives the context inherited from the parent.
*/
{
	SGL_T* sglParent = SGL__getStruct(hwnd) ;			/* check parent object					*/
	if (sglParent == NULL) return NULL ;

	if (rect == NULL) return NULL ;						/* check other parameters				*/
	if (text == NULL) return NULL ;
	if (textLen == 0) return NULL ;

	SGL_EDITPOPUP_T *ppd = calloc(1, sizeof(SGL_EDITPOPUP_T)) ;
	if (ppd == NULL) return NULL ;

	ppd->frame.type = -1 ;									/* not a SGL window						*/
	ppd->frame.eventProc = stringProcess ;
	ppd->textVal = text ;
	ppd->textLen = textLen ;
	ppd->CBpopup = editCB ;
	ppd->CBdataPtr = CBdataPtr ;

	MapWindowPoints(NULL, hwnd, (POINT*) rect, 2) ;				/* change to parent coordinates	*/
	int h = rect->bottom - rect->top ;								/* popup height				*/
	HWND frameW = CreateWindowEx(0, FRAMECLASSNAME, "popup_frame", WS_CHILD | WS_VISIBLE,
							    rect->left, rect->top, rect->right - rect->left, h,
							    hwnd, (HMENU) 0, SGL__instance, NULL) ;
	
	int lh = SGL__getFontHeight(sglParent) ;						/* line height				*/
	HWND ctrlW = CreateWindow("edit", text, WS_CHILD | WS_VISIBLE | style,
						    0, (h - lh) / 2, rect->right - rect->left, rect->bottom - rect->top,
						    frameW, (HMENU) 0, SGL__instance, NULL) ;

	if (frameW == NULL || ctrlW == NULL)						/* case window not created		*/
	{
		DestroyWindow(frameW) ;
		DestroyWindow(ctrlW) ;
		free(ppd) ;
		return NULL ;
	}
																/* subclass the edit box		*/
	defaultPopupProc = (WNDPROC) SetWindowLongPtr(ctrlW, GWLP_WNDPROC, (LONG_PTR) editProc) ;

	ppd->frame.frameW = frameW ;								/* link ppd and windows			*/
	ppd->frame.ctrlW = ctrlW ;
	SetWindowLongPtr(frameW, GWLP_USERDATA, (LONG_PTR) ppd) ;
	SetWindowLongPtr(ctrlW,  GWLP_USERDATA, (LONG_PTR) ppd) ;

	SendMessage(ctrlW, WM_SETFONT, (WPARAM) SGL__getFont(sglParent), 0) ;
	SendMessage(ctrlW, EM_SETSEL, strlen(text), strlen(text)) ;	/* set caret at end of string	*/
	SetFocus(ctrlW) ;

	return ctrlW ;
}

/*----------------------------------------------------------------------------------------------*/
static void stringProcess(void *ptr, int notif, int virtKey)
{
	SGL_EDITPOPUP_T *ppd = (SGL_EDITPOPUP_T*) ptr ;
//	SGL_Log(STD, "%s notif: 0x%x virtKey: 0x%x", __func__, notif, virtKey) ;
	if (notif != EN_UPDATE && virtKey == 0)
		return ;
	GetWindowText(ppd->frame.ctrlW, ppd->textVal, ppd->textLen) ;		/* get text				*/
	if (ppd->CBpopup)
	{
		int caret ;												/* caret save/restore position	*/
		SendMessage(ppd->frame.ctrlW, EM_GETSEL, 0, (LPARAM) &caret) ;
																/* user process					*/
		switch (ppd->CBpopup(virtKey, ppd->textVal, ppd->textLen, caret, ppd->CBdataPtr))
		{
			case 1 :
				SetWindowText(ppd->frame.ctrlW, ppd->textVal) ;
				SendMessage(ppd->frame.ctrlW, EM_SETSEL, caret, caret) ;
				break ;
			case -1 :
				DestroyWindow(ppd->frame.frameW) ;
				break ;
		}
	}
}

/*----------------------------------------------------------------------------------------------*/
static LRESULT CALLBACK editProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
//	SGL__trace(__func__, hwnd, message, wParam, lParam) ;
	int processed = 0 ;
	int closeAtEnd = 0 ;
	static int virtKey = 0 ;

	SGL_EDITPOPUP_T* ppd = (SGL_EDITPOPUP_T*) GetWindowLongPtr(hwnd, GWLP_USERDATA) ;

	switch (message)
	{
		case WM_KEYDOWN :
			switch (virtKey = (int) wParam)
			{
				case VK_UP :
				case VK_DOWN :
					stringProcess(ppd, 0, virtKey) ;
					processed = 1 ;
					break ;
			}
			break ;

		case WM_CHAR :
			switch (virtKey = (TCHAR) wParam)
			{
				case VK_RETURN :
				case VK_ESCAPE :
					processed = 1 ;
					closeAtEnd = 1 ;
					break ;
			}
			break ;

		case WM_KILLFOCUS :
			closeAtEnd = 1 ;
			break ;

		case WM_MOUSEWHEEL :
		{
			if (((short) HIWORD(wParam)) > 0)
				stringProcess(ppd, 0, VK_UP) ;
			else
				stringProcess(ppd, 0, VK_DOWN) ;
			processed = 1 ;
			break ;
		}

		case WM_NCDESTROY :
			if (virtKey != VK_RETURN)							/* case escape or lost focus	*/
				virtKey = VK_ESCAPE ;
			stringProcess(ppd, 0, virtKey) ;
			virtKey = 0 ;										/* do not keep (v1.3.4)			*/
			break ;
	}

	if (closeAtEnd)
		DestroyWindow(ppd->frame.frameW) ;

	if (processed)
		return 0 ;
	else
		return CallWindowProc(defaultPopupProc, hwnd, message, wParam, lParam) ;
}


/*================================================================================ POPUP MENU ==*/

/*----------------------------------------------------------------------------------------------*/
int SGL_PopupMenu(HWND hwnd, SGL_POPUPMENU_OPTIONS_T* options, RECT *rect, int align)
{
				/* The menu item ID is the position + 1 and is returned by TrackPopupMenuEx()	*/

	HMENU menu = CreatePopupMenu() ;					/* create menu							*/
	if (menu == NULL)
		return SGL_ERR_ALLOC ;

	int result = 0 ;
	for (int i = 0 ; options[i].text ; i++)				/* add options							*/
		if (0 == InsertMenu(menu, i, MF_BYPOSITION | options[i].state, i + 1, options[i].text))
			result = SGL_ERR_ALLOC ;

	if (result == 0)
	{
		int flag = TPM_LEFTBUTTON | TPM_RIGHTBUTTON | TPM_RETURNCMD ;
		int x = 0 ;

		switch (align)
		{
			case SGL_RIGHT :
				flag |= TPM_LEFTALIGN ;
				x = rect->right ;
				break ;
			case SGL_CENTER :
				flag |= TPM_CENTERALIGN ;
				x = (rect->left + rect->right) / 2 ;
				break ;
			case SGL_LEFT :
				flag |= TPM_RIGHTALIGN ;
				x = rect->left ;
				break ;
			default :
				result = SGL_ERR_PARM - 3 ;
		}
		if (result == 0)
		{
			result = TrackPopupMenuEx(menu, flag, x, rect->bottom, hwnd, NULL) - 1 ;
			if (result < 0)
				result = SGL_ERR_INT ;
		}
	}
	DestroyMenu(menu) ;
	return result ;
}


/*============================================================================ DATETIME POPUP ==*/

#define FORMATMAXLEN 128

static LRESULT CALLBACK datetimeProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) ;

typedef struct
{
	SGL_FRAME_T frame ;						/* frame (must be the 1st member)					*/
	SGL_DTIMECB CBpopup ;					/* user callback (default: NULL)					*/
	void* CBdataPtr ;						/* user callback data (optionnal)					*/
	int optStyle ;							/* lsb's of the style								*/
	HWND monthCal ;							/* month/calendar popup								*/
	SYSTEMTIME *datetime ;					/* user data										*/
	int textLen ;							/* length of the user string						*/
} SGL_DATETIMEPOPUP_T ;

/*----------------------------------------------------------------------------------------------*/
int SGL_DateTimeStringGet(SYSTEMTIME *datetime, int style, char *format, char* dst, int max)
{
	if (datetime && datetime->wYear == 0)					/* case null date-time				*/
	{
		if (dst == NULL && max < 1) return 0 ;
		if (dst) *dst = '\0' ;
		return 1 ;
	}

	switch (style & 0xff00)
	{
		case SGL_TIME :
			return GetTimeFormat(GetThreadLocale(), 0, datetime, format, dst, max) ;
		case SGL_DATE :
		{
			DWORD dwFlags = 0 ;
			if (format == NULL)
				dwFlags = (style & SGL_DT_LONG) ? DATE_LONGDATE	 : DATE_SHORTDATE ;
			return GetDateFormat(GetThreadLocale(), dwFlags, datetime, format, dst, max) ;
		}
		default :
			return 0 ;
	}
}

SYSTEMTIME SGL_DateTimeNow(void)
{
	SYSTEMTIME utc, local ;
	GetSystemTime(&utc) ;
	SystemTimeToTzSpecificLocalTime(NULL, &utc, &local) ;
	return local ;
}

/*----------------------------------------------------------------------------------------------*/
HWND SGL_PopupDatetime(HWND hwnd, RECT *rect, int style, char *format, SYSTEMTIME *datetime,
						SGL_DTIMECB dtimeCB, void* CBdataPtr)
/*
	To remove the border:
		- create with any size and positiion
		- set font
		- move window to the size & right position
		- in the Window procedure, clear the non client area 
*/
{
	SGL_T* sglParent = SGL__getStruct(hwnd) ;			/* check parent object					*/
	if (sglParent == NULL) return NULL ;

	int optStyle = style & 0xff ;
	style &= 0xff00 ;

	DWORD dtStyle = 0 ;
	switch (style)
	{
		case SGL_TIME :
			dtStyle = DTS_TIMEFORMAT ;
			break ;
		case SGL_DATE :
			dtStyle  = (optStyle & SGL_DT_CALENDAR) ? 0 : DTS_UPDOWN ;
			dtStyle |= (optStyle & SGL_DT_LONG) ? DTS_LONGDATEFORMAT : DTS_SHORTDATEFORMAT ;
			break ;
		default :
			return NULL ;
	}

	if (rect == NULL) return NULL ;						/* check other parameters				*/
	if (datetime == NULL) return NULL ;
	if (SGL_DATETIME_NONE_IS(*datetime))
		GetSystemTime(datetime) ;

	SGL_DATETIMEPOPUP_T *ppd = calloc(1, sizeof(SGL_DATETIMEPOPUP_T)) ;
	if (ppd == NULL) return NULL ;

	ppd->frame.type = -1 ;								/* not a SGL window						*/
	ppd->optStyle = optStyle ;
	ppd->datetime = datetime ;
	ppd->CBpopup = dtimeCB ;
	ppd->CBdataPtr = CBdataPtr ;

	MapWindowPoints(NULL, hwnd, (POINT*) rect, 2) ;				/* change to parent coordinates	*/
	int h = rect->bottom - rect->top ;								/* popup height				*/
	int w = rect->right - rect->left ;
	HWND frameW = CreateWindowEx(0, FRAMECLASSNAME, "popup_frame", WS_CHILD | WS_VISIBLE,
							    rect->left, rect->top, w, h,
							    hwnd, (HMENU) 0, SGL__instance, NULL) ;
	
	HWND ctrlW = CreateWindowEx(0, DATETIMEPICK_CLASS, "DateTime", 
								WS_CHILD | WS_VISIBLE | dtStyle,
							    0, 0, 0, 0,
							    frameW, (HMENU) 0, SGL__instance, NULL) ;

	if (frameW == NULL || ctrlW == NULL)						/* case window not created		*/
	{
		DestroyWindow(frameW) ;
		DestroyWindow(ctrlW) ;
		free(ppd) ;
		return NULL ;
	}

	if (ppd->CBpopup)
			ppd->CBpopup(SGL_DT_INSTALL, ppd->datetime, ppd->CBdataPtr) ;

																/* subclass the datetime box	*/
	defaultPopupProc = (WNDPROC) SetWindowLongPtr(ctrlW, GWLP_WNDPROC, (LONG_PTR) datetimeProc) ;

	ppd->frame.frameW = frameW ;									/* link ppd and windows		*/
	ppd->frame.ctrlW = ctrlW ;
	SetWindowLongPtr(frameW, GWLP_USERDATA, (LONG_PTR) ppd) ;
	SetWindowLongPtr(ctrlW,  GWLP_USERDATA, (LONG_PTR) ppd) ;

	SendMessage(ctrlW, WM_SETFONT, (WPARAM) SGL__getFont(sglParent), 0) ;	/* font setting		*/
	if (format && strlen(format))
		DateTime_SetFormat(ctrlW, format) ;
	DateTime_SetSystemtime(ctrlW, GDT_VALID, datetime) ;
	MoveWindow(ctrlW, 0, -1, w, h + 1, 1) ;						/* position adjusted !!			*/

	SetFocus(ctrlW) ;
	return ctrlW ;
}

/*----------------------------------------------------------------------------------------------*/
static LRESULT CALLBACK datetimeProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
//	SGL__trace(__func__, hwnd, message, wParam, lParam) ;

	int processed = 0 ;
	int closeAtEnd = 0 ;
	SGL_DATETIMEPOPUP_T* ppd = (SGL_DATETIMEPOPUP_T*) GetWindowLongPtr(hwnd, GWLP_USERDATA) ;

	switch (message)
	{
		case WM_NCCALCSIZE :											/* remove border		*/
			processed = 1 ;
			break ;

		case WM_MOUSEWHEEL :
			if (((short) HIWORD(wParam)) > 0)
				SendMessage(hwnd, WM_KEYDOWN, VK_UP, 0) ;
			else
				SendMessage(hwnd, WM_KEYDOWN, VK_DOWN, 0) ;
			processed = 1 ;
			break ;

		case WM_KEYDOWN :
			if ((ppd->optStyle & SGL_DT_NONE) && (wParam == VK_DELETE))
			{
				SGL_DATETIME_NONE_SET(*ppd->datetime) ;
				if (ppd->CBpopup)
					ppd->CBpopup(SGL_DT_DELETE, ppd->datetime, ppd->CBdataPtr) ;
			}
			else
				break ;

		case WM_KILLFOCUS :
			if (ppd->monthCal)
				processed = 1 ;
			else
				closeAtEnd = 1 ;
			break ;

		case WM_NOTIFY :
			switch (((NMHDR*) lParam)->code)							/* notification code	*/
			{
				case DTN_DATETIMECHANGE :
					DateTime_GetSystemtime(hwnd, ppd->datetime) ;
					if (ppd->CBpopup)
						ppd->CBpopup(SGL_DT_CHANGED, ppd->datetime, ppd->CBdataPtr) ;
					break ;
				case DTN_DROPDOWN :										/* calendar is drawn	*/
				{
					ppd->monthCal = DateTime_GetMonthCal(hwnd) ;		/* save its handle		*/

					long mStyle = GetWindowLong(ppd->monthCal, GWL_STYLE) ;		/* set style	*/
					mStyle |= (ppd->optStyle & SGL_DT_TODAY)  ? 0 : MCS_NOTODAY ;
					mStyle |= (ppd->optStyle & SGL_DT_WEEKNB) ? MCS_WEEKNUMBERS : 0 ;
					SetWindowLong(ppd->monthCal, GWL_STYLE, mStyle) ;

					RECT rc ;													/* set size	*/
					MonthCal_GetMinReqRect(ppd->monthCal, &rc) ;
					SetWindowPos(ppd->monthCal, NULL, rc.left, rc.top, 
				                rc.right - rc.left, rc.bottom - rc.top,
				                SWP_NOZORDER);
					break ;
				}
				case DTN_CLOSEUP :
					closeAtEnd = 1 ;
					break ;
			}
			break ;
	}

	if (closeAtEnd)
	{
		DestroyWindow(ppd->frame.frameW) ;
		if (ppd->CBpopup)
			ppd->CBpopup(SGL_DT_RELEASE, ppd->datetime, ppd->CBdataPtr) ;
	}

	if (processed)
		return 0 ;
	else
		return CallWindowProc(defaultPopupProc, hwnd, message, wParam, lParam) ;
}

