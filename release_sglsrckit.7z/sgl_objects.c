/*=============================================================================== SGL_OBJECTS.C ==
SGL dispacher for SGL oject classes.

Internal functions are:
	int  SGL__xxxInit(void) ;		// initialize and allocate resources for the class
	int  SGL__xxxNew(SGL_T *sgl) ;	// create or duplicate an object
	void SGL__xxxExit(void) ;		// release resources

==================================================================================================
date       author			update
----       ------			------
14/06/..   h serindat		creation start
15/09/29					v1.1 - new opengl object
================================================================================================*/

#include "sgl_base_.h"
#include "sgl_objects_.h"

#include "sgl_button_.h"
#include "sgl_edit_.h"
#include "sgl_graph_.h"
#include "sgl_image_.h"
#include "sgl_opengl_.h"
#include "sgl_panel_.h"
#include "sgl_popup_.h"
#include "sgl_separator_.h"
#include "sgl_table_.h"

int SGL__objectsInit(void)
{
	if (SGL__editInit())		return SGL_ERR_ALLOC ;
	if (SGL__buttonInit())		return SGL_ERR_ALLOC ;
	if (SGL__imageInit())		return SGL_ERR_ALLOC ;
	if (SGL__graphInit())		return SGL_ERR_ALLOC ;
	if (SGL__openglInit())		return SGL_ERR_ALLOC ;
	if (SGL__panelInit())		return SGL_ERR_ALLOC ;
	if (SGL__popupInit())		return SGL_ERR_ALLOC ;
	if (SGL__separatorInit())	return SGL_ERR_ALLOC ;
	if (SGL__tableInit())		return SGL_ERR_ALLOC ;
	return 0 ;
}

int SGL__objectsNew(SGL_T *sgl)
{
	int e = SGL_ERR_TYPE ;
	if (e == SGL_ERR_TYPE) e = SGL__editNew(sgl) ;
	if (e == SGL_ERR_TYPE) e = SGL__buttonNew(sgl) ;
	if (e == SGL_ERR_TYPE) e = SGL__imageNew(sgl) ;
	if (e == SGL_ERR_TYPE) e = SGL__graphNew(sgl) ;
	if (e == SGL_ERR_TYPE) e = SGL__openglNew(sgl) ;
	if (e == SGL_ERR_TYPE) e = SGL__panelNew(sgl) ;
	if (e == SGL_ERR_TYPE) e = SGL__separatorNew(sgl) ;
	if (e == SGL_ERR_TYPE) e = SGL__tableNew(sgl) ;

	return e ;
}

void SGL__objectsExit(void)
{
	SGL__editExit() ;
	SGL__buttonExit() ;
	SGL__imageExit() ;
	SGL__graphExit() ;
	SGL__openglExit() ;
	SGL__panelExit() ;
	SGL__popupExit() ;
	SGL__separatorExit() ;
	SGL__tableExit() ;
}
