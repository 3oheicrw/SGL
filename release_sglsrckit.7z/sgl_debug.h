#define NONE	0
#define STD		1
#define ERR		2
#define FATAL   3
#define QUIT	4

void SGL_Log(int mask, char *fmt,...) ;
void SGL_Fatal(char *file, int line, char *diag) ;
void SGL_Error(char *file, int line, int eresult) ; 

								/* Macro returning the number of elements of an array	*/
#define NELEMS(a) (sizeof(a) / sizeof((a)[0]))

								/* Macro to check a pointer								*/
#define PCHECK(p) if ((p) == NULL) SGL_Fatal(__FILE__, __LINE__, "ALLOCATION") ;

								/* Macro to check the result of a SGL function			*/
#define CHKERR(m) { SGL_Error(__FILE__, __LINE__, (m)) ; }

								/* Macro to log an execution time						*/
#define GCLK(m) { double _t_t = SGL_Timer() ; m ; _t_t = SGL_Timer() - _t_t ; \
					SGL_Log(STD, ":CLK: %-50.50s :%12.4f ms", #m, 1.e3 * _t_t) ;}
