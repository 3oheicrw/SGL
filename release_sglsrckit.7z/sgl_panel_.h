int SGL__panelInit(void) ;
int SGL__panelNew(SGL_T *sgl) ;
int SGL__panelCheckMaxPos(HWND parent, int left, int top) ;
void SGL__panelLayout(HWND hwnd) ;
void SGL__panelExit(void) ;

