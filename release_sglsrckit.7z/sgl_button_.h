int SGL__buttonInit(void) ;
int SGL__buttonNew(SGL_T *sgl) ;
void SGL__buttonExit(void) ;
