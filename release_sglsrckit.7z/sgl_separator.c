/*============================================================================= SGL_SEPARATOR.C ==
SGL SEPARATOR class.

A separator is stretched to the full width or height of its parent. If the parent has an internal
padding, it won't reach its border.
The documentation shows how to use hidden panels to encounter this problem.

==================================================================================================
date       author			update
----       ------			------
14/06/..   h serindat		creation start
15/09/04					v1.0 - first release
15/09/29					minor update SGL__separatorNew(): default args of CreateWindowEx()
15/10/16					v1.1 - automatic spanning to the border of the parent
16/01/11					v1.2 - winProc renamed sglProc to prevent confusion
16/03/16					v1.3 - SGL_ColorInperpolate() replaced by SGL_ColorInterpolate()
16/08/02					       separatorResize() now use macro SIZE
================================================================================================*/

#include "sgl_base_.h"
#include "sgl_separator.h"
#include "sgl_separator_.h"

typedef struct							/* specific object data									*/
{
	HCURSOR cursor ;
	POINT ptStart ;
	POINT ptEnd ;
} SGL_SEP_T ;

										/* debug condition										*/
#define DEBUG (sgl->debug ? STD : NONE)								/* sgl must be defined!		*/


/*========================================================================== SEPARATOR OBJECT ==*/

static void separatorResize(SGL_T *sgl) ;
static LRESULT separatorProc(HWND hwnd, SGL_T *sgl, UINT message, WPARAM wParam, LPARAM lParam) ;
static int parmIgnore(SGL_T *sgl, int opt, int check) ;


/*----------------------------------------------------------------------------------------------*/
int  SGL__separatorInit(void) { return 0 ; }
void SGL__separatorExit(void) { return ; }


/*----------------------------------------------------------------------------------------------*/
int SGL__separatorNew(SGL_T *sgl)					/* create a new separator					*/
{
	if (sgl->type != SGL_CTRL_HSEP && sgl->type != SGL_CTRL_VSEP)
		return SGL_ERR_TYPE ;
	if (sgl->hwndParent == NULL)	return SGL_ERR_PARM - 0 ;	/* parent must exist			*/


	NEW(SGL_SEP_T, sep) ;
	if (sgl->ex)											/* case duplicate					*/
		*sep = *(SGL_SEP_T*) sgl->ex ;
	else													/* case new							*/
	{																	/* default values		*/
		for (size_t i = 0 ; i < 2 ; i++)
			for (size_t j = 0 ; j < 2 ; j++)
				sgl->pad[i][j] = 0 ;

		switch (sgl->type)
		{
			case SGL_CTRL_HSEP :
				sgl->typeName = "HOR_SEPARATOR";
				sgl->uSize[1] = - 40 ;
				sgl->align = SGL_LEFT | SGL_RIGHT ;
				sep->cursor = LoadCursor(NULL, IDC_SIZENS) ;
				break ;

			case SGL_CTRL_VSEP :
				sgl->typeName = "VERT_SEPARATOR" ;
				sgl->uSize[0] = - 40 ;
				sgl->align = SGL_TOP | SGL_BOTTOM ;
				sep->cursor = LoadCursor(NULL, IDC_SIZEWE) ;
				break ;

			default :
				return SGL_ERR_TYPE ;
		}
		if (sgl->uStyle)											/* style not allowed		*/
			return SGL_ERR_PARM - 2 ;

		sgl->uBgColor = SGL_BLACK ;
		sgl->uFgColor = SGL_WHITE ;
		sgl->parmIgnore =	parmIgnore ;							/* check for std attributes	*/
		sgl->resizeObj =	separatorResize ;
		sgl->sglProc =		separatorProc ;
	}

	sgl->ex = sep ;

	sgl->hwnd = CreateWindowEx(0, MAINCLASSNAME, sgl->title, sgl->winStyle | sgl->uStyle,
							    0, 0, 0, 0,
							    sgl->hwndParent, (HMENU) 0, SGL__instance, NULL) ;
	if (sgl->hwnd == NULL)
		return SGL_ERR_ALLOC ;

	return 0 ;
}

/*================================================================== EXPORTED LOCAL FUNCTIONS ==*/

/*----------------------------------------------------------------------------------------------*/
static int parmIgnore(SGL_T *sgl, int check, int opt)			/* check if setting is allowed	*/
{
	if (check == CHECK_SIZE)											/* width or height		*/
	{
		if (opt == SGL_HEIGHT && sgl->type == SGL_CTRL_HSEP) return 0 ;
		if (opt == SGL_WIDTH  && sgl->type == SGL_CTRL_VSEP) return 0 ;
		return 1 ;
	}
	if (check == CHECK_BORDERTHICKNESS || 								/* no border setting	*/
		check == CHECK_BORDERSTYLE ||
		check == CHECK_ALIGNMENT)										/* no alignment			*/
		return 1 ;
	return 0 ;
}

/*----------------------------------------------------------------------------------------------*/
static void separatorResize(SGL_T *sgl)						/* resize an separator				*/
{
	int i = (sgl->type == SGL_CTRL_HSEP) ? 1 : 0 ;
	RECT_SETWH(i, sgl->rect, SIZE(sgl->uSize[i]))			/* thickness						*/
	RECT_SETWH(1 - i, sgl->rect, 0)							/* reset the length to 0			*/
	return ;
}

/*----------------------------------------------------------------------------------------------*/
static LRESULT separatorProc(HWND hwnd, SGL_T *sgl, UINT message, WPARAM wParam, LPARAM lParam)
{
	LRESULT result = DEFPROC ;						/* default result: no message processed		*/
	SGL_SEP_T *sep = sgl->ex ;

	switch (message)
	{
		case WM_PAINT :
		{
			RECT rect ;								/* separator rectangle						*/

			GetWindowRect(hwnd, &rect) ;			/* expand the separator to its parent		*/
			MapWindowPoints(NULL, GetParent(hwnd), (POINT*) &rect, 2) ;
			
			RECT parentRect ;							/* parent rectangle						*/
			GetClientRect(GetParent(hwnd), &parentRect) ;

			if (sgl->type == SGL_CTRL_HSEP)
			{
				rect.left  = parentRect.left ;
				rect.right = parentRect.right ;
			}
			else
			{
				rect.top    = parentRect.top ;
				rect.bottom = parentRect.bottom ;
			}
			MoveWindow(hwnd, rect.left, rect.top,		/* set the new size and posion			*/
				RECT_GETWH(0, rect), RECT_GETWH(1, rect), 0) ;

			PAINTSTRUCT ps ;						/* standard separator paint					*/
			HDC hdc = BeginPaint(hwnd, &ps) ;
				GetClientRect(hwnd, &rect) ;
				SelectObject(hdc,GetStockObject(DC_PEN)) ;
				int w = RECT_GETWH((sgl->type == SGL_CTRL_HSEP) ? 1 : 0, rect) ;
				for (int j = 0 ; j < w ; j++)
				{
					double k = (double) j / w ;
					SetDCPenColor(hdc, SGL_ColorInterpolate(sgl->context.fgdColor, 
															sgl->context.bgdColor, k)) ;
					if (sgl->type == SGL_CTRL_HSEP)
					{
						MoveToEx(hdc, rect.left, rect.top + j, NULL) ;
						LineTo(hdc, rect.right, rect.top + j) ;
					}
					else
					{
						MoveToEx(hdc, rect.left + j, rect.top, NULL) ;
						LineTo(hdc, rect.left + j, rect.bottom) ;
					}
				}
			EndPaint(hwnd, &ps) ;
			result = 0 ;
			break ;
		}

		case WM_LBUTTONDOWN :
			SGL_CursorPositionGet(NULL, 1, &(sep->ptStart)) ; 
			SetCapture(hwnd) ;
			break ;

		case WM_LBUTTONUP :
		{
			SGL_CursorPositionGet(NULL, 1, &(sep->ptEnd)) ;
			int moved = sgl->type == SGL_CTRL_VSEP ? sep->ptEnd.x - sep->ptStart.x 
													: sep->ptEnd.y - sep->ptStart.y ;
			SGL_Log(DEBUG, "Sepatator moved %d", moved) ;
			PostMessage(hwnd, WM_USER, moved, moved) ;
			ReleaseCapture() ;
			break ;
		}

		case WM_SETCURSOR :									/* redraw cursor					*/
			if (LOWORD(lParam) == HTCLIENT && sgl->CBfunction)		/* in client area only		*/
			{														/* and if callback exists	*/
				SetCursor(sep->cursor) ;
				result = 1 ;
			}
			break ;
	}
	return result ;
}
