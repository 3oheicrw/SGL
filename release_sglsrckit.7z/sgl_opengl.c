/*================================================================================ SGL_OPENGL.C ==
SGL OPENGL class.

==================================================================================================
date       author			update
----       ------			------
15/08/..   h serindat		creation start
15/10/19					v1.1 - realease
16/01/11					v1.2 - winProc renamed sglProc to prevent confusion
================================================================================================*/

#include "sgl_base_.h"
#include "sgl_opengl.h"
#include "sgl_opengl_.h"
#include <math.h>
#include <gl/gl.h>

#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "glu32.lib")

typedef struct							/* specific object data (not duplicated)				*/
{
	SGL_T *sgl ;							/* back pointer (not duplicated)					*/
    HGLRC hglrc ;    						/* OpenGL rendering context							*/
	double nFoc, zNear, zFar ;				/* perspective										*/
} SGL_OPENGL_T ;

#define DEBUG (sgl->debug ? STD : NONE)		/* debug condition (sgl must be defined)		 	*/


/*============================================================================= OpenGL OBJECT ==*/

static void openglResize(SGL_T *sgl) ;
static LRESULT openglProc(HWND hwnd, SGL_T *sgl, UINT message, WPARAM wParam, LPARAM lParam) ;
static int parmIgnore(SGL_T *sgl, int check, int dum) ;

/*----------------------------------------------------------------------------------------------*/
int  SGL__openglInit(void) { return 0 ; }
void SGL__openglExit(void) { return ; }

/*----------------------------------------------------------------------------------------------*/
int SGL__openglNew(SGL_T *sgl)							/* create a new opengl object			*/
{
	if (sgl->type != SGL_CTRL_OPENGL)
		return SGL_ERR_TYPE ;
	if (sgl->hwndParent == NULL)	return SGL_ERR_PARM - 0 ;	/* parent must exist			*/

	NEW(SGL_OPENGL_T, ogl) ;
	if (sgl->ex)											/* case duplicate					*/
		*ogl = *(SGL_OPENGL_T*) sgl->ex ;
	else													/* case new							*/
	{																/* default values			*/
		sgl->typeName = "OPENGL";
		sgl->uSize[0] = 160 ;										/* width (pixel)			*/
		sgl->uSize[1] = 120 ;										/* height					*/
		ogl->nFoc = 1.0 ;											/* normal focal length		*/

		sgl->parmIgnore =	parmIgnore ;							/* check for std attributes	*/
		sgl->resizeObj =	openglResize ;							/* linkage					*/
		sgl->sglProc =		openglProc ;
	}

	sgl->ex = ogl ;
	ogl->sgl = sgl ;

	sgl->hwnd = CreateWindowEx(0, MAINCLASSNAME, sgl->title, sgl->winStyle | sgl->uStyle,
							    0, 0, 0, 0,
							    sgl->hwndParent, (HMENU) 0, SGL__instance, NULL) ;
	if (sgl->hwnd == NULL)
		return SGL_ERR_ALLOC ;

    HDC hdc = GetDC(sgl->hwnd) ;

    PIXELFORMATDESCRIPTOR pfd =
	{
		.nSize = sizeof(PIXELFORMATDESCRIPTOR),
		.nVersion = 1,
		.dwFlags = PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER | PFD_DRAW_TO_WINDOW,
		.iPixelType = PFD_TYPE_RGBA,
		.cColorBits = 24,
		.cDepthBits = 32
	} ;

    int chosenPixelFormat = ChoosePixelFormat(hdc, &pfd) ;
    if (chosenPixelFormat == 0)
		FatalAppExit(0, "ChoosePixelFormat() failed!" ) ;

    if (SetPixelFormat(hdc, chosenPixelFormat, &pfd) == 0)
        FatalAppExit(0, "SetPixelFormat() failed!") ;

    ogl->hglrc = wglCreateContext(hdc) ;
    wglMakeCurrent(hdc, ogl->hglrc) ;

	return 0 ;
}


/*========================================================================= SET/GET FUNCTIONS ==*/

#define CHECK_OBJ(h, g)		SGL_T* _sgl = SGL__getStruct(h) ;								\
							if (_sgl == NULL)					return SGL_ERR_PARM - 0 ;	\
							if (_sgl->type != SGL_CTRL_OPENGL)	return SGL_ERR_TYPE ;		\
							SGL_OPENGL_T *g = _sgl->ex ;									\
							if (g == NULL)						return SGL_ERR_INT ;

/*----------------------------------------------------------------------------------------------*/
int SGL_OglZoomSet(HWND hwnd, double nFoc)				/* set the focal distance (1: normal)	*/
{
	CHECK_OBJ(hwnd, ogl) ;
	if (nFoc  <= 0)		return SGL_ERR_PARM - 1 ;
	ogl->nFoc  = nFoc ;
	return 0 ;
}

int SGL_OglZoomGet(HWND hwnd, double *nFoc)				/* get the focal distance (1: normal)	*/
{
	CHECK_OBJ(hwnd, ogl) ;
	if (nFoc)
		*nFoc = ogl->nFoc ;
	return 0 ;
}

int SGL_OglDepthOfFieldSet(HWND hwnd, double zNear, double zFar)	/* set the depth of field	*/
{
	CHECK_OBJ(hwnd, ogl) ;
	if (zNear <= 0) 	return SGL_ERR_PARM - 1 ;
	if (zFar  <= 0) 	return SGL_ERR_PARM - 2 ;
	if (zNear >= zFar)	return SGL_ERR_PARM - 2 ;

	ogl->zNear = zNear ;
	ogl->zFar  = zFar ;
	return 0 ;
}

int SGL_OglDepthOfFieldGet(HWND hwnd, double *zNear, double *zFar)	/* get the depth of field	*/
{
	CHECK_OBJ(hwnd, ogl) ;
	if (zNear)
		*zNear = ogl->zNear ;
	if (zFar)
		*zFar = ogl->zFar ;
	return 0 ;
}


/*================================================================== EXPORTED LOCAL FUNCTIONS ==*/

/*----------------------------------------------------------------------------------------------*/
static int parmIgnore(SGL_T *sgl, int check, int dum)
{
	switch (check)
	{
		case CHECK_BORDERSTYLE :
		case CHECK_BORDERTHICKNESS :
		case CHECK_COLORS :
		case CHECK_FONT :
			return 1 ;
	}
	return 0 ;
}

/*----------------------------------------------------------------------------------------------*/
static void openglResize(SGL_T *sgl)						/* resize an opengl object			*/
{
	int pixelSize[2] ;										/* [0]:width, [1]:height			*/
	for (int i = 0 ; i < 2 ; i++)
	{
		pixelSize[i] = SIZE(sgl->uSize[i]) ;				/* convert to pixels				*/
		RECT_SETWH(i, sgl->rect, pixelSize[i]) ;
	}
															/* OpenGL reshape					*/
	glViewport(0, 0, pixelSize[0], pixelSize[1]) ; 			/* set viewport						*/

	/*------------------------------------------------------------------
		Set the perspective, ie. solving the 4 equations:
			zNear = 2 * hDiag * nFoc	(hDiag = half image diagonal)
			left� + top� = hDiag�
			aspect = left / top = pixelSize[0] / pixelSize[1]
	------------------------------------------------------------------*/

	if (pixelSize[1] < 1)	return ;
	double aspect = (double) pixelSize[0] / pixelSize[1] ;

	SGL_OPENGL_T *ogl = sgl->ex ;
	double hDiag = 0.5 * ogl->zNear / ogl->nFoc ;
	double fH = hDiag / sqrt(1 + aspect * aspect) ;
	double fW = fH * aspect ;

    glMatrixMode(GL_PROJECTION) ;
	glLoadIdentity () ;
    glFrustum(-fW, fW, -fH, fH, ogl->zNear, ogl->zFar) ;

	glMatrixMode(GL_MODELVIEW);
	return ;
}

/*----------------------------------------------------------------------------------------------*/
static LRESULT openglProc(HWND hwnd, SGL_T *sgl, UINT message, WPARAM wParam, LPARAM lParam)
{
	LRESULT result = DEFPROC ;						/* default result: no message processed		*/
	SGL_OPENGL_T *ogl = sgl->ex ;

	switch (message)
	{
		case WM_DESTROY :							/* release and delete the OpenGL context	*/
		    wglMakeCurrent(NULL, NULL) ;
			wglDeleteContext(ogl->hglrc) ;
			result = 0 ;
			break ;
	}
	return result ;
}
