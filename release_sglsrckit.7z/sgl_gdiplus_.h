/*========================================================================== GDI+ DEFINITIONS ====

	Minimum implementation of GdiPlus that allows the loading and rendering of images
	cf. Microsoft GDI+ Flat API; J.Findlay http://www.johnfindlay.plus.com/pellesc/GdiPlus

	Error codes are (- GDI+) status codes
	GDI+ status codes are:
							Ok                          = 0,
							GenericError                = 1,
							InvalidParameter            = 2,
							OutOfMemory                 = 3,
							ObjectBusy                  = 4,
							InsufficientBuffer          = 5,
							NotImplemented              = 6,
							Win32Error                  = 7,
							WrongState                  = 8,
							Aborted                     = 9,
							FileNotFound                = 10,
							ValueOverflow               = 11,
							AccessDenied                = 12,
							UnknownImageFormat          = 13,
							FontFamilyNotFound          = 14,
							FontStyleNotFound           = 15,
							NotTrueTypeFont             = 16,
							UnsupportedGdiplusVersion   = 17,
							GdiplusNotInitialized       = 18,
							PropertyNotFound            = 19,
							PropertyNotSupported        = 20,
							ProfileNotFound             = 21 

================================================================================================*/

#pragma comment(lib, "gdiplus.lib")

											/* dummy types used for internal type checking		*/
typedef struct tagGp_GpImage			{ int unused ; } GP_GPIMAGE ;
typedef struct tagGp_GpGraphics			{ int unused ; } GP_GPGRAPHICS ;
typedef struct tagGp_GpImageAttributes	{ int unused ; } GP_GPIMAGEATTRIBUTES ;

typedef struct tagGpPropertyItem
{
    ULONG id ;								/* ID of this property								*/
    ULONG length ;							/* Length of the property value, in bytes			*/
    WORD  type ;							/* Type of the value (tag)							*/
    VOID* value ;							/* property value[s]								*/
} PROPERTYITEM ;

typedef struct
{
	UINT32 GdiplusVersion ;
	void* DebugEventCallback ;
	BOOL SuppressBackgroundThread ;
	BOOL SuppressExternalCodecs ;
} GDIPLUSSTARTUPINPUT ;

#define PropertyTagFrameDelay 0x5100	/* Delay in 1/100 s between 2 frames in an animated GIF	*/
										/* Type:	PropertyTagTypeLong							*/
										/* Count:	Number of frames in the image				*/

int  _stdcall GdiplusStartup(ULONG_PTR*, const GDIPLUSSTARTUPINPUT*, void*) ;
VOID _stdcall GdiplusShutdown(ULONG_PTR) ;

int _stdcall GdipLoadImageFromStreamICM(IStream* stream, GP_GPIMAGE **gpImg);
int _stdcall GdipLoadImageFromFileICM(const wchar_t*, GP_GPIMAGE **gpImg) ;
int _stdcall GdipDisposeImage(GP_GPIMAGE*) ;

int _stdcall GdipCreateFromHDC(HDC, GP_GPGRAPHICS**) ;
int _stdcall GdipDeleteGraphics(GP_GPGRAPHICS*) ;

int _stdcall GdipGetImageRawFormat(GP_GPIMAGE *gpImg, GUID *format);
int _stdcall GdipGetImageWidth(GP_GPIMAGE*, UINT*) ;
int _stdcall GdipGetImageHeight(GP_GPIMAGE*, UINT*) ;
int _stdcall GdipImageGetFrameDimensionsCount(GP_GPIMAGE *gpImg, UINT* count);
int _stdcall GdipImageGetFrameDimensionsList(GP_GPIMAGE *gpImg, GUID* dimensionIDs, UINT count);
int _stdcall GdipImageGetFrameCount(GP_GPIMAGE *gpImg, const GUID* dimensionID, UINT* count);
int _stdcall GdipImageSelectActiveFrame(GP_GPIMAGE *gpImg, const GUID* dimensionID,
							UINT frameIndex);
int _stdcall GdipGetPropertyItemSize(GP_GPIMAGE *gpImg, PROPID propId, UINT* size);
int _stdcall GdipGetPropertyItem(GP_GPIMAGE *gpImg, PROPID propId, UINT propSize,
                    		PROPERTYITEM* buffer);

int _stdcall GdipCreateImageAttributes(GP_GPIMAGEATTRIBUTES** imageattr) ;
int _stdcall GdipSetImageAttributesColorMatrix(GP_GPIMAGEATTRIBUTES *imageattr,
						int adjustType, BOOL enableFlag, float colorMatrix[5][5],
						float grayMatrix[5][5], int colorMatrixFlags) ;
int _stdcall GdipDisposeImageAttributes(GP_GPIMAGEATTRIBUTES*) ;

int _stdcall GdipDrawImageRectI(GP_GPGRAPHICS*, GP_GPIMAGE*, 
						int x, int y, int width, int height) ;
int _stdcall GdipDrawImageRectRectI(GP_GPGRAPHICS*, GP_GPIMAGE*, 
						int dstx, int dsty, int dstwidth, int dstheight,
						int srcx, int srcy, int srcwidth, int srcheight,
						int srcUnit, GP_GPIMAGEATTRIBUTES*, void* cbfunc, void* cbdata) ;
