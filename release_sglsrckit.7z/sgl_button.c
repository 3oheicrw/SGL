/*================================================================================ SGL_BUTTON.C ==
SGL BUTTON class.

For SGL_CTRL_BUTTON and SGL_CTRL_PUSHBUTTON, the border is a custom client area.
SGL_CTRL_CHECKBUTTON and SGL_CTRL_RADIOBUTTON are standard Windows buttons.

==================================================================================================
date       author			update
----       ------			------
14/06/..   h serindat		creation start
15/09/04					v1.0 - first release
15/09/29					minor update SGL__buttonNew(): default args of CreateWindowEx()
15/10/06					added missing break at end of the WM_PAINT case in buttonProc*()
15/12/25					styles for BUTTON and PUSHBUTTON
16/01/11					v1.2 - winProc renamed sglProc to prevent confusion
16/07/06					v1.3 - update of internal tools
================================================================================================*/

#include "sgl_base_.h"
#include "sgl_button.h"
#include "sgl_button_.h"

static int parmIgnore(SGL_T *sgl, int dum, int check) ;
static void buttonResize(SGL_T *sgl) ;
static LRESULT buttonProc(HWND hwnd, SGL_T *sgl, UINT message, WPARAM wParam, LPARAM lParam) ;
static LRESULT buttonProc2(HWND hwnd, SGL_T *sgl, UINT message, WPARAM wParam, LPARAM lParam) ;

typedef struct								/* specific object data								*/
{
	int val ;								/* value of the button (0/1)						*/
} SGL_BUTTON_T ;

#define ISBUTTON(sgl)  ((sgl)->type == SGL_CTRL_BUTTON		||			\
						(sgl)->type == SGL_CTRL_PUSHBUTTON	||			\
						(sgl)->type == SGL_CTRL_CHECKBUTTON	||			\
						(sgl)->type == SGL_CTRL_RADIOBUTTON)

/* default metrics	*/

#define BORDERTHICKNESS	-23					/* unit: twip					*/
#define WIDTH			 -7					/* unit: font height			*/

/* debug condition */

#define DEBUG (sgl->debug ? STD : NONE)

 
/*----------------------------------------------------------------------------------------------*/
int  SGL__buttonInit(void) { return 0 ; }
void SGL__buttonExit(void) { return ; }

/*----------------------------------------------------------------------------------------------*/
int SGL__buttonNew(SGL_T *sgl)							/* create a new button					*/
{
	if (!ISBUTTON(sgl))				return SGL_ERR_TYPE ;
	if (sgl->hwndParent == NULL)	return SGL_ERR_PARM - 0 ;	/* parent must exist			*/

	NEW(SGL_BUTTON_T, button) ;
	if (sgl->ex)											/* case duplicate					*/
		*button = *(SGL_BUTTON_T*)sgl->ex ;
	else													/* case new							*/
	{
		switch (sgl->type)
		{
			case SGL_CTRL_BUTTON :			sgl->typeName = "BUTTON" ;			break ;
			case SGL_CTRL_PUSHBUTTON :		sgl->typeName = "PUSH_BUTTON" ;		break ;
			case SGL_CTRL_CHECKBUTTON :		sgl->typeName = "CHECK_BUTTON" ;	break ;
			case SGL_CTRL_RADIOBUTTON :		sgl->typeName = "RADIO_BUTTON" ;	break ;
		}
		sgl->parmIgnore  = parmIgnore ;									/* default attributes	*/
		sgl->resizeObj = buttonResize ;
		switch (sgl->type)
		{
			case SGL_CTRL_BUTTON :
			case SGL_CTRL_PUSHBUTTON :
				switch (sgl->uStyle)									/* check style			*/
				{
					case SGL_LEFT :
					case SGL_CENTER :											/* default (0)	*/
					case SGL_RIGHT :
						break ;
					default :
						return  SGL_ERR_PARM - 2 ;
				}
				sgl->borderThickness = BORDERTHICKNESS ;
				sgl->borderStyle	 = SGL_BORDER_BEVEL_UP ;
				sgl->sglProc		 = buttonProc ;
				break ;
			case SGL_CTRL_CHECKBUTTON :
			case SGL_CTRL_RADIOBUTTON :
				switch (sgl->uStyle)									/* check style			*/
				{
					case DT_LEFT :												/* default (0)	*/
					case DT_RIGHT :
						break ;
					default :
						return  SGL_ERR_PARM - 2 ;
				}
				sgl->borderThickness = 0 ;
				sgl->sglProc		 = buttonProc2 ;
				break ;
		}
	}

	sgl->ex = button ;

	sgl->hwnd = CreateWindowEx(0, MAINCLASSNAME, sgl->title, sgl->winStyle,		/* creation		*/
							    0, 0, 0, 0,
							    sgl->hwndParent, (HMENU) 0, SGL__instance, NULL) ;
	if (sgl->hwnd == NULL)
		return SGL_ERR_ALLOC ;

	return 0 ;
}

/*----------------------------------------------------------------------------------------------*/
static int parmIgnore(SGL_T *sgl, int check, int dum)
{														/* no border for check or radio buttons */
	if ((check == CHECK_BORDERSTYLE || check == CHECK_BORDERTHICKNESS) &&
		(sgl->type == SGL_CTRL_CHECKBUTTON || sgl->type == SGL_CTRL_RADIOBUTTON))
			return 1 ;
	return 0 ;
}

/*========================================================================= SET/GET FUNCTIONS ==*/

#define CHECK_OBJ(h, b)		SGL_T* sgl = SGL__getStruct(h) ;								\
							if (sgl == NULL)					return SGL_ERR_PARM - 0 ;	\
							if (!ISBUTTON(sgl))					return SGL_ERR_TYPE ;		\
							SGL_BUTTON_T *b = sgl->ex ;										\
							if (b == NULL)						return SGL_ERR_INT ;

/*----------------------------------------------------------------------------------------------*/
int SGL_ButtonValueSet(HWND hwnd, int value)
{
	CHECK_OBJ(hwnd, button) ;
	if (value < 0)
		return SGL_ERR_PARM - 1 ;
	button->val = value ;
	RedrawWindow(sgl->hwnd, NULL, NULL, RDW_INVALIDATE | RDW_FRAME | RDW_UPDATENOW) ;
	return 0 ;
}

int SGL_ButtonValueGet(HWND hwnd)
{
	CHECK_OBJ(hwnd, button) ;
	return button->val ;
}

/*----------------------------------------------------------------------------------------------*/
static void buttonResize(SGL_T *sgl)					/* resize a button						*/
{
	for (size_t i = 0 ; i < 2 ; i++)					/* 0: horizontal, 1: vertical			*/
	{
		int l = sgl->uSize[i] ;								/* width or heigth					*/
		if (l == 0)											/* case autosize					*/
		{
			if (i == 0) 
				l = WIDTH ;											/* default width			*/
			else
			{
				l = SGL__getFontHeight(sgl) ;						/* auto height				*/
				if (sgl->type == SGL_CTRL_BUTTON || sgl->type == SGL_CTRL_PUSHBUTTON)
					l += 2 * SIZE(SGL_defPad / 2) ;
			}
		}
		if (l < 0)											/* user size in character height	*/
			l *= - SGL__getFontHeight(sgl) ;

		l += (2 * sgl->borderThickness) / 100 ;				/* add non client objects			*/
		RECT_SETWH(i, sgl->rect, l)
	}
	return ;											/* done									*/
}

/*------------------------------------------------------------------ for BUTTON or PUSHBUTTON --*/

static LRESULT buttonProc(HWND hwnd, SGL_T *sgl, UINT message, WPARAM wParam, LPARAM lParam)
{
	LRESULT result = DEFPROC ;						/* default result: no message processed		*/

	if (sgl->type == SGL_CTRL_PUSHBUTTON)			/* update value and border					*/
	{
		switch (message)
		{
			case WM_KILLFOCUS :
				sgl->context.selected = 0 ;
				SendMessage(hwnd, WM_NCPAINT, 0, 0) ;
				result = 0 ;
				break ;

			case WM_LBUTTONDOWN :
				sgl->context.selected = 1 ;
				SendMessage(hwnd, WM_NCPAINT, 0, 0) ;
				result = 0 ;
				break ;

			case WM_LBUTTONUP :
				sgl->context.selected = 0 ;
				SendMessage(hwnd, WM_NCPAINT, 0, 0) ;
				PostMessage(hwnd, WM_USER, 0, 0) ;
				result = 0 ;
				break ;
		}
	}

	switch (message)
	{
		case WM_NCCALCSIZE :						/* reserve space for the border				*/
			if (sgl->borderThickness)
			{
				int w = SIZE(sgl->borderThickness) ;
				RECT *clientRect = (RECT*) lParam ;
				InflateRect(clientRect, - w, - w) ;
			}
			break ;

		case WM_NCPAINT :							/* draw border								*/
			if (sgl->borderThickness)
			{
				HDC hdcW = GetWindowDC(hwnd) ;
					RECT rectW ;
					GetWindowRect(hwnd, &rectW) ;
					rectW.right -= rectW.left ; rectW.left = 0 ;
					rectW.bottom -= rectW.top ; rectW.top = 0 ;

					int style = sgl->borderStyle ;
					if (sgl->type == SGL_CTRL_PUSHBUTTON &&
						(((SGL_BUTTON_T*) sgl->ex)->val || sgl->context.selected))
					{										/* if button is set or	selected	*/
						switch (style)					 			/* invert the border aspect	*/
						{
							case SGL_BORDER_BEVEL_UP :
								style = SGL_BORDER_BEVEL_DOWN ;
								break ;
							case SGL_BORDER_BEVEL_DOWN :
								style = SGL_BORDER_BEVEL_UP ;
								break ;
							case SGL_BORDER_ETCHED_UP :
								style = SGL_BORDER_ETCHED_DOWN ;
								break ;
							case SGL_BORDER_ETCHED_DOWN :
								style = SGL_BORDER_ETCHED_UP ;
								break ;
						}
					}
				COLORREF borderColor ;
				if (sgl->borderColor == -1)
					borderColor = sgl->context.bgdColor ;
				else
					borderColor = SGL_ColorDim(sgl->borderColor, sgl->context.dimmed) ;
				SGL_BorderDraw(hdcW, &rectW, style, SIZE(sgl->borderThickness), 
						borderColor, sgl->context.dimmed) ;
				ReleaseDC(hwnd, hdcW) ;
			}
			break ;

		case WM_PAINT :
		{
			PAINTSTRUCT ps ;
			HDC hdc = BeginPaint(hwnd, &ps) ;

			RECT rect ; GetClientRect(hwnd, &rect) ;		/* paint background					*/
			SetDCBrushColor(hdc, sgl->context.bgdColor) ;
		    FillRect(hdc, &rect, GetStockObject(DC_BRUSH)) ;

			char* title = sgl->title ;						/* draw title						*/
			int titleSize = title ? (int) strlen(title) : 0 ;
        	if (titleSize)
			{
				SelectObject(hdc, SGL__getFont(sgl)) ;
				SetTextColor(hdc, sgl->context.fgdColor) ;
				SetBkMode(hdc, TRANSPARENT) ;
				int wStyle = 0 ;
				switch (sgl->uStyle)
				{
					case SGL_CENTER :
						wStyle = DT_CENTER ;
						break ;
					case SGL_LEFT :
						wStyle = DT_LEFT ;
						rect.left  += SIZE(SGL_defPad) ;
						break ;
					case SGL_RIGHT :
						wStyle = DT_RIGHT ;
						rect.right -= SIZE(SGL_defPad) ;
						break ;
				}
				DrawText(hdc, title, titleSize, &rect, TEXTSTYLE0 | wStyle) ;
			}

			EndPaint(hwnd, &ps) ;
			result = 0 ;
			break ;
		}
	}
	return result ;
}

/*------------------------------------------------------------ for RADIOBUTTON or CHECKBUTTON --*/

static LRESULT buttonProc2(HWND hwnd, SGL_T *sgl, UINT message, WPARAM wParam, LPARAM lParam)
{
	int *pval = &(((SGL_BUTTON_T*) sgl->ex)->val) ;			/* pointer to the control value		*/

	LRESULT result = DEFPROC ;						/* default result: no message processed		*/
	RECT rect, brect ;

	switch (message)
	{
		case WM_LBUTTONDOWN :						/* change value (0 <-> 1)					*/
		{
			GetClientRect(hwnd, &brect) ;						/* set the active clicking area	*/
			int h = brect.bottom ;									/* origin is (0, 0)			*/
			if (sgl->uStyle == DT_LEFT) brect.right = 2 * h ;
			if (sgl->uStyle == DT_RIGHT) brect.left = brect.right - 2 * h ;

			POINT pt ; SGL_CursorPositionGet(hwnd, 0, &pt) ;	/* cursor screen coordinates	*/
			if (PtInRect(&brect, pt))
			{
				*pval = (*pval) ? 0 : 1 ;							/* change value				*/
				SGL_Redraw(hwnd) ;
				PostMessage(hwnd, WM_USER, 0, 0) ;
			}
			result = 0 ;
			break ;
		}

		case WM_PAINT :							/* all (button & label) is in the client area	*/
		{
			PAINTSTRUCT ps ;
			HDC hdc = BeginPaint(hwnd, &ps) ;

			GetClientRect(hwnd, &rect) ;					/* paint background					*/
			SetDCBrushColor(hdc, sgl->context.bgdColor) ;
		    FillRect(hdc, &rect, GetStockObject(DC_BRUSH)) ;

			brect = rect ;									/* button rectangle					*/
			int h = rect.bottom ;							/* origin is (0, 0)					*/
			UINT textStyle = TEXTSTYLE0 ;
			if (sgl->uStyle == DT_LEFT)						/* draw button at left				*/
			{
				brect.right = h ;
				rect.left += 3 * h / 2 ;
				textStyle |= DT_LEFT ;
			}
			if (sgl->uStyle == DT_RIGHT)					/* draw button at right				*/
			{
				brect.left = brect.right - h ;
				rect.right -= 3 * h / 2 ;
				textStyle |= DT_RIGHT ;
			}
			UINT state = (sgl->type == SGL_CTRL_RADIOBUTTON) ? DFCS_BUTTONRADIO : DFCS_BUTTONCHECK ;
			if (*pval) state |= DFCS_CHECKED ;
			if (sgl->context.dimmed) state |= DFCS_INACTIVE ;
			DrawFrameControl(hdc, &brect, DFC_BUTTON, state) ;

			char* title = sgl->title ;						/* draw title						*/
			int titleSize = title ? (int) strlen(title) : 0 ;
        	if (titleSize)
			{
				SelectObject(hdc, SGL__getFont(sgl)) ;
				SetTextColor(hdc, sgl->context.fgdColor) ;
				SetBkMode(hdc, TRANSPARENT) ;
				DrawText(hdc, title, titleSize, &rect, TEXTSTYLE0 | sgl->uStyle) ;
			}

			EndPaint(hwnd, &ps) ;
			result = 0 ;
			break ;
		}
	}
	return result ;
}
