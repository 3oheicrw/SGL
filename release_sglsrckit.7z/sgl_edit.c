/*================================================================================== SGL_EDIT.C ==
SGL EDIT class.

An EDIT object is the Windows EDIT control.This object receives and processes messages normally 
sent to its parent (dialog). The Windows procedure in sgl.c redirect these messages).

==================================================================================================
date       author			update
----       ------			------
14/06/..   h serindat		creation start
15/09/04					v1.0 - first release
15/09/29					minor update SGL__editNew(): default args of CreateWindowEx()
15/10/16					v1.1 - editResize(): height correction when setting the nb of lines
16/01/11					v1.2 - winProc renamed sglProc to prevent confusion
16/07/06					v1.3 - update of internal tools
================================================================================================*/


#include "sgl_base_.h"
#include "sgl_edit.h"
#include "sgl_edit_.h"

#define ISEDIT(sgl)  ((sgl)->type == SGL_CTRL_EDIT)

/* debug condition */

#define DEBUG (sgl->debug ? STD : NONE)


/*========================================================================= STANDARD EDIT BOX ==*/

static void editResize(SGL_T *sgl) ;
static int parmIgnore(SGL_T *sgl, int dum, int check) ;
static LRESULT editProc(HWND hwnd, SGL_T *sgl, UINT message, WPARAM wParam, LPARAM lParam) ;

/*----------------------------------------------------------------------------------------------*/
int  SGL__editInit(void) { return 0 ; }
void SGL__editExit(void) { return ; }

/*----------------------------------------------------------------------------------------------*/
int SGL__editNew(SGL_T *sgl)								/* create a new edit				*/
{
	if (!ISEDIT(sgl))				return SGL_ERR_TYPE ;
	if (sgl->hwndParent == NULL)	return SGL_ERR_PARM - 0 ;		/* parent must exist		*/

	if (sgl->resizeObj == NULL)								/* if new (ie. not duplicate)		*/
	{
		sgl->typeName = "EDIT" ;
		sgl->uSize[0] = - 25 ;										/* default size				*/
		sgl->uSize[1] = - 8 ;

		sgl->resizeObj = editResize ;
		sgl->parmIgnore = parmIgnore ;								/* check for std attributes	*/
		sgl->sglProc = editProc ;
	}

	sgl->hwnd = CreateWindowEx(0, "edit", "", 			/* create control with no default text	*/
							   sgl->winStyle | sgl->uStyle,
							   0, 0, 0, 0,
							   sgl->hwndParent, (HMENU) 0, SGL__instance, NULL) ;
	if (sgl->hwnd == NULL)
		return SGL_ERR_ALLOC ;
																/* subclass the edit box		*/
	sgl->defWinProc = (WNDPROC) SetWindowLongPtr(sgl->hwnd, GWLP_WNDPROC,
												 (LONG_PTR) SGL__WinProc) ;
	return 0 ;
}

/*----------------------------------------------------------------------------------------------*/
static void editResize(SGL_T *sgl)							/* resize							*/
{
	int hCorr = 0 ;											/* height correction / border		*/
	if ((sgl->uStyle & WS_CAPTION) == WS_CAPTION)					/* test 1st (several bits)	*/
		hCorr = 2 ;
	else if (sgl->uStyle & WS_BORDER)
		hCorr = 4 ;
	else if (sgl->uStyle & WS_THICKFRAME)
		hCorr = 2 ;

	for (int i = 0 ; i < 2 ; i++)							/* 0: horizontal, 1: vertical		*/
	{
		int l ;														/* width or heigth			*/
		if (sgl->uSize[i] <= 0)									
			l = hCorr - sgl->uSize[i] * SGL__getFontHeight(sgl)		/* size in character height	*/
					  + (SGL__getFontHeight(sgl) + 4) / 6 ;
		else
			l = sgl->uSize[i] ;										/* size in pixels			*/

		if (sgl->scrollBars[1 - i])							/* add non client objects			*/
			l += GetSystemMetrics(i ? SM_CXHSCROLL : SM_CXVSCROLL) ;
		RECT_SETWH(i, sgl->rect, l)
	}
	return ;												/* done								*/
}

/*----------------------------------------------------------------------------------------------*/
static int parmIgnore(SGL_T *sgl, int check, int dum)
{
	if (check == CHECK_BORDERSTYLE || check == CHECK_BORDERTHICKNESS)
			return 1 ;
	return 0 ;
}


/*========================================================================= SET/GET FUNCTIONS ==*/

#define CHECK_OBJ(h)		SGL_T* _sgl = SGL__getStruct(h) ;								\
							if (_sgl == NULL)					return SGL_ERR_PARM - 0 ;	\
							if (!ISEDIT(_sgl))					return SGL_ERR_TYPE ;		\

/*----------------------------------------------------------------------------------------------*/
int SGL_EditTextSet(HWND hwnd, char *text)
{
	CHECK_OBJ(hwnd) ;

	int e = SetWindowText(hwnd, text) ;
	return e ? 0 : SGL_ERR_PARM - 1 ;
}

int SGL_EditTextAppend(HWND hwnd, char *text)
{
	CHECK_OBJ(hwnd) ;

	DWORD l,r;
	SendMessage(hwnd, EM_GETSEL,(WPARAM)&l,(LPARAM)&r) ;			/* save caret position		*/

	int iLength = GetWindowTextLength(hwnd) ;						/* set selection at end		*/
	SendMessage(hwnd, EM_SETSEL, iLength, iLength) ;
	SendMessage(hwnd, EM_REPLACESEL, 0, (LPARAM) text) ;			/* replace with new text	*/
	SendMessage(hwnd, EM_SETSEL,l,r) ;								/* restore caret			*/

	return 0 ;									/* just hope that SendMessage worked properly!	*/
}

int SGL_EditTextLengthGet(HWND hwnd)
{
	CHECK_OBJ(hwnd) ;
	return GetWindowTextLength(hwnd) ;
}

int SGL_EditTextGet(HWND hwnd, char *text, int maxLen)
{
	CHECK_OBJ(hwnd) ;
	if (text == NULL)	return SGL_ERR_PARM - 1 ;
	if (maxLen < 1)		return SGL_ERR_PARM - 2 ;

	return GetWindowText(hwnd, text, maxLen) ;
}


/*---------------------------------------------------------------------- SGL object procedure --*/
static LRESULT editProc(HWND hwnd, SGL_T *sgl, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_CTLCOLOREDIT :								/* set font and background			*/
		case WM_CTLCOLORSTATIC :									/* case ES_READONLY style	*/
			SendMessage(hwnd, WM_SETFONT, (WPARAM) SGL__getFont(sgl), 0) ;
			SetTextColor((HDC) wParam, sgl->context.fgdColor) ;
			SetBkColor((HDC) wParam, sgl->context.bgdColor) ;		/* color within edited text	*/
			SetDCBrushColor((HDC) wParam, sgl->context.bgdColor) ;	/* color outside			*/
			return (LRESULT) GetStockObject(DC_BRUSH) ;
			break ;
	}
	return DEFPROC ;
}
