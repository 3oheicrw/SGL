/*================================================================================ EDIT POPUP ==*/

typedef int (*SGL_EDITCB)(int virtKey, char* text, int textLen, int caret, void* CBdataPtr) ;

HWND SGL_PopupEdit(HWND hwnd, RECT *rect, DWORD style, char *text, int textLen, 
					SGL_EDITCB editCB, void* CBdataPtr) ;

/*=========================================================================== DATE-TIME POPUP ==*/

#define SGL_TIME		0x100										/* exclusive styles			*/
#define SGL_DATE		0x200

#define SGL_DT_LONG		0x80										/* or-ed styles for date	*/
#define SGL_DT_CALENDAR	0x40
#define SGL_DT_WEEKNB	0x20
#define SGL_DT_TODAY	0x10

#define SGL_DT_NONE		0x1											/* or-ed styles for all		*/

typedef void (*SGL_DTIMECB)(int event, SYSTEMTIME *datetime, void* CBdataPtr) ;
													/* event values for SGL_DTIMECB				*/
#define SGL_DT_INSTALL	0								/* popup install						*/
#define SGL_DT_DELETE	1								/* date time delete (case SGL_DT_NONE)	*/
#define SGL_DT_CHANGED	2								/* date time changed					*/
#define SGL_DT_RELEASE	3								/* popup release						*/

#define SGL_DATETIME_NONE_SET(dt) (dt).wYear = 0
#define SGL_DATETIME_NONE_IS(dt) ((dt).wYear == 0)

HWND SGL_PopupDatetime(HWND hwnd, RECT *rect, int style, char *format, SYSTEMTIME *datetime,
						SGL_DTIMECB dtimeCB, void* CBdataPtr) ;

int SGL_DateTimeStringGet(SYSTEMTIME *datetime, int style, char *format, char* dst, int max) ;
SYSTEMTIME SGL_DateTimeNow(void) ;

/*================================================================================ POPUP MENU ==*/

typedef struct
{
	int  state ;				/* one of: 0 (default), MF_CHECKED, MF_DISABLED, MF_SEPARATOR	*/
	char *text ;				/* option text: ignored if separator, NULL at end				*/
} SGL_POPUPMENU_OPTIONS_T ;

int SGL_PopupMenu(HWND hwnd, SGL_POPUPMENU_OPTIONS_T* option, RECT *rect, int align) ;
