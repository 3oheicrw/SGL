#pragma comment(lib, "comdlg32.lib")	/* required by GetOpenFileName()	*/

#include "sgl.h"
#include "sample_image.h"

#pragma warn(disable: 2118 2216)	/* disable some warnings				*/
			/* 2118: Parameter {parameter_name} is not referenced.			*/
			/* 2216: The return value from {function_name} is never used.	*/

HWND mainPanel, image, rbtn[2];
#define ANIMATE 0
#define NEXT 1

int frameCount;

void imageLoad(char* fileName)
{
	SGL_ImageUnload(image);
	SGL_ImageLoad(image, fileName);

	char *p = strrchr(fileName, '\\');
	if (p) SGL_TitleSet(image, p + 1);

	frameCount = SGL_ImageFrameCountGet(image);
	SGL_DimmedSet(rbtn[ANIMATE], (frameCount < 2));
	SGL_DimmedSet(rbtn[NEXT], (frameCount < 2));
	SGL_Redraw(mainPanel);
}

int radioBtnCB(HWND hwnd, UINT event, WPARAM wParam, LPARAM lParam)
{
	if (event == WM_USER)
	{
		for (int i = 0 ; i < 2 ; i++)				/* reset other buttons	*/
			if (hwnd != rbtn[i])
				SGL_ButtonValueSet(rbtn[i], 0);
		SGL_ImagePlay(image, 0);

		if (hwnd == rbtn[ANIMATE])					/* animate				*/
		{
			if (SGL_ButtonValueGet(hwnd))
				SGL_ImagePlay(image, 100);					/* normal speed	*/
		}
		else if (hwnd == rbtn[NEXT])				/* show next frame		*/
		{
			SGL_ImagePlay(image, 0);

			int i = SGL_ImageFrameIndexGet(image) + 1;
			if (i >= frameCount) i = 0;
			SGL_ImageFrameIndexSet(image, i);
			SGL_Redraw(image);
			SGL_Log(STD, "Frame %d / %d", i, frameCount);
		}
	}

	if (event == WM_LBUTTONUP && hwnd == rbtn[NEXT])
		SGL_ButtonValueSet(rbtn[NEXT], 0);

	return 0;
}

int imgSelectCB(HWND hwnd, UINT event, WPARAM wParm, LPARAM lParm)
{
	static char imageFilename[MAX_PATH];
	if (event == WM_LBUTTONUP)						/* get a new file		*/
	{
		radioBtnCB(0, WM_USER, 0, 0);

		OPENFILENAME ofn = {
			.lStructSize = sizeof(ofn),
			.lpstrTitle = "Afficher une image",
			.nMaxFile = MAX_PATH };
		ofn.hwndOwner = hwnd;
		ofn.lpstrFile = imageFilename;

		if (GetOpenFileName(&ofn))
			imageLoad(imageFilename);
	}
	return 0;
}

/*================================================================== MAIN ==*/

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    PSTR szCmdLine, int iCmdShow)
{
	AllocConsole();								/* for console messages	*/
	SGL_Init(hInstance, "#8001");
	SGL_Log(STD, "==== SGL IMAGE DEMO ====\n");

		/*------------------------------------------------------ Main panel	*/
	mainPanel = SGL_New(0, SGL_PANEL, 0, "SGL Image Demo", 30, 30);

		/*--------------------------------------- Hidden panel with buttons	*/
	HWND hpanel = SGL_New(mainPanel, SGL_HIDDENFRAME, 0, "hiddenPanel", 0, 0);
	CHKERR(SGL_AlignmentSet(hpanel, SGL_TOP));

	HWND btnLoad = SGL_New(hpanel, SGL_CTRL_PUSHBUTTON, 0, "Load image", 0, 0);
	CHKERR(SGL_CallbackFunctionSet(btnLoad, imgSelectCB));

	rbtn[ANIMATE] = SGL_New(hpanel, SGL_CTRL_RADIOBUTTON, 0, "Animate", 0, 2);
	CHKERR(SGL_CallbackFunctionSet(rbtn[ANIMATE], radioBtnCB));

	rbtn[NEXT] = SGL_New(hpanel, SGL_CTRL_RADIOBUTTON, 0, "Next frame", 0, 4);
	CHKERR(SGL_CallbackFunctionSet(rbtn[NEXT], radioBtnCB));

		/*----------------------------------------------------------- Image	*/
	image = SGL_New(mainPanel, SGL_CTRL_IMAGE, WS_CAPTION, " Image", 2, 0);
	CHKERR(SGL_SizeSet(image, SGL_WIDTH, 240));
	CHKERR(SGL_SizeSet(image, SGL_HEIGHT, 180));
	CHKERR(SGL_BGcolorSet(image, SGL_BLACK));
	imageLoad(":IMAGE:FRAPPE");

	SGL_Layout(mainPanel);
	SGL_VisibleSet(mainPanel, 1);
	SGL_Run();
	SGL_Exit();
	return 0;
}
