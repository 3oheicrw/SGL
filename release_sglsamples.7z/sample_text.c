#include "sgl.h"
#include <stdio.h>

#pragma warn(disable: 2118 2216)	/* disable some warnings					*/
				/* 2118: Parameter {parameter_name} is not referenced.			*/
				/* 2216: The return value from {function_name} is never used.	*/

HWND mainPanel, editFrame, editBox ;
HWND fontSizeBtn, fontStyleBtn ;

/*======================================================== EDIT BOX & BUTTONS ==*/

int fontSizeCB(HWND hwnd, UINT event, WPARAM wParm, LPARAM lParm)
{
	static int size = -1 ;									/* uninitialized	*/
	static char title[4][64] = { "Font size small", "Font size normal",
								 "Font size large", "Font size big" } ;

	if (event == WM_USER)							/* button value has changed */
	{
		if (size < 0)										/* initialize		*/
			size = SGL_FONT_NORMAL ;						/* initial value	*/
		else
			size++ ;										/* new size 		*/
		size = size % 4 ;

		CHKERR(SGL_FontSizeIxSet(editFrame, size)) ;				/* apply	*/
		CHKERR(SGL_TitleSet(hwnd, title[size])) ;
		SGL_Layout(mainPanel) ; 					/* rearrange all and redraw */
	}
	return 0 ;
}

int fontStyleCB(HWND hwnd, UINT event, WPARAM wParm, LPARAM lParm)
{
	static int style = -1 ; 								/* uninitialized	*/
	if (event == WM_LBUTTONDOWN)
	{
		static SGL_POPUPMENU_OPTIONS_T ppm[] =
		{
			{0, "Fixed"},
			{0, "Normal"},
			{0, "Bold"},
			{0, "Italic"},
			{0, NULL}
		} ;

		int e ; 											/* popup result 	*/

		if (style < 0)										/* initialize		*/
			e = SGL_FONT_NORMAL ;
		else
		{
			RECT rect ; 									/* install popup	*/
			GetWindowRect(hwnd, &rect) ;
			e = SGL_PopupMenu(hwnd, ppm, &rect, SGL_LEFT) ;
		}

		if (e >= 0)
		{
			style = e ; 									/* new style		*/
			for (int i = 0 ; ppm[i].text ; i++) 			/* update options	*/
				ppm[i].state = (i == style) ? MF_CHECKED : 0 ;

			CHKERR(SGL_FontStyleSet(editBox, style)) ; 	/* apply			*/
			SGL_Redraw(editBox) ;
		}
		return 1 ;
	}
	return 0 ;
}

/*================================================================== [F9-12]	*/

static int scaleCB(HWND hwnd, UINT event, WPARAM wParm, LPARAM dum)
{
	static char scaleLabel[32] ;
	switch (event)
	{
		case WM_SYSCOMMAND :			/* prevents F10 to entre a menu loop	*/
			if (wParm == SC_KEYMENU)
				return 1 ;
			break ;

		case WM_KEYDOWN :
		case WM_SYSKEYDOWN :			/* Windows handles F10 as a system key	*/
		{
			int scale = 0 ;
			switch (wParm)
			{
				case VK_F9 :  scale =  -85 ; break ;
				case VK_F10 : scale = -100 ; break ;
				case VK_F11 : scale = -160 ; break ;
				case VK_F12 : scale = -250 ; break ;
			}
			if (scale)
			{
				SGL_FontSizeSet(SGL_FONT_NORMAL, scale) ;
				sprintf(scaleLabel, "Scale %d %c", scale, '%') ;
				SGL_TitleSet(hwnd, scaleLabel) ;
				SGL_Layout(hwnd) ;
			}
			return 1 ;
		}
		case WM_SYSKEYUP :
			return 1 ;
	}
	return 0 ;
}


/*======================================================================== MAIN */

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
					PSTR szCmdLine, int iCmdShow)
{
	AllocConsole() ;								/* for console messages 	*/
	SGL_DebugSet(NULL, 2) ;
	SGL_Init(hInstance, NULL) ;
	SGL_Log(STD, "==== SGL DEMO ====\n") ;


		/*---------------------------------------------------------- Main panel */
	mainPanel = SGL_New(0, SGL_PANEL, 0, "Main panel", 30, 30) ;
	CHKERR(SGL_CallbackFunctionSet(mainPanel, scaleCB)) ;

		/*----------------------------------- Hidden panel top-left for buttons */
	HWND hpanel = SGL_New(mainPanel, SGL_HIDDENFRAME, 0, "hiddenPanel1", 0, 0) ;
	CHKERR(SGL_AlignmentSet(hpanel, SGL_TOP)) ;

		fontSizeBtn = SGL_New(hpanel, SGL_CTRL_PUSHBUTTON, 0, "Font size", 0, 0) ;
		CHKERR(SGL_CallbackFunctionSet(fontSizeBtn, fontSizeCB)) ;

		fontStyleBtn = SGL_New(hpanel, SGL_CTRL_BUTTON, 0, "Font style", 0, 1) ;
		CHKERR(SGL_CallbackFunctionSet(fontStyleBtn, fontStyleCB)) ;

		/*--------------------------------------------------------- Edit box--- */
	editFrame = SGL_New(mainPanel, SGL_ROUNDEDFRAME, 0, "edit frame", 2, 0) ;
	editBox = SGL_New(editFrame, SGL_CTRL_EDIT, WS_BORDER | WS_VSCROLL | 
			ES_AUTOVSCROLL | ES_LEFT | ES_MULTILINE, "edit box", 0, 0) ;
	CHKERR(SGL_BGcolorSet(editBox, SGL_WHITE)) ;
	CHKERR(SGL_SizeSet(editBox, SGL_WIDTH,	-20)) ;
	CHKERR(SGL_SizeSet(editBox, SGL_HEIGHT, -7)) ;

	char l[1024] = "Press [F9] to [F12] to change the window scale.\r\n"
		"\r\nRight click on [Editable] to change its label.\r\n"
		"\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit, sed "
		"do eiusmod tempor incididunt ut labore et dolore magna aliqua." ;
	SGL_EditTextSet(editBox, l) ;

		/*------------------------------- Initialize via the callback functions */
	fontSizeCB(fontSizeBtn, WM_USER, 0, 0) ;
	fontStyleCB(fontStyleBtn, WM_LBUTTONDOWN, 0, 0) ;
	scaleCB(mainPanel, WM_KEYDOWN, VK_F10, 0) ;

	SGL_VisibleSet(mainPanel, 1) ;
	SGL_Run() ;
	SGL_Exit() ;
	return 0 ;
}
