#include "sgl.h"
#include <stdio.h>

#include <gl/gl.h>
#include <gl/glu.h>

/*--------------------------------------------------------------------------*/
void draw(HWND hwnd, int rotate)        /* main drawing function            */
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    if (rotate)                             /* rotate object according to   */
    {                                       /* the mouse cursor position    */
        RECT rect;                                      /* drawing area     */
        GetClientRect(hwnd, &rect);
        int w = rect.right - rect.left;
        int h = rect.bottom - rect.top;

        POINT pt;                                       /* mouse position   */
        SGL_CursorPositionGet(hwnd, 0, &pt);
        glRotatef(1.0F, (pt.y - 0.5 * h) / h, (pt.x - 0.5 * w) / w, 0.0F);
    }

    glBegin(GL_QUADS);                      /* draw the faces of a cube     */
        glNormal3f( 0.0F, 0.0F, 1.0F);
        glVertex3f( 0.5F, 0.5F, 0.5F); glVertex3f(-0.5F, 0.5F, 0.5F);
        glVertex3f(-0.5F,-0.5F, 0.5F); glVertex3f( 0.5F,-0.5F, 0.5F);

        glNormal3f( 0.0F, 0.0F,-1.0F);
        glVertex3f(-0.5F,-0.5F,-0.5F); glVertex3f(-0.5F, 0.5F,-0.5F);
        glVertex3f( 0.5F, 0.5F,-0.5F); glVertex3f( 0.5F,-0.5F,-0.5F);

        glNormal3f( 0.0F, 1.0F, 0.0F);
        glVertex3f( 0.5F, 0.5F, 0.5F); glVertex3f( 0.5F, 0.5F,-0.5F);
        glVertex3f(-0.5F, 0.5F,-0.5F); glVertex3f(-0.5F, 0.5F, 0.5F);

        glNormal3f( 0.0F,-1.0F, 0.0F);
        glVertex3f(-0.5F,-0.5F,-0.5F); glVertex3f( 0.5F,-0.5F,-0.5F);
        glVertex3f( 0.5F,-0.5F, 0.5F); glVertex3f(-0.5F,-0.5F, 0.5F);

        glNormal3f( 1.0F, 0.0F, 0.0F);
        glVertex3f( 0.5F, 0.5F, 0.5F); glVertex3f( 0.5F,-0.5F, 0.5F);
        glVertex3f( 0.5F,-0.5F,-0.5F); glVertex3f( 0.5F, 0.5F,-0.5F);

        glNormal3f(-1.0F, 0.0F, 0.0F);
        glVertex3f(-0.5F,-0.5F,-0.5F); glVertex3f(-0.5F,-0.5F, 0.5F);
        glVertex3f(-0.5F, 0.5F, 0.5F); glVertex3f(-0.5F, 0.5F,-0.5F);
    glEnd();

    SwapBuffers(GetDC(hwnd));               /* display the result           */
}

/*--------------------------------------------------------------------------*/
int oglCB(HWND hwnd, UINT event, WPARAM wP, LPARAM lP)  /* process events   */
{
    int rotate = 0;
    switch (event)
    {
        case WM_MOUSEMOVE :
            rotate = SGL_LBUTTON ;          /* animate                      */
			if (rotate == 0)
				break ;
        case WM_PAINT :
            draw(hwnd, rotate);
            break;
    }
    return 0;
}

/*--------------------------------------------------------------------------*/
int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrev, LPSTR cLine, int cShow )
{
    SGL_Init(hInst, NULL);
    HWND main  = SGL_New(NULL, SGL_PANEL, 0, "SGL Demo", 50, 20);
    HWND b = SGL_New(main, SGL_CTRL_BUTTON, 0,
                    "Click and drag below ...", 0, 0);
    SGL_AlignmentSet(b, SGL_LEFT | SGL_RIGHT);

    HWND ogl = SGL_New(main, SGL_CTRL_OPENGL, 0, "SGL OpenGL", 0, 1);
    SGL_SizeSet(ogl, SGL_WIDTH, 200);               /* initial size         */
    SGL_SizeSet(ogl, SGL_HEIGHT, 200);
    SGL_ResizeInstall(ogl, 150, 150, NULL);

    SGL_CallbackFunctionSet(ogl, oglCB);

    SGL_OglDepthOfFieldSet(ogl, 0.2, 10.0);
    gluLookAt(0,0,3, 0,0,0, 0,1,0);

    glEnable(GL_DEPTH_TEST);                    /* process hidden parts     */

    glEnable(GL_LIGHTING);                      /* light settings           */
    float light_pos[3][4] = {{0,3.,2.,1}, {2,-2,2,1}, {-2,-2,2,1}};
    float light_col[3][4] = {{0,0,1,1}, {0,1,0,1},  {1,0,0,1}};
    for (int l = 0 ; l < 3 ; l++)
    {
        glEnable(GL_LIGHT0 + l);
        glLightfv(GL_LIGHT0 + l, GL_POSITION, &(light_pos[l][0]));
        glLightfv(GL_LIGHT0 + l, GL_DIFFUSE, &(light_col[l][0]));
    }

    SGL_Layout(main);
    SGL_VisibleSet(main, 1);
    SGL_Run();
    return 0;
}
