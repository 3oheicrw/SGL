/*	VERSION	*/

#define PRODUCT_NAME		"SGL_DEMO"
#define VERSION_BIN			1,0,0,0
#define VERSION_STR			"1.0.0.0"
#define DESCRIPTION			"Message box demo"
#define COPYRIGHT			"Henri Serindat, 2016"
