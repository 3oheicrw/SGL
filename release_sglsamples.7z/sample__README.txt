To build a sample with SGL inside:

- add the content of the release_sgllib.7z in the current directory
- launch PellesC 9.00
- open any project file sample_*.ppj


To build a sample with SGL outside:

- add the content of the release_sgldll.7z in the current directory
- launch PellesC 9.00
- open any project file sample_*.ppj
