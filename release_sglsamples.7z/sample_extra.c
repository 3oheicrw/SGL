#include <stdint.h>

#include "sgl.h"
#include "sample_extra.h"

#pragma warn(disable: 2118 2216)	/* disable some warnings						*/
					/* 2118: Parameter {parameter_name} is not referenced.			*/
					/* 2216: The return value from {function_name} is never used.	*/


/*----------------------------------------------------------------------------------------------*/
void SetMenuChecked(HMENU hMenu, UINT menuID, int checked)			/* simple Win32 addon		*/
{
	MENUITEMINFO mii = {
		.cbSize = sizeof(MENUITEMINFO) ,
		.fMask = MIIM_STATE
	} ;

	mii.fState = checked ? MFS_CHECKED : MFS_UNCHECKED ;
	SetMenuItemInfo(hMenu, menuID, 0, &mii) ;
}

/*----------------------------------------------------------------------------------------------*/
int GetMenuChecked(HMENU hMenu, UINT menuID)						/* simple Win32 addon		*/
{
	MENUITEMINFO mii = {
		.cbSize = sizeof(MENUITEMINFO) ,
		.fMask = MIIM_STATE
	} ;

	if (GetMenuItemInfo(hMenu, menuID, 0, &mii))
		return (mii.fState == MFS_CHECKED) ;
	else
		return 0 ;
}

/*----------------------------------------------------------------------------------------------*/
HCURSOR SGL_GraphCursorCreate(int w)						/* w: full pixel width				*/
{
	if (w % 2 == 0) w++ ;									/* w should be odd					*/
	int w1 = 16 * (1 + w / 16) ;							/* size + 1 as a multiple of 16		*/

	int byteCount = w1 * w1 / 8 ;
	uint8_t buffAnd[byteCount], buffXor[byteCount] ;
	for (int i = 0 ; i < byteCount ; i++)
	{
		buffAnd[i] = 0xff ;									/* use screen						*/
		buffXor[i] = 0x0 ;									/* default: no changed				*/
	}

	HBITMAP hBitmap = CreateBitmap(w + 1, w + 1, 1, 1, NULL) ;
	HDC hdcMask = CreateCompatibleDC (NULL) ;
	SelectObject (hdcMask, hBitmap) ;
	SetBitmapBits(hBitmap, byteCount, buffXor) ;

	SelectObject(hdcMask, GetStockObject(WHITE_PEN)) ;		/* setting for reverse video		*/

	int e = (w + 2) / 12 ;
	int tmax = e / 3 ;

	for (int t = - tmax ; t <= tmax ; t++)					/* thickness loop					*/
	{
		MoveToEx(hdcMask, 0, w / 2 + t, NULL) ;
		LineTo(hdcMask, w / 2 - e, w / 2 + t) ;
		MoveToEx(hdcMask, w / 2 + e + 1, w / 2 + t, NULL) ;
		LineTo(hdcMask, w, w / 2 + t) ;

		MoveToEx(hdcMask, w / 2 + t, 0, NULL) ;
		LineTo(hdcMask, w / 2 + t, w / 2 - e) ;
		MoveToEx(hdcMask, w / 2 + t, w / 2 + e + 1, NULL) ;
		LineTo(hdcMask, w / 2 + t, w) ;
	}

	GetBitmapBits(hBitmap, byteCount, buffXor) ;
	DeleteObject(hBitmap) ;
	DeleteDC(hdcMask) ;
	return CreateCursor(GetModuleHandle(NULL), 
						w / 2, w / 2,						/* position of hot spot				*/
						w1, w1, 							/* cursor size						*/
						buffAnd, buffXor) ;
}
