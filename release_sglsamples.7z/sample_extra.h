HCURSOR SGL_GraphCursorCreate(int w);

int GetMenuChecked(HMENU hMenu, UINT menuID);			/* functions that should exist in Win32	*/
void SetMenuChecked(HMENU hMenu, UINT menuID, int checked);
