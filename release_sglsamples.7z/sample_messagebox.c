#include "sgl.h"
#include <stdio.h>
#include <math.h>

#include "sample_messagebox.h"

#pragma warn(disable: 2118 2216)	/* disable some warnings					*/
				/* 2118: Parameter {parameter_name} is not referenced.			*/
				/* 2216: The return value from {function_name} is never used.	*/


/*============================================================= MESSAGE POPUP ==*/

/*--------------------------------------------------------------------------------
Before calling the public functions, one should dim he main application:
	SGL_DimmedSet(main, 1);

At return, dimming and focus should be reset:
	SGL_DimmedSet(main, 0);
	SetFocus(main);
--------------------------------------------------------------------------------*/

#define LOG_MSGMAX 		1024					/* maximum message size			*/

static HWND confirmPanel;
static int confirmResult;

/*------------------------------------------------------------------------------*/
static void textFit(HWND hwnd, char* text)		/* put text in object withsize fit */
{
	SGL_Layout(hwnd);					/* required to retrieve the font handle	*/
	HFONT hfont = SGL_FontHandleGet(hwnd, -1, -1);

	RECT rect = { 0 } ;
	HDC hdc = GetDC(hwnd) ;
		SelectObject(hdc, hfont);
		DrawText(hdc, text, -1, &rect, DT_CALCRECT) ;
		rect.right += SGL_FontSizeGet(hwnd) ;			/* add some extra width	*/
	ReleaseDC(0, hdc) ;
	SGL_SizeSet(hwnd, SGL_WIDTH, rect.right);
	SGL_SizeSet(hwnd, SGL_HEIGHT, rect.bottom);
	SGL_EditTextSet(hwnd, text);								/* set text		*/

}

/*------------------------------------------------------------------------------*/
static int confirmBtnCB(HWND hwnd, UINT event, WPARAM wParam, LPARAM lParam)
{
	if (event == WM_USER)
	{												/* save button number		*/
		SGL_CallbackDataGet(hwnd, (void*) &confirmResult);
		SGL_Destroy(confirmPanel);
	}
	return 0;
}

/*------------------------------------------------------------------------------*/
static int confirmDrawCB(HWND hwnd, UINT event, WPARAM wParam, LPARAM lParam)
{
	if (event == WM_PAINT)
	{
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hwnd, &ps);
			DrawIcon(hdc, 0, 0, LoadIcon(NULL, IDI_QUESTION));
		EndPaint(hwnd, &ps);
		return 0;
	}
	return 0;
}

/*------------------------------------------------------------------------------*/
int confirmYes(char *fmt,...)
{
	HWND panel, hwnd;									/* temporary object		*/

	confirmPanel = SGL_New(0, SGL_PANEL, 0, PRODUCT_NAME, -1, -1);
	SetWindowLongPtr(confirmPanel, GWL_STYLE, WS_CAPTION);	/* no WS_SYSMENU	*/
	COLORREF color = SGL_ProfileIntGet("COLORS", "panel", -1);
	SGL_BGcolorSet(confirmPanel, color);
														/* TOP ROW				*/
	panel = SGL_New(confirmPanel, SGL_HIDDENFRAME, 0, "button row", 0, 0);

	hwnd = SGL_New(panel, SGL_CTRL_IMAGE, 0, "", 0, 0);		/* icon				*/
	SGL_SizeSet(hwnd, SGL_WIDTH, GetSystemMetrics(SM_CXICON));
	SGL_SizeSet(hwnd, SGL_HEIGHT, GetSystemMetrics(SM_CYICON));
	RECT m; m.top = m.left = m.right = m.bottom = SGL_RefSizeGet();
	SGL_PaddingSet(hwnd, &m);									/* with padding	*/
	SGL_CallbackFunctionSet(hwnd, confirmDrawCB);
	
	char message[LOG_MSGMAX];								/* message			*/
	va_list ap;

	va_start(ap, fmt);											/* build		*/
	vsnprintf(message, LOG_MSGMAX, fmt, ap);
	message[LOG_MSGMAX - 1] = '\0';
	va_end(ap);

	DWORD style = ES_MULTILINE | ES_READONLY;
	hwnd = SGL_New(panel, SGL_CTRL_EDIT, style, "", 1, 0);		/* set size		*/
																/*	and text	*/
	textFit(hwnd, message);
														/* BOTTOM ROW			*/
	panel = SGL_New(confirmPanel, SGL_HIDDENFRAME, 0, "button row", 0, 1);
	SGL_AlignmentSet(panel, SGL_RIGHT);

	char *btnLabel[] = { "No", "Yes" };							/* buttons		*/
	color = SGL_ProfileIntGet("COLORS", "button", -1);
	for (int btn = 0; btn < 2; btn++)
	{
		hwnd = SGL_New(panel, SGL_CTRL_PUSHBUTTON, 0, btnLabel[btn], btn, 0);
		SGL_BGcolorSet(hwnd, color);
		SGL_SizeSet(hwnd, SGL_WIDTH, - 5);
		SGL_CallbackFunctionSet(hwnd, confirmBtnCB);
		SGL_CallbackDataSet(hwnd, (void*) btn);
	}

	SetWindowPos(confirmPanel, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE	| SWP_NOSIZE);
	SGL_Layout(confirmPanel);
	SGL_VisibleSet(confirmPanel, 1);
	MessageBeep(MB_OK);
	SGL_Run();
	return confirmResult;
}

/*====================================================================== MAIN ==*/

HWND mainPanel, colorBtn;
char *colorDef[] = { "panel","button", NULL }; 

int closeCB(HWND hwnd, UINT event, WPARAM wParam, LPARAM lParam)
{
	if (event == WM_SYSCOMMAND && wParam == SC_CLOSE)
	{
		SGL_DimmedSet(mainPanel, 1);
		int close = confirmYes("Really quit?");
		SGL_DimmedSet(mainPanel, 0);
		SetFocus(mainPanel);
		if (!close)
			return 1;
	}
	return 0;
}

static void colorChangeCB(int ix, COLORREF color)
{
	switch (ix)
	{
		case 0:	SGL_BGcolorSet(mainPanel, color);	break;
		case 1:	SGL_BGcolorSet(colorBtn, color);	break;
	}
	SGL_Redraw(mainPanel);
}


int colorBtnCB(HWND hwnd, UINT event, WPARAM wParam, LPARAM lParam)
{
	if (event == WM_USER) SGL_ColorsSet();			/* open the color picker	*/
	return 0;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
					PSTR szCmdLine, int iCmdShow)
{
	SGL_Init(hInstance, "#8001");
	mainPanel = SGL_New(0, SGL_PANEL, 0, "SGL - Message box demo", -1, -1);
	SGL_CallbackFunctionSet(mainPanel, closeCB);
	SGL_Layout(mainPanel);
	SGL_VisibleSet(mainPanel, 1);

	colorBtn = SGL_New(mainPanel, SGL_CTRL_PUSHBUTTON, 0, "Change colors", 0, 0);
	SGL_SizeSet(colorBtn, SGL_WIDTH, -15);
	SGL_CallbackFunctionSet(colorBtn, colorBtnCB);

	SGL_ResizeInstall(colorBtn, 120, 30, NULL);
	SGL_ColorsConfigure(colorDef, "COLORS", colorChangeCB);
	SGL_LayoutConfigure(mainPanel, "MAIN", SGL_SAVE_POSITION);
	SGL_LayoutConfigure(colorBtn, "MAIN", SGL_SAVE_SIZE);
	SGL_Layout(mainPanel) ;
	SGL_Run();

	SGL_Exit();
	return 0;
}
