# SGL-FreeBASIC
Small GUI Library (or Simple Graphic Layer) binding for FreeBASIC

SGL is a small GUI library developed for Windows GUI development by Henri Serindat

Check it here: <http://perso.numericable.fr/hserindat/sgl/>

Download release_sgldllkit.7z and you will have sgl32.dll and sgl64.dll
